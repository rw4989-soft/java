/**
 * 后台管理接口封装（对接 Spring Boot /api/admin/**）。
 *
 * 这组接口需要管理员 token：每次请求自动带上 Authorization: Bearer <adm_token>。
 * token 失效时后端返回 401，这里清掉本地管理员登录态，由调用方跳回管理登录页。
 */
import { adminAuthHeader, clearAdminSession } from '../utils/auth.js'

const BASE = '/api'

/** 过滤空值 */
function buildQuery(params = {}) {
  const search = new URLSearchParams()
  Object.entries(params).forEach(([key, value]) => {
    if (value !== '' && value !== null && value !== undefined) {
      search.append(key, value)
    }
  })
  const qs = search.toString()
  return qs ? `?${qs}` : ''
}

async function request(path, { method = 'GET', params, body } = {}) {
  try {
    const headers = {}
    const auth = adminAuthHeader()
    if (auth) headers.Authorization = auth
    if (body) headers['Content-Type'] = 'application/json'

    const res = await fetch(BASE + path + buildQuery(params), {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined
    })
    const json = await res.json().catch(() => ({}))

    if (res.status === 401 || json.code === 401) {
      clearAdminSession()
      return { ok: false, code: 401, message: json.message || '管理员登录状态已失效，请重新登录' }
    }
    if (json.code === 200) {
      return { ok: true, code: 200, message: json.message, data: json.data }
    }
    return { ok: false, code: json.code, message: json.message || '请求失败，蟹堡王后厨开小差了' }
  } catch (e) {
    return { ok: false, code: -1, message: '网络异常，检查一下后端是不是没启动' }
  }
}

/* 管理员账号 */
export const adminLogin = (username, password) =>
  request('/admin/login', { method: 'POST', body: { username, password } })
export const adminMe = () => request('/admin/me')
export const adminLogout = () => request('/admin/logout', { method: 'POST' })

/* 统计 + 分类 + 地点 */
export const getStats = () => request('/admin/stats')
export const listCategories = () => request('/admin/categories')
export const createCategory = (data) => request('/admin/categories', { method: 'POST', body: data })
export const updateCategory = (id, data) => request(`/admin/categories/${id}`, { method: 'PUT', body: data })
export const deleteCategory = (id) => request(`/admin/categories/${id}`, { method: 'DELETE' })

export const listPlaces = (params) => request('/admin/places', { params })
export const createPlace = (data) => request('/admin/places', { method: 'POST', body: data })
export const updatePlace = (id, data) => request(`/admin/places/${id}`, { method: 'PUT', body: data })
export const deletePlace = (id) => request(`/admin/places/${id}`, { method: 'DELETE' })
