<template>
  <div class="about">
    <OceanBackdrop />
    <PageNav active="about" :nickname="displayName" @logout="$emit('logout')" />

    <main class="main">
      <!-- ============ 头部 ============ -->
      <section class="hero">
        <div class="hero-bubbles" aria-hidden="true">
          <span v-for="b in 8" :key="b" class="hb" :style="bubbleStyle(b)"></span>
        </div>
        <span class="hero-kicker">🍍 比奇堡游客中心</span>
        <h1 class="title">关于比奇堡</h1>
        <p class="sub">一座藏在菠萝屋里的海底小站，收录了比奇堡的角落、故事和快乐。</p>
      </section>

      <!-- ============ 本站简介 ============ -->
      <section class="intro-card">
        <div class="intro-logo">🧽</div>
        <div class="intro-body">
          <h2>欢迎来到比奇堡！</h2>
          <p>
            这里是一个以海绵宝宝为主题的海底小站。我们把比奇堡里的地点、人物和日常整理成一本
            <b>海底图鉴</b>，你可以搜索、筛选、给它们评分；累了就去<b>蟹堡王打个工</b>，或者到
            <b>海底游乐场</b>玩几局小游戏。所有内容都存放在真实的数据库里，成绩和浏览记录都会跟着你的账号走。
          </p>
          <div class="intro-tags">
            <span>🌊 海底图鉴</span>
            <span>🧽 打工日常</span>
            <span>🎮 小游戏</span>
            <span>🛠️ 数据后台</span>
          </div>
        </div>
      </section>

      <!-- ============ 功能板块导览 ============ -->
      <section class="block">
        <div class="block-head">
          <h2>这里有什么玩？</h2>
          <p>四个角落，各自有点意思。点开逛逛吧～</p>
        </div>
        <div class="feature-grid">
          <article
            v-for="f in features"
            :key="f.key"
            class="feature-card"
            :style="{ '--accent': f.accent, '--accent2': f.accent2 }"
            @click="go(f.to)"
          >
            <div class="fc-top">
              <span class="fc-icon">{{ f.icon }}</span>
              <span class="fc-no">{{ f.no }}</span>
            </div>
            <h3>{{ f.name }}</h3>
            <p>{{ f.desc }}</p>
            <div class="fc-foot">
              <span class="fc-tag">{{ f.tag }}</span>
              <span class="fc-go">进入 →</span>
            </div>
          </article>
        </div>
      </section>

      <!-- ============ 数据说明 + 技术栈 ============ -->
      <section class="two-col">
        <div class="info-panel data-panel">
          <h2>📊 图鉴是怎么分的？</h2>
          <p class="panel-sub">首页收录的每条地点，都带分级、评分和热度。</p>
          <div class="grade-row">
            <span v-for="g in grades" :key="g.code" class="grade-pill" :style="{ '--gc': g.color }">
              <b>{{ g.code }}</b> {{ g.label }}
            </span>
          </div>
          <ul class="fact-list">
            <li><span>⭐</span> 评分：由大家打分，越高越值得一看</li>
            <li><span>🔥</span> 热度：近期有多受欢迎</li>
            <li><span>👀</span> 浏览：点开详情一次就 +1</li>
            <li><span>🏷️</span> 标签 & 分类：帮你快速找到同类角落</li>
          </ul>
        </div>

        <div class="info-panel tech-panel">
          <h2>⚙️ 用什么做的？</h2>
          <p class="panel-sub">一个前后端分离的小项目，真数据库、真接口。</p>
          <div class="tech-list">
            <div class="tech-item">
              <span class="tech-ico front">🎨</span>
              <div><b>前端</b><small>Vue 3 · Vite · Vue Router</small></div>
            </div>
            <div class="tech-item">
              <span class="tech-ico back">☕</span>
              <div><b>后端</b><small>Spring Boot · MyBatis-Plus · Java 17</small></div>
            </div>
            <div class="tech-item">
              <span class="tech-ico db">🗄️</span>
              <div><b>数据库</b><small>MySQL · 分类 / 地点 / 用户 / 成绩</small></div>
            </div>
          </div>
          <p class="tech-foot">🍍 数据来自 Spring Boot + MySQL</p>
        </div>
      </section>

      <!-- ============ 玩法指南 ============ -->
      <section class="block guide-block">
        <div class="block-head">
          <h2>新手指南</h2>
          <p>三步上手，快乐出发。</p>
        </div>
        <div class="steps">
          <div class="step">
            <span class="step-no">1</span>
            <div>
              <h3>逛图鉴</h3>
              <p>在首页搜索或按分类、分级筛选，点开卡片看详情，还能顺手打个分。</p>
            </div>
          </div>
          <div class="step-arrow">›</div>
          <div class="step">
            <span class="step-no">2</span>
            <div>
              <h3>玩一局</h3>
              <p>去海底游乐场挑个小游戏，翻牌、接蟹堡、答题，总有一款适合你。</p>
            </div>
          </div>
          <div class="step-arrow">›</div>
          <div class="step">
            <span class="step-no">3</span>
            <div>
              <h3>冲榜单</h3>
              <p>成绩自动记到账号，段位从「铁铲学徒」一路升到「蟹堡王之星」。</p>
            </div>
          </div>
        </div>
      </section>

      <!-- ============ 彩蛋 footer ============ -->
      <section class="footer-note">
        <span>🐚</span>
        <p>准备好螺蛳粉……啊不，蟹黄堡了吗？<br><small>比奇堡 · 一个用爱发电的海底小站 · 造于菠萝屋</small></p>
        <span>⭐</span>
      </section>
    </main>
  </div>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import OceanBackdrop from './OceanBackdrop.vue'
import PageNav from './PageNav.vue'
import { getNickname } from '../utils/auth.js'

defineEmits(['logout'])

const router = useRouter()
const displayName = computed(() => getNickname() || '海绵宝宝')

const features = [
  {
    key: 'home', no: '01', icon: '🏠', name: '比奇堡图鉴', tag: '探索 · 搜索 · 评分',
    desc: '收录比奇堡的地点与角落，按分类、分级、热度筛选，点开详情还能评分、涨浏览。',
    accent: '#ffca28', accent2: '#ff8f00', to: { name: 'home' }
  },
  {
    key: 'work', no: '02', icon: '🧽', name: '打工日常', tag: '剧情 · 互动',
    desc: '跟着海绵宝宝和章鱼哥体验蟹堡王的打工日常，做选择、看故事，剧情由你推进。',
    accent: '#4fc3f7', accent2: '#0288d1', to: { name: 'work' }
  },
  {
    key: 'games', no: '03', icon: '🎮', name: '海底游乐场', tag: '4 款小游戏 · 排行榜',
    desc: '出餐大作战、记忆翻牌、接蟹堡、知识问答——四款小游戏，各有独立排行榜。',
    accent: '#66bb6a', accent2: '#2e7d32', to: { name: 'games' }
  },
  {
    key: 'admin', no: '04', icon: '🛠️', name: '数据管理后台', tag: '管理员专属',
    desc: '管理员可以在这里维护分类、地点和用户数据，图鉴内容都由它支撑。（需管理员权限）',
    accent: '#ab7be8', accent2: '#7e3fc7', to: { name: 'admin' }
  }
]

const grades = [
  { code: 'S', label: '必去', color: '#ffb300' },
  { code: 'A', label: '推荐', color: '#40c4ff' },
  { code: 'B', label: '不错', color: '#66bb6a' },
  { code: 'C', label: '一般', color: '#90a4ae' }
]

function go(to) {
  router.push(to)
}

// 头部漂浮小气泡：位置 / 大小 / 时长错开，柔和不抢眼
function bubbleStyle(n) {
  const left = 6 + ((n * 37) % 88)
  const size = 8 + ((n * 13) % 22)
  const delay = ((n * 1.7) % 9).toFixed(1)
  const duration = (12 + (n % 5) * 3) + 's'
  return {
    left: left + '%',
    width: size + 'px',
    height: size + 'px',
    animationDelay: delay + 's',
    animationDuration: duration
  }
}

onMounted(() => {
  document.title = '关于比奇堡 · 海绵宝宝'
})
</script>

<style scoped>
.about { min-height: 100vh; position: relative; }
.main {
  position: relative;
  z-index: 2;
  max-width: 1180px;
  margin: 0 auto;
  padding: 40px 20px 80px;
}

/* ============ 头部 ============ */
.hero { text-align: center; margin-bottom: 30px; position: relative; }
.hero-bubbles { position: absolute; inset: 0; overflow: hidden; pointer-events: none; }
.hb {
  position: absolute;
  bottom: -20px;
  border-radius: 50%;
  background: radial-gradient(circle at 32% 28%, rgba(255,255,255,.85), rgba(126,226,255,.25) 55%, rgba(126,226,255,.05));
  border: 1px solid rgba(255,255,255,.5);
  box-shadow: inset 0 0 6px rgba(255,255,255,.6);
  animation: hb-rise linear infinite;
  opacity: .55;
}
@keyframes hb-rise {
  0% { transform: translateY(0) scale(.8); opacity: 0; }
  12% { opacity: .55; }
  85% { opacity: .4; }
  100% { transform: translateY(-320px) scale(1.15); opacity: 0; }
}
.hero-kicker {
  display: inline-block;
  font-size: 13px;
  letter-spacing: 2px;
  color: #b9e6ff;
  background: rgba(3, 46, 76, 0.6);
  border: 1px solid rgba(126, 226, 255, 0.4);
  padding: 6px 16px;
  border-radius: 999px;
  margin-bottom: 14px;
}
.title {
  font-size: clamp(34px, 6vw, 58px);
  color: #ffe082;
  letter-spacing: 6px;
  text-shadow: 0 3px 0 #c17900, 0 6px 0 rgba(0,0,0,.15), 0 0 30px rgba(255,213,79,.5);
  margin-bottom: 12px;
}
.sub { color: #eaf7ff; font-size: 16px; text-shadow: 0 2px 4px rgba(1,26,44,.6); }

/* ============ 本站简介 ============ */
.intro-card {
  position: relative;
  display: flex;
  gap: 22px;
  align-items: flex-start;
  padding: 26px 28px;
  border-radius: 26px;
  border: 2px solid rgba(255, 255, 255, 0.6);
  background:
    radial-gradient(circle at 12% 10%, rgba(255,255,255,.4), transparent 40%),
    linear-gradient(150deg, rgba(255,255,255,.94), rgba(226,244,255,.9));
  box-shadow: inset 0 2px 0 #fff, 0 8px 0 rgba(4,74,110,.32), 0 22px 42px rgba(1,26,44,.4);
  margin-bottom: 46px;
}
.intro-logo {
  width: 76px; height: 76px; flex-shrink: 0;
  display: grid; place-items: center;
  font-size: 42px; border-radius: 22px;
  background: linear-gradient(150deg, #ffd54f, #ff9f00);
  border: 3px solid #fff;
  box-shadow: 0 4px 0 rgba(0,0,0,.15), inset 0 2px 6px rgba(255,255,255,.6), 0 0 22px rgba(255,193,7,.55);
}
.intro-body h2 { font-size: 22px; color: #06476e; letter-spacing: 1px; margin-bottom: 8px; }
.intro-body p { font-size: 14.5px; line-height: 1.8; color: #33596f; }
.intro-body p b { color: #c17900; }
.intro-tags { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 14px; }
.intro-tags span {
  font-size: 12px; font-weight: bold; color: #0a5c86;
  background: rgba(126,226,255,.18);
  border: 1px solid rgba(6,71,110,.18);
  padding: 4px 12px; border-radius: 999px;
}

/* ============ 通用板块标题 ============ */
.block { margin-bottom: 46px; }
.block-head { text-align: center; margin-bottom: 22px; }
.block-head h2 {
  display: inline-block;
  font-size: 26px; color: #ffe082; letter-spacing: 2px;
  text-shadow: 0 2px 0 #c17900, 0 0 18px rgba(255,213,79,.4);
}
.block-head p { color: #cdeaff; font-size: 14px; margin-top: 8px; }

/* ============ 功能卡片 ============ */
.feature-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
.feature-card {
  position: relative;
  padding: 22px 24px 20px;
  border-radius: 24px;
  border: 2px solid rgba(255,255,255,.55);
  background:
    radial-gradient(circle at 85% 12%, var(--accent), transparent 46%),
    linear-gradient(150deg, rgba(255,255,255,.94), rgba(232,246,255,.9));
  box-shadow: inset 0 2px 0 #fff, 0 8px 0 rgba(4,74,110,.32), 0 20px 38px rgba(1,26,44,.38);
  cursor: pointer;
  overflow: hidden;
  transition: transform .28s cubic-bezier(.2,1.3,.4,1), box-shadow .28s;
}
.feature-card:hover {
  transform: translateY(-9px) rotate(-.3deg);
  box-shadow: inset 0 2px 0 #fff, 0 14px 0 rgba(4,74,110,.3), 0 32px 52px rgba(1,26,44,.5), 0 0 34px var(--accent);
}
.fc-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; }
.fc-icon {
  width: 58px; height: 58px; display: grid; place-items: center;
  font-size: 32px; border-radius: 18px;
  background: linear-gradient(150deg, var(--accent), var(--accent2));
  border: 3px solid #fff;
  box-shadow: 0 4px 0 rgba(0,0,0,.14), inset 0 2px 5px rgba(255,255,255,.55);
}
.fc-no { font-size: 26px; font-weight: bold; color: rgba(6,71,110,.14); }
.feature-card h3 { font-size: 20px; color: #06476e; letter-spacing: 1px; margin-bottom: 6px; }
.feature-card p { font-size: 13.5px; line-height: 1.6; color: #3a6076; min-height: 64px; }
.fc-foot { display: flex; align-items: center; justify-content: space-between; margin-top: 12px; }
.fc-tag {
  font-size: 12px; padding: 3px 11px; border-radius: 999px;
  background: rgba(6,71,110,.09); color: #0a5c86; border: 1px solid rgba(6,71,110,.18);
}
.fc-go { font-size: 13px; font-weight: bold; color: #fff; background: linear-gradient(180deg, var(--accent), var(--accent2)); padding: 5px 13px; border-radius: 999px; box-shadow: 0 2px 0 rgba(0,0,0,.16); }

/* ============ 两栏面板 ============ */
.two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 46px; }
.info-panel {
  padding: 24px 26px; border-radius: 24px;
  border: 2px solid rgba(126,226,255,.4);
  background: rgba(3,46,76,.58);
  backdrop-filter: blur(8px);
  box-shadow: inset 0 2px 0 rgba(255,255,255,.12), 0 16px 34px rgba(1,26,44,.35);
}
.info-panel h2 { font-size: 20px; color: #ffe082; letter-spacing: 1px; margin-bottom: 6px; }
.panel-sub { font-size: 13px; color: #b9e6ff; margin-bottom: 18px; }
.grade-row { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 18px; }
.grade-pill {
  font-size: 12px; color: #eaf7ff; padding: 5px 12px; border-radius: 999px;
  background: rgba(255,255,255,.08); border: 1.5px solid var(--gc);
}
.grade-pill b { color: var(--gc); font-size: 14px; margin-right: 2px; }
.fact-list { list-style: none; display: grid; gap: 11px; }
.fact-list li { font-size: 13.5px; color: #d9f2ff; display: flex; gap: 10px; align-items: center; }
.fact-list li span { font-size: 17px; width: 22px; text-align: center; }

.tech-list { display: grid; gap: 12px; }
.tech-item { display: flex; gap: 12px; align-items: center; }
.tech-ico {
  width: 44px; height: 44px; flex-shrink: 0; display: grid; place-items: center;
  font-size: 22px; border-radius: 13px; border: 2px solid rgba(255,255,255,.5);
  box-shadow: inset 0 2px 5px rgba(255,255,255,.4);
}
.tech-ico.front { background: linear-gradient(150deg,#64b5f6,#1976d2); }
.tech-ico.back { background: linear-gradient(150deg,#ffb74d,#f57c00); }
.tech-ico.db { background: linear-gradient(150deg,#81c784,#388e3c); }
.tech-item div { display: flex; flex-direction: column; line-height: 1.35; }
.tech-item b { font-size: 14.5px; color: #fff; }
.tech-item small { font-size: 12px; color: #b9e6ff; }
.tech-foot { margin-top: 16px; font-size: 12px; color: #8fd0f0; text-align: center; }

/* ============ 新手指南 ============ */
.steps {
  display: flex; align-items: stretch; gap: 10px;
  padding: 24px; border-radius: 24px;
  border: 2px solid rgba(255,255,255,.5);
  background: linear-gradient(150deg, rgba(255,255,255,.92), rgba(226,244,255,.86));
  box-shadow: inset 0 2px 0 #fff, 0 10px 0 rgba(4,74,110,.28), 0 22px 40px rgba(1,26,44,.35);
}
.step { flex: 1; display: flex; gap: 12px; align-items: flex-start; }
.step-no {
  width: 40px; height: 40px; flex-shrink: 0; display: grid; place-items: center;
  font-size: 20px; font-weight: bold; color: #5d3700;
  background: linear-gradient(180deg,#ffd54f,#ffb300);
  border: 3px solid #fff; border-radius: 50%;
  box-shadow: 0 3px 0 #c17900;
}
.step h3 { font-size: 16px; color: #06476e; margin-bottom: 5px; }
.step p { font-size: 13px; line-height: 1.6; color: #3a6076; }
.step-arrow { align-self: center; font-size: 30px; color: #ffb300; font-weight: bold; }

/* ============ 底部 ============ */
.footer-note {
  margin-top: 46px; text-align: center;
  display: flex; flex-direction: column; align-items: center; gap: 8px;
  color: #d9f2ff; text-shadow: 0 2px 4px rgba(1,26,44,.6);
}
.footer-note > span { font-size: 26px; }
.footer-note p { font-size: 15px; line-height: 1.7; }
.footer-note small { font-size: 12px; color: #8fd0f0; }

@media (max-width: 900px) {
  .feature-grid, .two-col { grid-template-columns: 1fr; }
  .steps { flex-direction: column; }
  .step-arrow { align-self: center; transform: rotate(90deg); }
}
@media (max-width: 560px) {
  .intro-card { flex-direction: column; align-items: center; text-align: center; }
}
</style>
