<template>
  <div class="ach-page">
    <OceanBackdrop />
    <PageNav active="profile" :nickname="displayName" @logout="$emit('logout')" />

    <main class="main">
      <section class="hero">
        <span class="hero-kicker">🏅 比奇堡荣誉墙</span>
        <h1 class="title">成就徽章</h1>
        <p class="sub">每一次尝试都算数，看看你收集了多少闪亮徽章。</p>
      </section>

      <!-- 总进度 -->
      <section class="progress-card">
        <div class="pc-left">
          <span class="pc-badge">🎖️</span>
          <div>
            <h2>已完成 {{ done }}/{{ total }}</h2>
            <p>解锁全部徽章，成为真正的比奇堡之星！</p>
          </div>
        </div>
        <div class="pc-right">
          <div class="pc-num">{{ percent }}%</div>
          <div class="bar"><div class="bar-fill" :style="{ width: percent + '%' }"></div></div>
        </div>
      </section>

      <!-- 徽章网格 -->
      <section class="badge-grid">
        <article
          v-for="a in list"
          :key="a.code"
          class="badge"
          :class="{ got: a.unlocked }"
          @click="select(a)"
        >
          <div class="b-glow"></div>
          <div class="b-icon">{{ a.unlocked ? a.emoji : '🔒' }}</div>
          <h3>{{ a.unlocked ? a.name : '???' }}</h3>
          <p class="b-desc">{{ a.desc }}</p>
          <div class="b-progress">
            <div class="b-bar"><div :style="{ width: a.percent + '%' }"></div></div>
            <span>{{ a.current }}/{{ a.goal }}</span>
          </div>
          <span v-if="a.unlocked" class="b-check">✓ 已达成</span>
        </article>
      </section>

      <p class="foot-note">提示：徽章进度根据你的游戏、图鉴、签到、水母与留言实时计算</p>
    </main>

    <!-- 详情弹窗 -->
    <div v-if="detail" class="mask" @click.self="detail = null">
      <div class="dialog">
        <div class="d-icon">{{ detail.unlocked ? detail.emoji : '🔒' }}</div>
        <h3>{{ detail.unlocked ? detail.name : '尚未解锁' }}</h3>
        <p class="d-desc">{{ detail.desc }}</p>
        <div class="d-line"><span>达成进度</span><b>{{ detail.current }} / {{ detail.goal }}</b></div>
        <div class="b-bar big"><div :style="{ width: detail.percent + '%' }"></div></div>
        <p class="d-hint">{{ detail.unlocked ? '🎉 恭喜，这枚徽章属于你了！' : '💡 ' + detail.hint }}</p>
        <button class="ghost" @click="detail = null">关闭</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import OceanBackdrop from './OceanBackdrop.vue'
import PageNav from './PageNav.vue'
import { getNickname } from '../utils/auth.js'
import { computeProgress, syncUnlocked, getAchievementSummary } from '../utils/achievements.js'

defineEmits(['logout'])
const displayName = computed(() => getNickname() || '海绵宝宝')

const list = ref([])
const done = ref(0)
const total = ref(0)
const percent = ref(0)
const detail = ref(null)

function load() {
  syncUnlocked()
  list.value = computeProgress()
  const s = getAchievementSummary()
  done.value = s.unlocked
  total.value = s.total
  percent.value = s.percent
}

function select(a) { detail.value = a }

onMounted(() => {
  document.title = '成就徽章 · 海绵宝宝'
  load()
})
</script>

<style scoped>
.ach-page { min-height: 100vh; position: relative; }
.main { position: relative; z-index: 2; max-width: 1000px; margin: 0 auto; padding: 40px 20px 80px; }
.hero { text-align: center; margin-bottom: 26px; }
.hero-kicker { display: inline-block; font-size: 13px; letter-spacing: 2px; color: #b9e6ff; background: rgba(3,46,76,.6); border: 1px solid rgba(126,226,255,.4); padding: 6px 16px; border-radius: 999px; margin-bottom: 12px; }
.title { font-size: clamp(32px,6vw,52px); color: #ffe082; letter-spacing: 5px; text-shadow: 0 3px 0 #c17900, 0 0 30px rgba(255,213,79,.5); margin-bottom: 8px; }
.sub { color: #eaf7ff; font-size: 15px; }

.progress-card { display: flex; align-items: center; justify-content: space-between; gap: 24px; background: linear-gradient(135deg, rgba(255,213,79,.94), rgba(255,167,0,.9)); border: 3px solid #fff; border-radius: 24px; padding: 22px 28px; box-shadow: 0 8px 0 rgba(193,121,0,.5), 0 20px 40px rgba(1,26,44,.35); margin-bottom: 26px; }
.pc-left { display: flex; align-items: center; gap: 16px; }
.pc-badge { font-size: 48px; }
.pc-left h2 { color: #5d3700; font-size: 22px; }
.pc-left p { color: #7a5200; font-size: 13px; margin-top: 4px; }
.pc-right { min-width: 180px; text-align: right; }
.pc-num { color: #5d3700; font-size: 26px; font-weight: bold; }
.bar, .b-bar { height: 10px; background: rgba(93,55,0,.2); border-radius: 999px; overflow: hidden; margin-top: 6px; }
.bar-fill { height: 100%; background: #fff; border-radius: 999px; transition: width .5s; box-shadow: 0 0 10px #fff; }

.badge-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }
.badge { position: relative; text-align: center; padding: 22px 14px 18px; border-radius: 22px; background: rgba(120,140,155,.16); border: 2px solid rgba(150,170,180,.3); cursor: pointer; overflow: hidden; transition: transform .2s; }
.badge:hover { transform: translateY(-5px); }
.badge.got { background: rgba(255,255,255,.94); border-color: #ffd54f; box-shadow: 0 5px 0 rgba(193,121,0,.4), 0 0 22px rgba(255,213,79,.35); }
.b-glow { display: none; }
.badge.got .b-glow { display: block; position: absolute; right: -30px; top: -30px; width: 120px; height: 120px; border-radius: 50%; background: radial-gradient(circle, rgba(255,213,79,.5), transparent 65%); }
.b-icon { font-size: 44px; filter: grayscale(1); opacity: .5; }
.badge.got .b-icon { filter: none; opacity: 1; }
.badge h3 { font-size: 16px; color: #8a9aa4; margin: 8px 0 4px; }
.badge.got h3 { color: #0a5c86; }
.b-desc { font-size: 12px; color: #7a8f9c; min-height: 34px; line-height: 1.4; }
.badge.got .b-desc { color: #3a6076; }
.b-progress { display: flex; align-items: center; gap: 8px; margin-top: 10px; }
.b-bar { flex: 1; margin: 0; background: rgba(120,140,155,.25); }
.badge.got .b-bar { background: rgba(6,71,110,.15); }
.b-bar > div { height: 100%; background: #90a4ae; border-radius: 999px; transition: width .4s; }
.badge.got .b-bar > div { background: linear-gradient(90deg,#ffb300,#ffd54f); }
.b-progress span { font-size: 11px; color: #7a8f9c; white-space: nowrap; }
.badge.got .b-progress span { color: #f57f17; font-weight: bold; }
.b-check { position: absolute; top: 10px; right: 10px; font-size: 10px; color: #fff; background: #ffb300; padding: 3px 8px; border-radius: 999px; }
.foot-note { text-align: center; color: #8fdcff; font-size: 12px; margin-top: 26px; opacity: .85; }

.mask { position: fixed; inset: 0; z-index: 80; display: grid; place-items: center; padding: 20px; background: rgba(2,20,36,.65); backdrop-filter: blur(4px); }
.dialog { width: min(380px,100%); text-align: center; background: linear-gradient(160deg,#fffdf5,#eaf8ff); border: 3px solid #ffd54f; border-radius: 22px; padding: 26px; box-shadow: 0 12px 0 rgba(193,121,0,.4), 0 30px 60px rgba(0,0,0,.5); }
.d-icon { font-size: 54px; }
.dialog h3 { color: #0a5c86; font-size: 21px; margin: 6px 0; }
.d-desc { color: #3a6076; font-size: 14px; }
.d-line { display: flex; justify-content: space-between; color: #5a7a8a; font-size: 13px; margin-top: 14px; }
.d-line b { color: #f57f17; }
.b-bar.big { height: 12px; background: rgba(6,71,110,.15); margin-top: 6px; }
.b-bar.big > div { background: linear-gradient(90deg,#ffb300,#ffd54f); }
.d-hint { color: #5a7a8a; font-size: 13px; margin: 16px 0; }
.ghost { border: 2px solid #ffb300; background: #fff; color: #f57f17; font-family: inherit; font-size: 14px; font-weight: bold; padding: 8px 26px; border-radius: 999px; cursor: pointer; }
.ghost:hover { background: #fff8e1; }

@media (max-width: 760px) { .badge-grid { grid-template-columns: repeat(2, 1fr); } .progress-card { flex-direction: column; align-items: stretch; } .pc-right { text-align: left; } }
</style>
