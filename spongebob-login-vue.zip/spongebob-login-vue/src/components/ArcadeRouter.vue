<template>
  <component :is="current" @logout="$emit('logout')" />
</template>

<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import MemoryGame from './MemoryGame.vue'
import CatchGame from './CatchGame.vue'
import QuizGame from './QuizGame.vue'
import PuzzleGame from './PuzzleGame.vue'
import BubbleGame from './BubbleGame.vue'

defineEmits(['logout'])
const route = useRoute()

const map = {
  memory: MemoryGame,
  catch: CatchGame,
  quiz: QuizGame,
  puzzle: PuzzleGame,
  bubble: BubbleGame
}

const current = computed(() => map[route.query.game] || MemoryGame)
</script>
