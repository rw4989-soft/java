<template>
  <div class="mini-game">
    <OceanBackdrop />
    <PageNav active="game" :nickname="displayName" @logout="$emit('logout')" />

    <main class="main">
      <router-link to="/games" class="back">‹ 游戏中心</router-link>

      <section class="head">
        <span class="g-icon">🫧</span>
        <div>
          <h1>泡泡大作战</h1>
          <p>25 秒内戳破尽可能多的泡泡！连击有加成，但别碰到水雷。</p>
        </div>
      </section>

      <section v-if="phase === 'idle'" class="start-panel">
        <div class="preview-bubbles" aria-hidden="true">
          <span v-for="i in 7" :key="i" :style="{ animationDelay: (i * 0.3) + 's', left: (i * 12) + '%' }">🫧</span>
        </div>
        <h2>一起来戳泡泡！</h2>
        <p>🎈 普通泡泡 +10 · 💛 金泡泡 +30 · 💣 水雷 -20</p>
        <button class="cta" @click="start">开始戳泡泡</button>
        <GameLeaderboard :board="board" :loading="loading" title="泡泡" />
      </section>

      <section v-else class="play-panel">
        <div class="hud">
          <div class="hs"><span>得分</span><b>{{ score }}</b></div>
          <div class="hs"><span>剩余</span><b>{{ timeLeft }}s</b></div>
          <div class="hs"><span>连击</span><b>×{{ combo }}</b></div>
          <button class="quit" @click="phase = 'idle'">结束</button>
        </div>

        <div class="field" @click="spawnBurst">
          <button
            v-for="b in bubbles"
            :key="b.id"
            type="button"
            class="bubble"
            :class="b.kind"
            :style="{ left: b.x + '%', width: b.size + 'px', height: b.size + 'px', animationDuration: b.dur + 's' }"
            @click.stop="pop(b)"
          >{{ b.icon }}</button>
          <div v-for="f in floats" :key="f.id" class="float" :style="{ left: f.x + '%', top: f.y + '%' }">{{ f.text }}</div>
        </div>
        <p class="tip">点击泡泡得分 · 躲开水雷 💣</p>
      </section>

      <div v-if="phase === 'done'" class="overlay" @click.self="phase = 'idle'">
        <div class="result-card">
          <div class="r-emoji">{{ isNewRecord ? '🏆' : '🎉' }}</div>
          <h2>{{ isNewRecord ? '新纪录！' : '时间到！' }}</h2>
          <div class="r-score">{{ finalScore }} <small>分</small></div>
          <p>最高连击 ×{{ maxCombo }} · 戳破 {{ popped }} 个</p>
          <p v-if="saved" class="r-saved">成绩已记录 ✓</p>
          <div class="r-btns">
            <button class="cta small" @click="start">再来一局</button>
            <button class="ghost" @click="phase = 'idle'">看排行榜</button>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { computed, onUnmounted, ref } from 'vue'
import OceanBackdrop from './OceanBackdrop.vue'
import PageNav from './PageNav.vue'
import GameLeaderboard from './GameLeaderboard.vue'
import { getNickname } from '../utils/auth.js'
import { useGameBoard } from '../utils/useGameBoard.js'
import { sfx } from '../utils/sound.js'

defineEmits(['logout'])
const displayName = computed(() => getNickname() || '海绵宝宝')
const { board, loading, commit } = useGameBoard('bubble')

const phase = ref('idle')
const score = ref(0)
const combo = ref(0)
const maxCombo = ref(0)
const timeLeft = ref(25)
const popped = ref(0)
const bubbles = ref([])
const floats = ref([])
const finalScore = ref(0)
const isNewRecord = ref(false)
const saved = ref(false)
let spawnTimer = null
let tickTimer = null
let uid = 0

function makeBubble() {
  const roll = Math.random()
  const kind = roll < 0.12 ? 'mine' : roll < 0.3 ? 'gold' : 'normal'
  const icon = kind === 'mine' ? '💣' : kind === 'gold' ? '💛' : '🫧'
  const size = kind === 'mine' ? 52 : 44 + Math.floor(Math.random() * 26)
  return {
    id: ++uid, kind, icon, size,
    x: 4 + Math.random() * 88,
    dur: (3.2 + Math.random() * 2).toFixed(1)
  }
}

function addFloat(x, text) {
  const id = ++uid
  floats.value.push({ id, x, y: 70 + Math.random() * 10, text })
  setTimeout(() => { floats.value = floats.value.filter(f => f.id !== id) }, 800)
}

function pop(b) {
  if (phase.value !== 'playing') return
  bubbles.value = bubbles.value.filter(x => x.id !== b.id)
  if (b.kind === 'mine') {
    score.value = Math.max(0, score.value - 20)
    combo.value = 0
    sfx.bad()
    addFloat(b.x, '-20 💣')
    return
  }
  combo.value++
  maxCombo.value = Math.max(maxCombo.value, combo.value)
  const base = b.kind === 'gold' ? 30 : 10
  const gain = base + Math.max(0, combo.value - 1) * 2
  score.value += gain
  popped.value++
  if (b.kind === 'gold') sfx.coin(); else sfx.good()
  addFloat(b.x, '+' + gain)
}

function spawnBurst() {
  if (phase.value !== 'playing') return
  bubbles.value.push(makeBubble())
}

function start() {
  clearInterval(spawnTimer)
  clearInterval(tickTimer)
  score.value = 0
  combo.value = 0
  maxCombo.value = 0
  timeLeft.value = 25
  popped.value = 0
  bubbles.value = []
  floats.value = []
  saved.value = false
  phase.value = 'playing'
  for (let i = 0; i < 5; i++) bubbles.value.push(makeBubble())
  spawnTimer = setInterval(() => {
    if (bubbles.value.length < 9) bubbles.value.push(makeBubble())
  }, 480)
  tickTimer = setInterval(() => {
    timeLeft.value--
    if (timeLeft.value <= 0) finish()
  }, 1000)
}

async function finish() {
  clearInterval(spawnTimer)
  clearInterval(tickTimer)
  bubbles.value = []
  finalScore.value = score.value
  isNewRecord.value = finalScore.value > (board.value.bestScore || 0)
  phase.value = 'done'
  sfx.win()
  try {
    await commit({ score: finalScore.value, combo: maxCombo.value, count: popped.value })
    saved.value = true
  } catch (e) { /* 提交失败不影响结算 */ }
}

onUnmounted(() => {
  clearInterval(spawnTimer)
  clearInterval(tickTimer)
})
</script>

<style scoped>
.mini-game { min-height: 100vh; position: relative; }
.main { position: relative; z-index: 2; max-width: 720px; margin: 0 auto; padding: 32px 20px 80px; }
.back { display: inline-block; color: #b9e6ff; text-decoration: none; font-size: 14px; margin-bottom: 16px; }
.back:hover { color: #ffe082; }
.head { display: flex; align-items: center; gap: 16px; margin-bottom: 24px; }
.g-icon { font-size: 48px; filter: drop-shadow(0 4px 6px rgba(0,0,0,.3)); }
.head h1 { font-size: 28px; color: #ffe082; letter-spacing: 2px; text-shadow: 0 3px 0 #c17900; margin-bottom: 4px; }
.head p { color: #d9f2ff; font-size: 14px; line-height: 1.5; }

.start-panel { text-align: center; background: rgba(3,46,76,.55); border: 2px solid rgba(126,226,255,.35); border-radius: 24px; padding: 32px 24px; backdrop-filter: blur(6px); }
.preview-bubbles { position: relative; height: 60px; margin-bottom: 12px; }
.preview-bubbles span { position: absolute; bottom: 0; font-size: 30px; animation: floatUp 2.4s ease-in infinite; }
@keyframes floatUp { 0% { transform: translateY(20px); opacity: 0; } 40% { opacity: 1; } 100% { transform: translateY(-40px); opacity: 0; } }
.start-panel h2 { color: #fff8e1; font-size: 22px; margin-bottom: 8px; }
.start-panel > p { color: #b9e6ff; font-size: 14px; margin-bottom: 20px; }

.cta { border: none; background: linear-gradient(180deg,#ffd54f,#ffb300); color: #5d3700; font-family: inherit; font-size: 16px; font-weight: bold; padding: 12px 34px; border-radius: 999px; cursor: pointer; box-shadow: 0 4px 0 #c17900, 0 0 22px rgba(255,193,7,.5); transition: transform .18s, filter .18s; }
.cta:hover { transform: translateY(-2px); filter: brightness(1.06); }
.cta.small { font-size: 14px; padding: 9px 22px; }
.ghost { border: 2px solid rgba(126,226,255,.5); background: transparent; color: #b9e6ff; font-family: inherit; font-size: 14px; padding: 8px 20px; border-radius: 999px; cursor: pointer; }
.ghost:hover { background: rgba(126,226,255,.18); color: #fff; }

.play-panel { background: rgba(3,46,76,.5); border: 2px solid rgba(126,226,255,.3); border-radius: 24px; padding: 20px; backdrop-filter: blur(6px); }
.hud { display: flex; gap: 10px; align-items: center; margin-bottom: 16px; flex-wrap: wrap; }
.hs { flex: 1; min-width: 70px; background: rgba(126,226,255,.12); border: 1px solid rgba(126,226,255,.3); border-radius: 12px; padding: 8px 10px; text-align: center; }
.hs span { display: block; font-size: 11px; color: #8fdcff; }
.hs b { font-size: 20px; color: #ffe082; }
.quit { border: 2px solid rgba(255,193,7,.5); background: rgba(255,193,7,.12); color: #ffe082; font-family: inherit; font-size: 13px; font-weight: bold; padding: 8px 16px; border-radius: 999px; cursor: pointer; }

.field { position: relative; height: 420px; border-radius: 18px; overflow: hidden; background: linear-gradient(180deg, rgba(2,40,66,.5), rgba(3,60,90,.35)); border: 1px solid rgba(126,226,255,.25); cursor: crosshair; }
.bubble { position: absolute; bottom: -60px; border: 2px solid rgba(255,255,255,.7); border-radius: 50%; background: radial-gradient(circle at 32% 28%, rgba(255,255,255,.9), rgba(126,226,255,.35) 55%, rgba(126,226,255,.15)); font-size: 24px; display: grid; place-items: center; cursor: pointer; animation: rise linear forwards; box-shadow: inset -4px -6px 10px rgba(0,60,100,.2), 0 0 14px rgba(126,226,255,.5); }
.bubble.gold { background: radial-gradient(circle at 32% 28%, #fffde7, #ffd54f 60%, #ffb300); box-shadow: 0 0 18px rgba(255,213,79,.8); }
.bubble.mine { background: radial-gradient(circle at 32% 28%, #ffcdd2, #ef5350 60%, #b71c1c); border-color: rgba(255,205,210,.8); }
@keyframes rise { 0% { transform: translateY(0) scale(.85); opacity: 0; } 12% { opacity: 1; } 100% { transform: translateY(-490px) scale(1.05); opacity: 0; } }
.float { position: absolute; font-size: 18px; font-weight: bold; color: #ffe082; text-shadow: 0 2px 4px rgba(0,0,0,.5); animation: floatText .8s ease-out forwards; pointer-events: none; }
@keyframes floatText { 0% { transform: translateY(0); opacity: 1; } 100% { transform: translateY(-50px); opacity: 0; } }
.tip { text-align: center; color: #b9e6ff; font-size: 13px; margin-top: 14px; }

.overlay { position: absolute; inset: 0; z-index: 20; display: grid; place-items: center; padding: 20px; background: rgba(2,20,36,.6); backdrop-filter: blur(4px); border-radius: 24px; }
.result-card { width: min(360px,100%); text-align: center; background: linear-gradient(160deg,#fffdf5,#eaf8ff); border: 3px solid #ffd54f; border-radius: 24px; padding: 28px; box-shadow: 0 10px 0 rgba(193,121,0,.4), 0 24px 50px rgba(0,0,0,.5); }
.r-emoji { font-size: 46px; }
.result-card h2 { color: #0a5c86; font-size: 22px; margin: 6px 0; }
.r-score { font-size: 44px; font-weight: bold; color: #f57f17; }
.r-score small { font-size: 16px; }
.result-card p { color: #4a6b7d; font-size: 14px; margin: 4px 0; }
.r-saved { color: #2e7d32 !important; }
.r-btns { display: flex; gap: 10px; justify-content: center; margin-top: 18px; }

@media (max-width: 520px) { .r-btns { flex-direction: column; } }
</style>
