<template>
  <div class="mini-game">
    <OceanBackdrop />
    <PageNav active="game" :nickname="displayName" @logout="$emit('logout')" />

    <main class="main">
      <router-link to="/games" class="back">‹ 游戏中心</router-link>

      <section class="head">
        <span class="g-icon">🧀</span>
        <div>
          <h1>接蟹堡大作战</h1>
          <p>点住掉下来的蟹堡，别碰垃圾！连击越高，分数越可观。</p>
        </div>
      </section>

      <!-- 开始 -->
      <section v-if="phase === 'idle'" class="start-panel">
        <div class="demo-row" aria-hidden="true">
          <span v-for="(e, i) in demoEmojis" :key="i" :style="{ animationDelay: (i * .35) + 's' }">{{ e }}</span>
        </div>
        <h2>20 秒限时挑战</h2>
        <p>🍔 蟹堡 +分　⭐ 金蟹堡 高分　🗑️ 垃圾 -分</p>
        <button class="cta" @click="start">开始接蟹堡</button>
        <GameLeaderboard :board="board" :loading="loading" title="接蟹堡" />
      </section>

      <!-- 游戏 -->
      <section v-else-if="phase === 'playing'" class="arena" ref="arena" @pointerdown="onPointerDown">
        <div class="hud">
          <div class="hs"><span>时间</span><b :class="{ urgent: timeLeft <= 5 }">{{ timeLeft }}s</b></div>
          <div class="hs"><span>得分</span><b>{{ score }}</b></div>
          <div class="hs"><span>连击</span><b :class="{ lit: combo >= 3 }">×{{ combo }}</b></div>
          <button class="quit" @click="endGame">结束</button>
        </div>

        <div class="field">
          <div
            v-for="item in items"
            :key="item.id"
            class="item"
            :class="item.kind"
            :style="{ left: item.x + '%', top: item.y + '%' }"
            @pointerdown.stop="hit(item, $event)"
          >{{ item.emoji }}</div>

          <div v-for="p in pops" :key="p.id" class="pop" :style="{ left: p.x + '%', top: p.y + '%' }">{{ p.text }}</div>
        </div>
        <div class="basket">🧺</div>
      </section>

      <!-- 结算 -->
      <div v-if="phase === 'done'" class="overlay" @click.self="closeResult">
        <div class="result-card">
          <div class="r-emoji">{{ newRecord ? '🏆' : '🎉' }}</div>
          <h2>{{ newRecord ? '新纪录！' : '挑战完成！' }}</h2>
          <div class="r-score">{{ finalScore }} <small>分</small></div>
          <p>接到 {{ finalCaught }} 个 · 最高连击 ×{{ finalCombo }}</p>
          <p v-if="saved" class="r-saved">成绩已记录 ✓</p>
          <div class="r-btns">
            <button class="cta small" @click="start">再来一局</button>
            <button class="ghost" @click="closeResult">看排行榜</button>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import OceanBackdrop from './OceanBackdrop.vue'
import PageNav from './PageNav.vue'
import GameLeaderboard from './GameLeaderboard.vue'
import { getNickname } from '../utils/auth.js'
import { useGameBoard } from '../utils/useGameBoard.js'

defineEmits(['logout'])
const displayName = computed(() => getNickname() || '海绵宝宝')
const { board, loading, lastResult, commit } = useGameBoard('catch')

const demoEmojis = ['🍔', '⭐', '🗑️', '🍔', '⭐']
const phase = ref('idle')
const arena = ref(null)
const items = ref([])
const pops = ref([])
const score = ref(0)
const combo = ref(0)
const timeLeft = ref(20)
const caught = ref(0)
let idSeed = 0
let spawnTimer = null
let tickTimer = null
let popSeed = 0

const finalScore = ref(0)
const finalCaught = ref(0)
const finalCombo = ref(0)
const newRecord = ref(false)
const saved = ref(false)

const KINDS = [
  { kind: 'good', emoji: '🍔', weight: 6, points: 10 },
  { kind: 'gold', emoji: '⭐', weight: 2, points: 30 },
  { kind: 'bad', emoji: '🗑️', weight: 3, points: -15 }
]

function pickKind() {
  const pool = KINDS.flatMap(k => Array(k.weight).fill(k))
  return pool[Math.floor(Math.random() * pool.length)]
}

function start() {
  items.value = []
  pops.value = []
  score.value = 0
  combo.value = 0
  timeLeft.value = 20
  caught.value = 0
  saved.value = false
  newRecord.value = false
  phase.value = 'playing'

  spawnTimer = setInterval(spawn, 520)
  tickTimer = setInterval(() => {
    // 漏掉的好东西断连击
    items.value = items.value.filter(it => it.y < 92)
    timeLeft.value--
    if (timeLeft.value <= 0) endGame()
  }, 1000)
}

function spawn() {
  const k = pickKind()
  items.value.push({
    id: ++idSeed,
    kind: k.kind,
    emoji: k.emoji,
    points: k.points,
    x: 6 + Math.random() * 84,
    y: -8
  })
  // 下落动画由 CSS 关键帧驱动
}

function hit(item, e) {
  if (phase.value !== 'playing') return
  items.value = items.value.filter(it => it.id !== item.id)
  const rect = arena.value?.getBoundingClientRect()
  const px = rect ? ((e.clientX - rect.left) / rect.width) * 100 : item.x
  const py = rect ? ((e.clientY - rect.top) / rect.height) * 100 : item.y

  if (item.kind === 'bad') {
    combo.value = 0
    score.value = Math.max(0, score.value + item.points)
    addPop(px, py, item.points + '', 'bad')
  } else {
    combo.value++
    const bonus = Math.min(combo.value, 10) * 2
    const gain = item.points + bonus
    score.value += gain
    caught.value++
    addPop(px, py, '+' + gain, item.kind === 'gold' ? 'gold' : 'good')
  }
}

function addPop(x, y, text, cls) {
  const p = { id: ++popSeed, x, y, text, cls }
  pops.value.push(p)
  setTimeout(() => { pops.value = pops.value.filter(v => v.id !== p.id) }, 700)
}

function onPointerDown() {
  // 点空白：连击清零（鼓励精准点击）
  if (phase.value === 'playing') combo.value = 0
}

async function endGame() {
  clearInterval(spawnTimer)
  clearInterval(tickTimer)
  finalScore.value = score.value
  finalCaught.value = caught.value
  finalCombo.value = combo.value
  phase.value = 'done'
  const r = await commit({ score: score.value, combo: combo.value, count: caught.value })
  saved.value = r.ok
  newRecord.value = Boolean(lastResult.value?.newRecord)
}

function reset() { clearInterval(spawnTimer); clearInterval(tickTimer); phase.value = 'idle' }
function closeResult() { phase.value = 'idle' }

onMounted(() => { document.title = '接蟹堡大作战 · 海绵宝宝' })
onUnmounted(() => { clearInterval(spawnTimer); clearInterval(tickTimer) })
</script>

<style scoped>
.mini-game { min-height: 100vh; position: relative; }
.main { position: relative; z-index: 2; max-width: 900px; margin: 0 auto; padding: 24px 20px 80px; }
.back { display: inline-block; color: #b9e6ff; text-decoration: none; font-size: 14px; margin-bottom: 16px; }
.back:hover { color: #ffe082; }
.head { display: flex; align-items: center; gap: 16px; margin-bottom: 24px; }
.g-icon { font-size: 50px; filter: drop-shadow(0 4px 6px rgba(1,26,44,.5)); }
.head h1 { font-size: 30px; color: #ffe082; letter-spacing: 2px; text-shadow: 0 2px 0 #c17900, 0 0 20px rgba(255,213,79,.4); }
.head p { color: #eaf7ff; font-size: 14px; margin-top: 4px; }

.start-panel { text-align: center; background: rgba(3,46,76,.55); border: 2px solid rgba(126,226,255,.35); border-radius: 28px; padding: 30px 24px; backdrop-filter: blur(8px); }
.demo-row { display: flex; justify-content: center; gap: 18px; margin-bottom: 14px; }
.demo-row span { font-size: 40px; animation: bob 1.6s ease-in-out infinite; }
@keyframes bob { 0%,100% { transform: translateY(0) } 50% { transform: translateY(-14px) } }
.start-panel h2 { color: #fff8e1; font-size: 24px; }
.start-panel > p { color: #b9e6ff; margin: 8px 0 20px; }
.cta { border: none; border-radius: 999px; padding: 13px 40px; font-family: inherit; font-size: 17px; font-weight: bold; color: #5d3700; background: linear-gradient(180deg,#ffd54f,#ffb300); box-shadow: 0 4px 0 #c17900, 0 8px 20px rgba(1,26,44,.4); cursor: pointer; transition: transform .2s, box-shadow .2s; }
.cta:hover { transform: translateY(-2px); box-shadow: 0 6px 0 #c17900, 0 0 24px rgba(255,213,79,.7); }
.cta.small { padding: 10px 26px; font-size: 15px; }

.arena { position: relative; height: 560px; background: rgba(3,46,76,.5); border: 2px solid rgba(126,226,255,.35); border-radius: 28px; padding: 16px; overflow: hidden; backdrop-filter: blur(8px); touch-action: manipulation; }
.hud { display: flex; gap: 12px; align-items: center; position: relative; z-index: 3; }
.hs { flex: 1; text-align: center; background: rgba(255,255,255,.12); border-radius: 14px; padding: 8px; }
.hs span { display: block; font-size: 11px; color: #b9e6ff; }
.hs b { display: block; font-size: 22px; color: #ffe082; }
.hs b.urgent { color: #ff8a80; animation: flash .5s infinite alternate; }
.hs b.lit { color: #ff7043; text-shadow: 0 0 10px #ff7043; }
@keyframes flash { to { opacity: .5; } }
.quit { border: 2px solid rgba(126,226,255,.5); background: rgba(126,226,255,.1); color: #eaf7ff; border-radius: 12px; padding: 8px 16px; font-family: inherit; font-weight: bold; cursor: pointer; }
.field { position: absolute; inset: 70px 16px 16px; z-index: 2; }
.item { position: absolute; font-size: 44px; cursor: pointer; user-select: none; filter: drop-shadow(0 4px 6px rgba(0,0,0,.4)); animation: fall 2.6s linear forwards; }
.item.gold { filter: drop-shadow(0 0 12px #ffd54f); }
.item.bad { filter: drop-shadow(0 4px 6px rgba(0,0,0,.5)) grayscale(.3); }
@keyframes fall { from { top: -8%; } to { top: 100%; } }
.pop { position: absolute; font-size: 22px; font-weight: bold; pointer-events: none; animation: popUp .7s ease-out forwards; z-index: 5; }
.pop.good { color: #c8ffc4; } .pop.gold { color: #ffe082; } .pop.bad { color: #ff8a80; }
@keyframes popUp { from { transform: translateY(0) scale(.8); opacity: 1; } to { transform: translateY(-50px) scale(1.2); opacity: 0; } }
.basket { position: absolute; bottom: 6px; left: 50%; transform: translateX(-50%); font-size: 46px; z-index: 1; }

.overlay { position: fixed; inset: 0; z-index: 100; display: grid; place-items: center; background: rgba(1,20,35,.65); backdrop-filter: blur(4px); padding: 20px; }
.result-card { width: min(380px, 100%); text-align: center; background: linear-gradient(160deg,#fffdf3,#fff3cf); border: 4px solid #ffe082; border-radius: 28px; padding: 30px 24px; box-shadow: 0 20px 50px rgba(0,0,0,.5); }
.r-emoji { font-size: 60px; }
.result-card h2 { color: #e65100; font-size: 26px; margin: 6px 0; }
.r-score { font-size: 52px; font-weight: bold; color: #f57f17; text-shadow: 0 2px 0 #ffd54f; }
.r-score small { font-size: 18px; }
.result-card p { color: #6d4c00; margin: 6px 0; }
.r-saved { color: #2e7d32 !important; font-weight: bold; }
.r-btns { display: flex; gap: 12px; justify-content: center; margin-top: 18px; }
.ghost { border: 2px solid #ffb300; background: #fff; color: #e65100; border-radius: 999px; padding: 9px 22px; font-family: inherit; font-weight: bold; cursor: pointer; }
.ghost:hover { background: #fff8e1; }
</style>
