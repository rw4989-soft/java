<template>
  <div class="characters-page">
    <OceanBackdrop />
    <PageNav active="characters" :nickname="displayName" @logout="$emit('logout')" />

    <main class="main">
      <!-- ============ 头部 ============ -->
      <section class="hero">
        <span class="hero-kicker">🤝 比奇堡居民 · 互动时间</span>
        <h1 class="title">角色互动</h1>
        <p class="sub">和居民聊天，选对懂 TA 的话攒默契。默契够了，就能把他收进图鉴里！</p>
      </section>

      <!-- ============ 角色卡片网格 ============ -->
      <section class="grid">
        <article
          v-for="(c, i) in characters"
          :key="c.code"
          class="char-card"
          :style="{ '--accent': c.accent, '--accent2': c.accent2, animationDelay: i * 0.07 + 's' }"
          @click="openChat(c)"
        >
          <span class="card-shine"></span>
          <div class="char-top">
            <div class="portrait">
              <span class="bubble b1"></span>
              <span class="bubble b2"></span>
              <span class="portrait-emoji">{{ c.emoji }}</span>
              <span v-if="isUnlocked(c.code)" class="owned-badge">✓ 已收集</span>
            </div>
            <div class="char-id">
              <h2>{{ c.name }}</h2>
              <p class="char-job">{{ c.job }}</p>
            </div>
          </div>
          <p class="char-desc">{{ c.desc }}</p>
          <div class="char-progress">
            <span class="cp-label">默契</span>
            <span class="cp-dots">
              <i v-for="n in c.unlock.need" :key="n" :class="{ on: n <= chatState(c.code).correct }"></i>
            </span>
            <span class="cp-num">{{ chatState(c.code).correct }}/{{ c.unlock.need }}</span>
          </div>
          <div class="char-foot">
            <span class="chat-hint">💬 点我聊天</span>
            <span class="enter">进入 →</span>
          </div>
          <span v-if="burstFor === c.code" class="click-burst" aria-hidden="true">
            <i v-for="n in 7" :key="n" :style="burstStyle(n)"></i>
          </span>
        </article>
      </section>

      <!-- ============ 图鉴入口提示 ============ -->
      <section class="note">
        <span>📖</span>
        <p>
          已收集 <b>{{ progress.owned }}/{{ progress.total }}</b> 位居民 ·
          <router-link to="/collection">去图鉴看看 →</router-link>
        </p>
      </section>
    </main>

    <!-- ============ 对话弹窗 ============ -->
    <transition name="dialog">
      <div v-if="active" class="mask" @click.self="closeChat">
        <div class="chat-dialog" :style="{ '--accent': active.accent, '--accent2': active.accent2 }">
          <div class="dlg-bubbles" aria-hidden="true">
            <span v-for="b in 9" :key="b" class="db" :style="dlgBubbleStyle(b)"></span>
          </div>

          <button class="dlg-close" type="button" @click="closeChat" aria-label="关闭">✕</button>

          <div class="dlg-head">
            <div class="dlg-portrait">
              <span class="dp-ring"></span>
              <span class="dp-emoji">{{ active.emoji }}</span>
            </div>
            <div class="dlg-title">
              <h2>{{ active.name }}</h2>
              <p>{{ active.job }}</p>
            </div>
            <div class="rapport">
              <span>默契 {{ chatState(active.code).correct }}/{{ active.unlock.need }}</span>
              <span class="rapport-dots">
                <i v-for="n in active.unlock.need" :key="n" :class="{ on: n <= chatState(active.code).correct }"></i>
              </span>
            </div>
          </div>

          <!-- 进度：第几轮 -->
          <div class="round-bar">
            <span v-for="(rd, ri) in active.dialogue" :key="ri" class="round-dot"
              :class="{ done: ri < round, now: ri === round }"></span>
            <span class="round-text">第 {{ Math.min(round + 1, active.dialogue.length) }}/{{ active.dialogue.length }} 轮</span>
          </div>

          <!-- 角色说话 -->
          <div class="speech">
            <span class="speech-quote">“</span>
            <p :key="'say-' + round">{{ currentSay }}</p>
            <span class="speech-quote end">”</span>
          </div>

          <!-- 用户的回应（选完后显示） -->
          <transition name="bubble-in">
            <div v-if="lastChoice" class="reply-wrap">
              <div class="user-reply">{{ lastChoice.text }}</div>
              <div class="role-reply">
                <span class="rr-emoji">{{ active.emoji }}</span>
                <p>{{ lastChoice.reply }}</p>
              </div>
              <span class="choice-feedback" :class="lastChoice.best ? 'good' : 'miss'">
                {{ lastChoice.best ? '💛 默契 +1，你懂 TA！' : '🫧 好像不太对，再试试别的说法～' }}
              </span>
            </div>
          </transition>

          <!-- 选项区 -->
          <div v-if="!finished && !lastChoice" class="options">
            <p class="options-hint">你会怎么回应？</p>
            <button
              v-for="(opt, oi) in currentOptions"
              :key="oi"
              type="button"
              class="option-btn"
              @click="choose(opt)"
            >
              <span class="opt-mark">{{ ['A', 'B', 'C'][oi] }}</span>{{ opt.text }}
            </button>
          </div>

          <!-- 完成一轮后的操作 -->
          <div v-if="lastChoice" class="dlg-foot">
            <button v-if="!finished" class="nav-line next" type="button" @click="nextRound">继续下一轮 ›</button>
            <button v-else class="nav-line next" type="button" @click="finishChat">
              {{ alreadyUnlocked ? '聊完了 · 关闭' : '结束对话' }}
            </button>
          </div>

          <!-- 解锁提示 -->
          <transition name="bubble-in">
            <div v-if="showUnlock" class="unlock-banner">
              <span>🎉</span>
              <p>默契达标！已解锁「{{ active.name }}」图鉴<br><small>去图鉴页看看你的收藏吧～</small></p>
            </div>
          </transition>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import OceanBackdrop from './OceanBackdrop.vue'
import PageNav from './PageNav.vue'
import { getNickname } from '../utils/auth.js'
import { characters } from '../data/characters.js'
import { isUnlocked, getProgress, getChatState, recordChoice } from '../utils/collection.js'

defineEmits(['logout'])

const displayName = computed(() => getNickname() || '海绵宝宝')

const active = ref(null)
const round = ref(0)          // 当前对话轮次索引
const lastChoice = ref(null)  // 本轮用户选的选项（含 reply/best）
const finished = ref(false)   // 是否已走完所有轮
const showUnlock = ref(false) // 是否展示解锁横幅
const alreadyUnlocked = ref(false)
const burstFor = ref('')
let burstTimer = null

const progress = computed(() => getProgress(characters.length))
const currentSay = computed(() =>
  active.value ? active.value.dialogue[round.value]?.say || '' : ''
)
const currentOptions = computed(() =>
  active.value ? active.value.dialogue[round.value]?.options || [] : []
)

function chatState(code) {
  return getChatState(code)
}

function openChat(c) {
  active.value = c
  round.value = 0
  lastChoice.value = null
  finished.value = false
  showUnlock.value = false
  alreadyUnlocked.value = isUnlocked(c.code)
  // 点击气泡动画
  burstFor.value = c.code
  clearTimeout(burstTimer)
  burstTimer = setTimeout(() => { burstFor.value = '' }, 900)
}

function closeChat() {
  active.value = null
  showUnlock.value = false
}

function choose(opt) {
  if (!active.value || lastChoice.value) return
  lastChoice.value = opt
  // 记录默契（选对 +1），达到要求自动解锁
  const result = recordChoice(active.value.code, opt.best, active.value.unlock.need)
  if (result.justUnlocked) {
    showUnlock.value = true
    alreadyUnlocked.value = true
  }
}

function nextRound() {
  lastChoice.value = null
  if (round.value < active.value.dialogue.length - 1) {
    round.value++
  } else {
    finished.value = true
  }
}

function finishChat() {
  closeChat()
}

// 卡片点击气泡动画
function burstStyle(n) {
  const left = 30 + ((n * 23) % 45)
  const size = 8 + ((n * 5) % 14)
  return { left: left + '%', width: size + 'px', height: size + 'px', animationDelay: (n * 0.05) + 's' }
}

function dlgBubbleStyle(n) {
  const left = (n * 11 + 4) % 96
  const size = 8 + ((n * 7) % 26)
  return {
    left: left + '%', width: size + 'px', height: size + 'px', bottom: '-30px',
    animationDelay: ((n * 1.3) % 8).toFixed(1) + 's',
    animationDuration: (9 + (n % 4) * 3) + 's'
  }
}

onMounted(() => {
  document.title = '角色互动 · 海绵宝宝'
})
</script>

<style scoped>
.characters-page { min-height: 100vh; position: relative; }
.main { position: relative; z-index: 2; max-width: 1180px; margin: 0 auto; padding: 40px 20px 80px; }

/* ============ 头部 ============ */
.hero { text-align: center; margin-bottom: 36px; }
.hero-kicker {
  display: inline-block; font-size: 13px; letter-spacing: 2px; color: #b9e6ff;
  background: rgba(3,46,76,.6); border: 1px solid rgba(126,226,255,.4);
  padding: 6px 16px; border-radius: 999px; margin-bottom: 14px;
}
.title {
  font-size: clamp(34px,6vw,58px); color: #ffe082; letter-spacing: 6px;
  text-shadow: 0 3px 0 #c17900, 0 6px 0 rgba(0,0,0,.15), 0 0 30px rgba(255,213,79,.5);
  margin-bottom: 12px;
}
.sub { color: #eaf7ff; font-size: 16px; text-shadow: 0 2px 4px rgba(1,26,44,.6); }

/* ============ 角色卡片 ============ */
.grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
.char-card {
  position: relative; overflow: hidden; cursor: pointer;
  padding: 22px 22px 18px; border-radius: 24px;
  background: linear-gradient(180deg, rgba(255,255,255,.14), rgba(255,255,255,.02) 46%, rgba(2,44,72,.2)), rgba(6,66,104,.38);
  border: 2px solid rgba(160,232,255,.4);
  box-shadow: 0 14px 34px rgba(1,26,44,.32), inset 0 1px 0 rgba(255,255,255,.18);
  transition: transform .25s cubic-bezier(.2,1.3,.4,1), border-color .25s, box-shadow .25s;
  animation: cardIn .55s ease both;
}
@keyframes cardIn { from { opacity: 0; transform: translateY(18px); } to { opacity: 1; transform: translateY(0); } }
.char-card:hover {
  transform: translateY(-8px); border-color: var(--accent);
  box-shadow: 0 22px 46px rgba(1,26,44,.42), 0 0 30px color-mix(in srgb, var(--accent) 40%, transparent);
}
.char-card:active { transform: translateY(-2px) scale(.99); }
.card-shine { position: absolute; inset: -40% -60% auto -60%; height: 70%; background: radial-gradient(ellipse at center, rgba(255,255,255,.22), transparent 65%); pointer-events: none; }
.char-top { display: flex; align-items: center; gap: 14px; position: relative; }
.portrait {
  position: relative; width: 76px; height: 76px; flex-shrink: 0; display: grid; place-items: center; border-radius: 22px; overflow: hidden;
  background: radial-gradient(circle at 50% 32%, color-mix(in srgb, var(--accent) 60%, white), color-mix(in srgb, var(--accent2) 70%, transparent));
  border: 3px solid #fff;
  box-shadow: 0 4px 0 rgba(0,0,0,.15), inset 0 2px 8px rgba(255,255,255,.5), 0 0 22px color-mix(in srgb, var(--accent) 45%, transparent);
}
.portrait-emoji { font-size: 42px; line-height: 1; position: relative; z-index: 2; animation: bob 3s ease-in-out infinite; }
@keyframes bob { 0%,100% { transform: translateY(0) rotate(-3deg); } 50% { transform: translateY(-6px) rotate(3deg); } }
.portrait .bubble { position: absolute; border-radius: 50%; background: rgba(255,255,255,.45); border: 1px solid rgba(255,255,255,.7); z-index: 1; }
.portrait .b1 { width: 12px; height: 12px; left: 10px; top: 14px; animation: pb 4s ease-in-out infinite; }
.portrait .b2 { width: 8px; height: 8px; right: 12px; bottom: 16px; animation: pb 5s ease-in-out infinite 1s; }
@keyframes pb { 0%,100% { transform: translateY(0); opacity: .5; } 50% { transform: translateY(-12px); opacity: .9; } }
.owned-badge { position: absolute; z-index: 3; bottom: 0; left: 0; right: 0; font-size: 10px; font-weight: bold; text-align: center; color: #5d3700; background: linear-gradient(180deg,#ffe082,#ffb300); padding: 2px 0; }
.char-id { flex: 1; min-width: 0; }
.char-id h2 { font-size: 20px; color: #fff8e1; letter-spacing: 1px; }
.char-job { margin-top: 3px; font-size: 12.5px; color: color-mix(in srgb, var(--accent) 85%, white); }
.char-desc { position: relative; margin-top: 14px; font-size: 13px; line-height: 1.7; color: #d9f2ff; min-height: 62px; }

/* 默契进度 */
.char-progress { position: relative; display: flex; align-items: center; gap: 8px; margin-top: 12px; }
.cp-label { font-size: 11.5px; color: #b9e6ff; }
.cp-dots { display: inline-flex; gap: 4px; }
.cp-dots i { width: 22px; height: 6px; border-radius: 3px; background: rgba(160,232,255,.22); transition: background .3s; }
.cp-dots i.on { background: linear-gradient(90deg, var(--accent), #ffe082); box-shadow: 0 0 8px var(--accent); }
.cp-num { font-size: 11.5px; color: #ffe082; font-weight: bold; }

.char-foot { position: relative; margin-top: 12px; padding-top: 12px; border-top: 1px dashed rgba(160,232,255,.28); display: flex; align-items: center; justify-content: space-between; }
.chat-hint { font-size: 12px; color: #b9e6ff; }
.enter { font-size: 12px; font-weight: bold; color: #5d3700; background: linear-gradient(180deg,#ffd54f,#ffb300); padding: 4px 12px; border-radius: 999px; box-shadow: 0 2px 0 #c17900; }

/* 点击气泡动画 */
.click-burst { position: absolute; inset: 0; pointer-events: none; z-index: 5; }
.click-burst i { position: absolute; bottom: 12%; border-radius: 50%; background: radial-gradient(circle at 32% 28%, #fff, rgba(126,226,255,.55) 60%, transparent); border: 1px solid rgba(255,255,255,.7); animation: burstUp .85s ease-out forwards; }
@keyframes burstUp { 0% { transform: translateY(0) scale(.4); opacity: 0; } 25% { opacity: .95; } 100% { transform: translateY(-160px) scale(1.2); opacity: 0; } }

/* ============ 图鉴入口 ============ */
.note { margin-top: 30px; display: flex; align-items: center; justify-content: center; gap: 12px; color: #d9f2ff; font-size: 14px; text-align: center; background: rgba(3,46,76,.5); border: 1px solid rgba(126,226,255,.3); padding: 14px 20px; border-radius: 18px; backdrop-filter: blur(6px); }
.note span { font-size: 22px; }
.note b { color: #ffe082; }
.note a { color: #ffe082; font-weight: bold; text-decoration: none; }
.note a:hover { text-decoration: underline; }

/* ============ 对话弹窗 ============ */
.mask { position: fixed; inset: 0; z-index: 80; display: grid; place-items: center; padding: 20px; background: rgba(2,20,38,.62); backdrop-filter: blur(5px); }
.chat-dialog {
  position: relative; width: min(540px, 100%); max-height: 90vh; overflow-y: auto; overflow-x: hidden;
  padding: 24px 26px 22px; border-radius: 26px;
  background: linear-gradient(160deg, #fffdf5, #e6f5ff);
  border: 3px solid var(--accent);
  box-shadow: 0 12px 0 color-mix(in srgb, var(--accent2) 55%, transparent), 0 30px 60px rgba(0,0,0,.5);
}
.dlg-bubbles { position: absolute; inset: 0; overflow: hidden; pointer-events: none; }
.db { position: absolute; border-radius: 50%; background: radial-gradient(circle at 32% 28%, rgba(255,255,255,.9), rgba(126,226,255,.28) 60%, transparent); border: 1px solid rgba(126,226,255,.35); animation: dbRise linear infinite; opacity: 0; }
@keyframes dbRise { 0% { transform: translateY(0) scale(.6); opacity: 0; } 15% { opacity: .5; } 85% { opacity: .35; } 100% { transform: translateY(-480px) scale(1.1); opacity: 0; } }
.dlg-close { position: absolute; z-index: 3; top: 14px; right: 14px; width: 32px; height: 32px; border-radius: 50%; cursor: pointer; border: 2px solid rgba(6,71,110,.3); background: rgba(255,255,255,.85); color: #06476e; font-size: 14px; font-weight: bold; transition: transform .2s, background .2s; }
.dlg-close:hover { transform: rotate(90deg); background: #ffe082; }
.dlg-head { position: relative; z-index: 2; display: flex; align-items: center; gap: 14px; margin-bottom: 14px; }
.dlg-portrait { position: relative; width: 62px; height: 62px; flex-shrink: 0; display: grid; place-items: center; border-radius: 20px; background: linear-gradient(150deg, var(--accent), var(--accent2)); border: 3px solid #fff; box-shadow: 0 3px 0 rgba(0,0,0,.14), 0 0 18px color-mix(in srgb, var(--accent) 50%, transparent); }
.dp-emoji { font-size: 34px; position: relative; z-index: 2; animation: bob 3s ease-in-out infinite; }
.dp-ring { position: absolute; inset: -6px; border-radius: 26px; border: 2px dashed color-mix(in srgb, var(--accent) 60%, transparent); animation: spin 14s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.dlg-title { flex: 1; min-width: 0; }
.dlg-title h2 { font-size: 20px; color: #06476e; letter-spacing: 1px; }
.dlg-title p { font-size: 12px; color: #5a7d92; margin-top: 2px; }
.rapport { display: flex; flex-direction: column; align-items: flex-end; gap: 4px; font-size: 11px; font-weight: bold; color: #c17900; }
.rapport-dots { display: inline-flex; gap: 3px; }
.rapport-dots i { width: 14px; height: 6px; border-radius: 3px; background: rgba(6,71,110,.16); }
.rapport-dots i.on { background: linear-gradient(90deg, var(--accent), #ffe082); }

/* 轮次进度 */
.round-bar { position: relative; z-index: 2; display: flex; align-items: center; gap: 6px; margin-bottom: 12px; }
.round-dot { width: 26px; height: 5px; border-radius: 3px; background: rgba(6,71,110,.14); }
.round-dot.done { background: var(--accent2); }
.round-dot.now { background: var(--accent); box-shadow: 0 0 8px var(--accent); }
.round-text { margin-left: auto; font-size: 11px; color: #7a93a3; }

/* 角色说话 */
.speech { position: relative; z-index: 2; min-height: 88px; padding: 18px 22px 16px 34px; background: rgba(255,255,255,.75); border: 2px solid rgba(6,71,110,.14); border-radius: 18px 18px 18px 6px; box-shadow: inset 0 2px 6px rgba(6,71,110,.06); }
.speech p { font-size: 15px; line-height: 1.75; color: #2c4a5e; font-weight: bold; animation: fadeIn .3s ease; }
@keyframes fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
.speech-quote { position: absolute; left: 10px; top: 6px; font-size: 40px; color: var(--accent); line-height: 1; opacity: .6; }
.speech-quote.end { left: auto; right: 12px; top: auto; bottom: -6px; }

/* 用户回应 + 角色回复 */
.reply-wrap { position: relative; z-index: 2; margin-top: 14px; }
.user-reply { margin-left: auto; max-width: 82%; width: fit-content; padding: 9px 14px; border-radius: 16px 16px 4px 16px; background: linear-gradient(150deg, #b3e5fc, #81d4fa); color: #06476e; font-size: 13.5px; font-weight: bold; box-shadow: 0 3px 10px rgba(2,136,209,.2); }
.role-reply { display: flex; gap: 8px; align-items: flex-start; margin-top: 10px; padding: 10px 12px; border-radius: 14px 14px 14px 4px; background: rgba(255,255,255,.8); border: 1px solid rgba(6,71,110,.12); }
.rr-emoji { font-size: 24px; flex-shrink: 0; }
.role-reply p { font-size: 13.5px; line-height: 1.6; color: #2c4a5e; }
.choice-feedback { display: block; margin-top: 9px; text-align: center; font-size: 12px; font-weight: bold; }
.choice-feedback.good { color: #e6a100; }
.choice-feedback.miss { color: #6c8a9c; }

/* 选项 */
.options { position: relative; z-index: 2; margin-top: 16px; }
.options-hint { font-size: 12.5px; color: #7a93a3; margin-bottom: 9px; }
.option-btn {
  display: flex; align-items: center; gap: 10px; width: 100%; text-align: left;
  margin-bottom: 8px; padding: 11px 13px; border-radius: 14px;
  border: 2px solid rgba(6,71,110,.18); background: rgba(255,255,255,.85);
  color: #2c4a5e; font-family: inherit; font-size: 13.5px; font-weight: bold; cursor: pointer;
  transition: all .18s;
}
.option-btn:hover { border-color: var(--accent); background: #fffdf2; transform: translateX(4px); box-shadow: 0 4px 12px color-mix(in srgb, var(--accent) 28%, transparent); }
.opt-mark { width: 24px; height: 24px; flex-shrink: 0; display: grid; place-items: center; border-radius: 8px; background: linear-gradient(150deg, var(--accent), var(--accent2)); color: #fff; font-size: 12px; box-shadow: 0 2px 0 rgba(0,0,0,.12); }

/* 底部操作 */
.dlg-foot { position: relative; z-index: 2; display: flex; justify-content: flex-end; margin-top: 16px; }
.nav-line { border: 2px solid rgba(6,71,110,.24); background: rgba(255,255,255,.85); color: #0a5c86; padding: 8px 16px; border-radius: 12px; font-family: inherit; font-size: 13px; font-weight: bold; cursor: pointer; transition: all .2s; }
.nav-line.next { background: linear-gradient(180deg,#ffd54f,#ffb300); border-color: #ffd54f; color: #5d3700; box-shadow: 0 2px 0 #c17900; }
.nav-line.next:hover { filter: brightness(1.06); transform: translateY(-1px); }

/* 解锁横幅 */
.unlock-banner { position: relative; z-index: 2; display: flex; align-items: center; gap: 12px; margin-top: 16px; padding: 14px 16px; border-radius: 16px; background: linear-gradient(120deg, #fff6cf, #ffe9a8); border: 2px solid #ffd54f; box-shadow: 0 4px 16px rgba(255,193,7,.35); }
.unlock-banner span { font-size: 28px; }
.unlock-banner p { font-size: 14px; font-weight: bold; color: #8a5a00; line-height: 1.5; }
.unlock-banner small { font-size: 11.5px; color: #a5791f; font-weight: normal; }

/* 过渡 */
.bubble-in-enter-active { animation: bubblePop .35s cubic-bezier(.2,1.3,.4,1); }
@keyframes bubblePop { from { opacity: 0; transform: translateY(10px) scale(.94); } to { opacity: 1; transform: translateY(0) scale(1); } }
.dialog-enter-active, .dialog-leave-active { transition: opacity .25s ease; }
.dialog-enter-active .chat-dialog { animation: dlgIn .32s cubic-bezier(.2,1.3,.4,1); }
@keyframes dlgIn { from { transform: scale(.86) translateY(20px); opacity: 0; } to { transform: scale(1) translateY(0); opacity: 1; } }
.dialog-enter-from, .dialog-leave-to { opacity: 0; }

@media (max-width: 900px) { .grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 560px) { .grid { grid-template-columns: 1fr; } }
</style>
