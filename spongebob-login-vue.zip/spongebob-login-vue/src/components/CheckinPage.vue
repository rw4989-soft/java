<template>
  <div class="checkin-page">
    <OceanBackdrop />
    <PageNav active="profile" :nickname="displayName" @logout="$emit('logout')" />

    <main class="main">
      <section class="hero">
        <span class="hero-kicker">📅 每日签到</span>
        <h1 class="title">海底打卡</h1>
        <p class="sub">每天来打个卡，连续签到奖励更丰厚哦！</p>
      </section>

      <!-- 连续天数 -->
      <section class="streak-card">
        <div class="sc-item"><span>🔥</span><div><b>{{ state.streak }}</b><small>连续天数</small></div></div>
        <div class="sc-div"></div>
        <div class="sc-item"><span>📆</span><div><b>{{ state.total }}</b><small>累计签到</small></div></div>
        <div class="sc-div"></div>
        <div class="sc-item"><span>🎁</span><div><b>{{ todayReward }}</b><small>今日奖励</small></div></div>
      </section>

      <!-- 签到按钮 -->
      <section class="action-card">
        <button v-if="!state.checkedToday" class="check-btn" @click="doCheck">
          <span class="cb-bubble">🫧</span>
          今日签到
        </button>
        <div v-else class="checked-box">
          <span>✅</span>
          <div><b>今天已签到</b><small>明天再来，保持连续哦～</small></div>
        </div>
        <p class="reward-tip">连续签到越久，奖励越多（第 7 天起奖励翻倍）</p>
      </section>

      <!-- 月历 -->
      <section class="calendar">
        <div class="cal-head">
          <button class="cal-nav" @click="changeMonth(-1)">‹</button>
          <h3>{{ year }} 年 {{ month + 1 }} 月</h3>
          <button class="cal-nav" @click="changeMonth(1)">›</button>
        </div>
        <div class="weekdays"><span v-for="w in weeks" :key="w">{{ w }}</span></div>
        <div class="days">
          <template v-for="(d, i) in cells" :key="i">
            <span v-if="d === null" class="day empty"></span>
            <span v-else class="day" :class="{
              checked: isMarked(year, month, d),
              today: isToday(year, month, d)
            }">{{ d }}</span>
          </template>
        </div>
        <div class="cal-legend">
          <span><i class="lg checked"></i> 已签到</span>
          <span><i class="lg today"></i> 今天</span>
        </div>
      </section>

      <!-- 奖励里程碑 -->
      <section class="milestones">
        <h3>🎁 连续签到奖励</h3>
        <div class="ms-list">
          <div v-for="m in milestones" :key="m.day" class="ms" :class="{ reached: state.streak >= m.day }">
            <span class="ms-icon">{{ m.icon }}</span>
            <b>{{ m.day }} 天</b>
            <small>{{ m.name }}</small>
          </div>
        </div>
      </section>

      <!-- 奖励通知 -->
      <div v-if="toast" class="toast">{{ toast }}</div>
    </main>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import OceanBackdrop from './OceanBackdrop.vue'
import PageNav from './PageNav.vue'
import { getNickname } from '../utils/auth.js'
import { getCheckinState, checkIn, isDateChecked, buildMonth } from '../utils/checkin.js'
import { sfx } from '../utils/sound.js'

defineEmits(['logout'])
const displayName = computed(() => getNickname() || '海绵宝宝')

const now = new Date()
const year = ref(now.getFullYear())
const month = ref(now.getMonth())
const state = ref(getCheckinState())
const toast = ref('')
const weeks = ['日', '一', '二', '三', '四', '五', '六']

const cells = computed(() => buildMonth(year.value, month.value))

const milestones = [
  { day: 1, name: '10 贝币', icon: '🪙' },
  { day: 3, name: '30 贝币', icon: '💰' },
  { day: 7, name: '神秘宝箱', icon: '🎁' },
  { day: 15, name: '金勋章', icon: '🏅' },
  { day: 30, name: '水母之王', icon: '👑' }
]

const todayReward = computed(() => 10 + Math.min(Math.max(state.value.streak, 1), 7) * 5)

function pad(n) { return String(n).padStart(2, '0') }
function dateStr(y, m, d) { return `${y}-${pad(m + 1)}-${pad(d)}` }
function isMarked(y, m, d) { return isDateChecked(dateStr(y, m, d)) }
function isToday(y, m, d) {
  const t = new Date()
  return t.getFullYear() === y && t.getMonth() === m && t.getDate() === d
}
function changeMonth(step) {
  let m = month.value + step
  let y = year.value
  if (m < 0) { m = 11; y-- }
  if (m > 11) { m = 0; y++ }
  month.value = m
  year.value = y
}
function doCheck() {
  const r = checkIn()
  if (r.already) return
  state.value = getCheckinState()
  sfx.coin()
  toast.value = `签到成功！+${r.reward} 贝币 · 连续 ${r.streak} 天 🎉`
  setTimeout(() => { toast.value = '' }, 2800)
}

onMounted(() => {
  document.title = '每日签到 · 海绵宝宝'
  state.value = getCheckinState()
})
</script>

<style scoped>
.checkin-page { min-height: 100vh; position: relative; }
.main { position: relative; z-index: 2; max-width: 760px; margin: 0 auto; padding: 40px 20px 80px; }
.hero { text-align: center; margin-bottom: 24px; }
.hero-kicker { display: inline-block; font-size: 13px; letter-spacing: 2px; color: #b9e6ff; background: rgba(3,46,76,.6); border: 1px solid rgba(126,226,255,.4); padding: 6px 16px; border-radius: 999px; margin-bottom: 12px; }
.title { font-size: clamp(32px,6vw,50px); color: #ffe082; letter-spacing: 5px; text-shadow: 0 3px 0 #c17900, 0 0 30px rgba(255,213,79,.5); margin-bottom: 8px; }
.sub { color: #eaf7ff; font-size: 15px; }

.streak-card { display: flex; align-items: center; justify-content: space-around; background: rgba(3,46,76,.55); border: 2px solid rgba(126,226,255,.35); border-radius: 22px; padding: 18px; margin-bottom: 18px; backdrop-filter: blur(6px); }
.sc-item { display: flex; align-items: center; gap: 10px; }
.sc-item > span { font-size: 34px; }
.sc-item b { display: block; font-size: 26px; color: #ffe082; line-height: 1; }
.sc-item small { font-size: 12px; color: #b9e6ff; }
.sc-div { width: 1px; height: 36px; background: rgba(126,226,255,.3); }

.action-card { text-align: center; background: rgba(255,255,255,.94); border: 3px solid #ffd54f; border-radius: 24px; padding: 26px; box-shadow: 0 7px 0 rgba(193,121,0,.4), 0 20px 40px rgba(1,26,44,.3); margin-bottom: 22px; }
.check-btn { position: relative; border: none; background: linear-gradient(180deg,#ffd54f,#ffb300); color: #5d3700; font-family: inherit; font-size: 19px; font-weight: bold; padding: 14px 52px; border-radius: 999px; cursor: pointer; box-shadow: 0 5px 0 #c17900, 0 0 26px rgba(255,193,7,.55); transition: transform .18s, filter .18s; }
.check-btn:hover { transform: translateY(-3px); filter: brightness(1.05); }
.check-btn:active { transform: translateY(2px); box-shadow: 0 2px 0 #c17900; }
.cb-bubble { position: absolute; left: 14px; font-size: 20px; animation: bob 2s ease-in-out infinite; }
@keyframes bob { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-6px); } }
.checked-box { display: inline-flex; align-items: center; gap: 12px; text-align: left; }
.checked-box > span { font-size: 38px; }
.checked-box b { display: block; color: #0a5c86; font-size: 18px; }
.checked-box small { color: #5a7a8a; font-size: 13px; }
.reward-tip { color: #5a7a8a; font-size: 12px; margin-top: 14px; }

.calendar { background: rgba(3,46,76,.5); border: 2px solid rgba(126,226,255,.3); border-radius: 22px; padding: 20px; margin-bottom: 22px; backdrop-filter: blur(6px); }
.cal-head { display: flex; align-items: center; justify-content: center; gap: 20px; margin-bottom: 16px; }
.cal-head h3 { color: #ffe082; font-size: 18px; min-width: 120px; text-align: center; }
.cal-nav { width: 32px; height: 32px; border-radius: 50%; border: 2px solid rgba(126,226,255,.45); background: rgba(126,226,255,.12); color: #b9e6ff; font-size: 20px; cursor: pointer; line-height: 1; }
.cal-nav:hover { background: rgba(126,226,255,.25); }
.weekdays, .days { display: grid; grid-template-columns: repeat(7, 1fr); gap: 6px; }
.weekdays span { text-align: center; font-size: 12px; color: #8fdcff; padding-bottom: 8px; }
.day { aspect-ratio: 1; display: grid; place-items: center; font-size: 14px; color: #eaf7ff; background: rgba(255,255,255,.08); border: 1px solid rgba(126,226,255,.18); border-radius: 10px; }
.day.empty { background: transparent; border: none; }
.day.checked { background: linear-gradient(150deg,#ffd54f,#ffb300); color: #5d3700; font-weight: bold; box-shadow: 0 2px 0 #c17900; }
.day.today { border: 2px solid #ffe082; box-shadow: 0 0 12px rgba(255,213,79,.6); }
.cal-legend { display: flex; gap: 18px; justify-content: center; margin-top: 14px; font-size: 12px; color: #b9e6ff; }
.cal-legend span { display: flex; align-items: center; gap: 6px; }
.lg { width: 14px; height: 14px; border-radius: 4px; display: inline-block; }
.lg.checked { background: #ffb300; }
.lg.today { border: 2px solid #ffe082; }

.milestones { background: rgba(3,46,76,.5); border: 2px solid rgba(126,226,255,.3); border-radius: 22px; padding: 20px; backdrop-filter: blur(6px); }
.milestones h3 { color: #ffe082; font-size: 17px; margin-bottom: 16px; }
.ms-list { display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; }
.ms { text-align: center; padding: 12px 4px; border-radius: 14px; background: rgba(120,140,155,.15); border: 1px solid rgba(150,170,180,.25); opacity: .6; }
.ms.reached { opacity: 1; background: rgba(255,213,79,.16); border-color: #ffd54f; }
.ms-icon { font-size: 26px; display: block; }
.ms b { display: block; color: #eaf7ff; font-size: 13px; margin-top: 4px; }
.ms small { color: #b9e6ff; font-size: 11px; }
.ms.reached b { color: #ffe082; }

.toast { position: fixed; top: 90px; left: 50%; transform: translateX(-50%); z-index: 90; background: rgba(255,253,235,.98); border: 3px solid #ffb300; color: #5d3700; font-weight: bold; font-size: 14px; padding: 12px 24px; border-radius: 999px; box-shadow: 0 8px 24px rgba(0,0,0,.4); animation: pop .3s; }
@keyframes pop { from { transform: translateX(-50%) scale(.7); opacity: 0; } }

@media (max-width: 560px) { .ms-list { grid-template-columns: repeat(3, 1fr); } }
</style>
