<template>
  <div class="collection-page">
    <OceanBackdrop />
    <PageNav active="collection" :nickname="displayName" @logout="$emit('logout')" />

    <main class="main">
      <!-- ============ 头部 ============ -->
      <section class="hero">
        <span class="hero-kicker">📖 比奇堡居民图鉴</span>
        <h1 class="title">图鉴收集</h1>
        <p class="sub">和居民聊天要选对懂 TA 的回应，攒够默契才能收进图鉴。集齐所有伙伴吧！</p>
      </section>

      <!-- ============ 进度条 ============ -->
      <section class="progress-card">
        <div class="progress-head">
          <span class="progress-title" title="Shift+点击可重置图鉴" @click="onReset">🏆 收集进度</span>
          <span class="progress-num"><b>{{ progress.owned }}</b> / {{ progress.total }} <small>（{{ progress.percent }}%）</small></span>
        </div>
        <div class="progress-track">
          <i class="progress-fill" :style="{ width: progress.percent + '%' }">
            <span class="progress-glow"></span>
          </i>
        </div>
        <p class="progress-tip">{{ progressTip }}</p>
      </section>

      <!-- ============ 图鉴网格 ============ -->
      <section class="grid">
        <article
          v-for="c in characters"
          :key="c.code"
          class="collection-cell"
          :class="{ locked: !isUnlocked(c.code) }"
          :style="{ '--accent': c.accent, '--accent2': c.accent2 }"
          @click="onCell(c)"
        >
          <template v-if="isUnlocked(c.code)">
            <span class="cell-shine"></span>
            <div class="cell-portrait">
              <span class="cell-emoji">{{ c.emoji }}</span>
            </div>
            <h3 class="cell-name">{{ c.name }}</h3>
            <p class="cell-desc">{{ c.desc }}</p>
            <div class="cell-how"><span>🔑</span> {{ c.unlock.rule }}</div>
            <span class="cell-check">✓ 已收集</span>
          </template>
          <template v-else>
            <div class="cell-lock-wrap">
              <span class="lock-emoji">🔒</span>
              <span v-if="chatState(c.code).correct > 0" class="lock-progress">{{ chatState(c.code).correct }}/{{ c.unlock.need }}</span>
            </div>
            <h3 class="cell-name locked-name">??? </h3>
            <p class="cell-desc locked-desc">尚未收集</p>
            <div class="cell-rule"><span>🎯</span> {{ c.unlock.rule }}</div>
            <div class="cell-rapport">
              <span>默契</span>
              <span class="cr-dots">
                <i v-for="n in c.unlock.need" :key="n" :class="{ on: n <= chatState(c.code).correct }"></i>
              </span>
            </div>
          </template>
        </article>
      </section>

      <!-- ============ 去互动入口 ============ -->
      <section class="note">
        <span>🤝</span>
        <p>还没集齐？<router-link to="/characters">去角色互动页 →</router-link> 找伙伴们聊聊吧</p>
      </section>
    </main>

    <!-- ============ 图鉴详情弹窗 ============ -->
    <transition name="dialog">
      <div v-if="detail" class="mask" @click.self="detail = null">
        <div class="detail-dialog" :style="{ '--accent': detail.accent, '--accent2': detail.accent2 }">
          <div class="dlg-bubbles" aria-hidden="true">
            <span v-for="b in 7" :key="b" class="db" :style="dlgBubbleStyle(b)"></span>
          </div>
          <button class="dlg-close" type="button" @click="detail = null" aria-label="关闭">✕</button>
          <div class="detail-head">
            <div class="detail-portrait">
              <span class="dp-ring"></span>
              <span class="dp-emoji">{{ detail.emoji }}</span>
            </div>
            <div>
              <span class="detail-badge">📖 图鉴 No.{{ indexOf(detail) + 1 }}</span>
              <h2>{{ detail.name }}</h2>
              <p>{{ detail.job }}</p>
            </div>
          </div>
          <div class="detail-body">
            <h4>小简介</h4>
            <p>{{ detail.desc }}</p>
            <h4>解锁要求</h4>
            <p class="detail-how"><span>🎯</span> {{ detail.unlock.rule }}</p>
            <p class="detail-progress-line">当前默契：<b>{{ chatState(detail.code).correct }}/{{ detail.unlock.need }}</b> · 已对话 {{ chatState(detail.code).chats }} 次</p>
          </div>
          <button class="detail-go" type="button" @click="goChat">
            💬 再去找 TA 聊聊 →
          </button>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import OceanBackdrop from './OceanBackdrop.vue'
import PageNav from './PageNav.vue'
import { getNickname } from '../utils/auth.js'
import { characters } from '../data/characters.js'
import { isUnlocked, getProgress, getChatState, resetCollection } from '../utils/collection.js'

defineEmits(['logout'])

const router = useRouter()
const displayName = computed(() => getNickname() || '海绵宝宝')
const detail = ref(null)

const progress = computed(() => getProgress(characters.length))
const progressTip = computed(() => {
  const { owned, total } = progress.value
  if (owned === 0) return '还没开始收集呢～去互动页聊天，选对默契回应就能解锁图鉴！'
  if (owned === total) return '🎉 太棒了！你已经集齐了所有比奇堡居民图鉴！'
  return `还差 ${total - owned} 位就集齐啦，去和居民们多聊聊、选对 TA 喜欢的回应吧！`
})

function chatState(code) {
  return getChatState(code)
}

function onCell(c) {
  if (!isUnlocked(c.code)) return
  detail.value = c
}

function indexOf(c) {
  return characters.findIndex((x) => x.code === c.code)
}

function goChat() {
  detail.value = null
  router.push('/characters')
}

// 调试用：重置图鉴（按住 Shift 点击进度标题）
function onReset(e) {
  if (e.shiftKey) {
    resetCollection()
  }
}

function dlgBubbleStyle(n) {
  const left = (n * 13 + 5) % 94
  const size = 8 + ((n * 7) % 22)
  return {
    left: left + '%',
    width: size + 'px',
    height: size + 'px',
    bottom: '-30px',
    animationDelay: ((n * 1.1) % 7).toFixed(1) + 's',
    animationDuration: (9 + (n % 4) * 3) + 's'
  }
}

onMounted(() => {
  document.title = '图鉴收集 · 海绵宝宝'
})
</script>

<style scoped>
.collection-page { min-height: 100vh; position: relative; }
.main {
  position: relative; z-index: 2; max-width: 1180px; margin: 0 auto; padding: 40px 20px 80px;
}

/* ============ 头部 ============ */
.hero { text-align: center; margin-bottom: 30px; }
.hero-kicker {
  display: inline-block; font-size: 13px; letter-spacing: 2px; color: #b9e6ff;
  background: rgba(3,46,76,.6); border: 1px solid rgba(126,226,255,.4);
  padding: 6px 16px; border-radius: 999px; margin-bottom: 14px;
}
.title {
  font-size: clamp(34px,6vw,58px); color: #ffe082; letter-spacing: 6px;
  text-shadow: 0 3px 0 #c17900, 0 6px 0 rgba(0,0,0,.15), 0 0 30px rgba(255,213,79,.5);
  margin-bottom: 12px;
}
.sub { color: #eaf7ff; font-size: 16px; text-shadow: 0 2px 4px rgba(1,26,44,.6); }

/* ============ 进度条 ============ */
.progress-card {
  padding: 20px 26px; border-radius: 24px; margin-bottom: 34px;
  background: rgba(3,46,76,.58); border: 2px solid rgba(126,226,255,.4);
  backdrop-filter: blur(8px);
  box-shadow: inset 0 2px 0 rgba(255,255,255,.12), 0 16px 34px rgba(1,26,44,.35);
}
.progress-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; }
.progress-title { font-size: 17px; font-weight: bold; color: #ffe082; letter-spacing: 1px; user-select: none; }
.progress-num { font-size: 18px; color: #eaf7ff; }
.progress-num b { font-size: 26px; color: #ffe082; }
.progress-num small { font-size: 13px; color: #8fd0f0; }
.progress-track {
  height: 18px; border-radius: 999px; overflow: hidden;
  background: rgba(1,26,44,.55); border: 2px solid rgba(126,226,255,.3);
  box-shadow: inset 0 2px 6px rgba(0,0,0,.35);
}
.progress-fill {
  position: relative; display: block; height: 100%; border-radius: 999px;
  background: linear-gradient(90deg, #ffb300, #ffe082, #ffb300);
  box-shadow: 0 0 18px rgba(255,193,7,.7);
  transition: width .7s cubic-bezier(.2,1,.3,1);
  overflow: hidden;
}
.progress-glow {
  position: absolute; inset: 0;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,.6), transparent);
  animation: flow 2.2s linear infinite;
}
@keyframes flow { from { transform: translateX(-100%); } to { transform: translateX(100%); } }
.progress-tip { margin-top: 10px; text-align: center; font-size: 13px; color: #b9e6ff; }

/* ============ 图鉴格子 ============ */
.grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
.collection-cell {
  position: relative; overflow: hidden; cursor: pointer;
  padding: 22px 20px 18px; border-radius: 24px; text-align: center;
  background: linear-gradient(160deg, rgba(255,255,255,.94), rgba(226,244,255,.9));
  border: 2px solid rgba(255,255,255,.65);
  box-shadow: inset 0 2px 0 #fff, 0 9px 0 rgba(4,74,110,.3), 0 20px 38px rgba(1,26,44,.4);
  transition: transform .25s cubic-bezier(.2,1.3,.4,1), box-shadow .25s;
  animation: cardIn .55s ease both;
}
@keyframes cardIn { from { opacity: 0; transform: translateY(18px); } to { opacity: 1; transform: translateY(0); } }
.collection-cell:not(.locked):hover {
  transform: translateY(-8px);
  box-shadow: inset 0 2px 0 #fff, 0 15px 0 rgba(4,74,110,.28), 0 30px 50px rgba(1,26,44,.5), 0 0 32px var(--accent);
}
.cell-shine {
  position: absolute; right: -40px; top: -40px; width: 150px; height: 150px; border-radius: 50%;
  background: radial-gradient(circle, var(--accent), transparent 68%); opacity: .2; pointer-events: none;
}
.cell-portrait {
  position: relative; width: 92px; height: 92px; margin: 0 auto 12px;
  display: grid; place-items: center; border-radius: 26px;
  background: radial-gradient(circle at 50% 30%, color-mix(in srgb, var(--accent) 65%, white), var(--accent2));
  border: 4px solid #fff;
  box-shadow: 0 5px 0 rgba(0,0,0,.14), inset 0 2px 10px rgba(255,255,255,.55), 0 0 26px color-mix(in srgb, var(--accent) 55%, transparent);
}
.cell-emoji { font-size: 52px; line-height: 1; animation: bob 3s ease-in-out infinite; }
@keyframes bob { 0%,100% { transform: translateY(0) rotate(-4deg); } 50% { transform: translateY(-7px) rotate(4deg); } }
.cell-name { font-size: 19px; color: #06476e; letter-spacing: 1px; margin-bottom: 6px; }
.cell-desc { font-size: 12.5px; line-height: 1.6; color: #3a6076; min-height: 60px; }
.cell-how {
  margin-top: 10px; font-size: 11.5px; color: #0a5c86;
  background: rgba(126,226,255,.18); border: 1px solid rgba(6,71,110,.16);
  padding: 5px 10px; border-radius: 999px; display: inline-block;
}
.cell-how span { margin-right: 3px; }
.cell-check {
  position: absolute; top: 12px; right: 12px; font-size: 10px; font-weight: bold; color: #5d3700;
  background: linear-gradient(180deg,#ffe082,#ffb300); padding: 3px 9px; border-radius: 999px; box-shadow: 0 2px 0 #c17900;
}

/* 未解锁 */
.collection-cell.locked {
  background: linear-gradient(160deg, rgba(150,170,185,.16), rgba(120,140,155,.1));
  border: 2px dashed rgba(160,190,210,.4);
  box-shadow: inset 0 2px 0 rgba(255,255,255,.12), 0 8px 24px rgba(1,26,44,.25);
  cursor: default; filter: grayscale(.6);
}
.collection-cell.locked:hover { transform: none; }
.cell-lock-wrap {
  position: relative; width: 92px; height: 92px; margin: 0 auto 12px;
  display: grid; place-items: center; border-radius: 26px;
  background: rgba(120,140,155,.22); border: 3px solid rgba(160,190,210,.4);
}
.lock-emoji { font-size: 46px; filter: grayscale(1); opacity: .65; }
.locked-name { color: #7e96a6; }
.locked-desc { color: #8ba1af; }
.locked-how { background: rgba(120,140,155,.16); color: #8499a7; border-color: rgba(120,140,155,.25); }
.lock-progress {
  position: absolute; bottom: -6px; right: -6px; z-index: 2;
  font-size: 11px; font-weight: bold; color: #5d3700;
  background: linear-gradient(180deg,#ffe082,#ffb300);
  padding: 2px 8px; border-radius: 999px; box-shadow: 0 2px 0 #c17900;
}
.cell-rule {
  margin-top: 10px; font-size: 11px; line-height: 1.5; color: #6f8a9a;
  background: rgba(126,226,255,.1); border: 1px dashed rgba(120,140,155,.35);
  padding: 5px 9px; border-radius: 10px; display: inline-block;
}
.cell-rule span { margin-right: 3px; }
.cell-rapport { display: flex; align-items: center; justify-content: center; gap: 7px; margin-top: 9px; font-size: 10.5px; color: #8ba1af; }
.cr-dots { display: inline-flex; gap: 4px; }
.cr-dots i { width: 18px; height: 5px; border-radius: 3px; background: rgba(120,140,155,.28); }
.cr-dots i.on { background: linear-gradient(90deg,#ffb300,#ffe082); box-shadow: 0 0 6px rgba(255,193,7,.5); }

/* ============ 入口提示 ============ */
.note {
  margin-top: 30px; display: flex; align-items: center; justify-content: center; gap: 12px;
  color: #d9f2ff; font-size: 14px; text-align: center;
  background: rgba(3,46,76,.5); border: 1px solid rgba(126,226,255,.3);
  padding: 14px 20px; border-radius: 18px; backdrop-filter: blur(6px);
}
.note span { font-size: 22px; }
.note a { color: #ffe082; font-weight: bold; text-decoration: none; }
.note a:hover { text-decoration: underline; }

/* ============ 详情弹窗 ============ */
.mask {
  position: fixed; inset: 0; z-index: 80; display: grid; place-items: center; padding: 20px;
  background: rgba(2,20,38,.62); backdrop-filter: blur(5px);
}
.detail-dialog {
  position: relative; width: min(500px, 100%); overflow: hidden;
  padding: 26px; border-radius: 26px;
  background: linear-gradient(160deg, #fffdf5, #e6f5ff);
  border: 3px solid var(--accent);
  box-shadow: 0 12px 0 color-mix(in srgb, var(--accent2) 55%, transparent), 0 30px 60px rgba(0,0,0,.5);
}
.dlg-bubbles { position: absolute; inset: 0; overflow: hidden; pointer-events: none; }
.db {
  position: absolute; border-radius: 50%;
  background: radial-gradient(circle at 32% 28%, rgba(255,255,255,.9), rgba(126,226,255,.28) 60%, transparent);
  border: 1px solid rgba(126,226,255,.35); animation: dbRise linear infinite; opacity: 0;
}
@keyframes dbRise {
  0% { transform: translateY(0) scale(.6); opacity: 0; }
  15% { opacity: .5; } 85% { opacity: .35; }
  100% { transform: translateY(-400px) scale(1.1); opacity: 0; }
}
.dlg-close {
  position: absolute; z-index: 3; top: 14px; right: 14px; width: 32px; height: 32px;
  border-radius: 50%; cursor: pointer; border: 2px solid rgba(6,71,110,.3);
  background: rgba(255,255,255,.8); color: #06476e; font-size: 14px; font-weight: bold;
  transition: transform .2s, background .2s;
}
.dlg-close:hover { transform: rotate(90deg); background: #ffe082; }
.detail-head { position: relative; z-index: 2; display: flex; align-items: center; gap: 16px; margin-bottom: 18px; }
.detail-portrait {
  position: relative; width: 76px; height: 76px; flex-shrink: 0; display: grid; place-items: center;
  border-radius: 24px; background: linear-gradient(150deg, var(--accent), var(--accent2));
  border: 3px solid #fff; box-shadow: 0 3px 0 rgba(0,0,0,.14), 0 0 20px color-mix(in srgb, var(--accent) 55%, transparent);
}
.dp-emoji { font-size: 44px; position: relative; z-index: 2; animation: bob 3s ease-in-out infinite; }
.dp-ring { position: absolute; inset: -6px; border-radius: 30px; border: 2px dashed color-mix(in srgb, var(--accent) 60%, transparent); animation: spin 14s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.detail-badge { display: inline-block; font-size: 11px; color: #5d3700; background: linear-gradient(180deg,#ffe082,#ffb300); padding: 3px 10px; border-radius: 999px; margin-bottom: 5px; }
.detail-head h2 { font-size: 22px; color: #06476e; letter-spacing: 1px; }
.detail-head p { font-size: 12.5px; color: #5a7d92; margin-top: 2px; }
.detail-body { position: relative; z-index: 2; }
.detail-body h4 { font-size: 13px; color: #c17900; margin: 14px 0 5px; letter-spacing: 1px; }
.detail-body h4:first-child { margin-top: 0; }
.detail-body p { font-size: 13.5px; line-height: 1.7; color: #2c4a5e; }
.detail-how { background: rgba(126,226,255,.18); border: 1px solid rgba(6,71,110,.14); border-radius: 12px; padding: 8px 12px; }
.detail-how span { margin-right: 4px; }
.detail-progress-line { margin-top: 8px; font-size: 12px; color: #7a93a3; }
.detail-progress-line b { color: #c17900; }
.detail-go {
  position: relative; z-index: 2; width: 100%; margin-top: 20px;
  border: none; background: linear-gradient(180deg,#ffd54f,#ffb300); color: #5d3700;
  padding: 11px; border-radius: 14px; font-family: inherit; font-size: 14px; font-weight: bold;
  cursor: pointer; box-shadow: 0 3px 0 #c17900; transition: filter .2s, transform .2s;
}
.detail-go:hover { filter: brightness(1.06); transform: translateY(-1px); }

/* 弹窗过渡 */
.dialog-enter-active, .dialog-leave-active { transition: opacity .25s ease; }
.dialog-enter-active .detail-dialog { animation: dlgIn .32s cubic-bezier(.2,1.3,.4,1); }
@keyframes dlgIn { from { transform: scale(.86) translateY(20px); opacity: 0; } to { transform: scale(1) translateY(0); opacity: 1; } }
.dialog-enter-from, .dialog-leave-to { opacity: 0; }

@media (max-width: 900px) { .grid { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 560px) { .grid { grid-template-columns: 1fr; } }
</style>
