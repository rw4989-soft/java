<template>
  <div class="lb-grid">
    <!-- 我的记录 -->
    <div class="lb-panel mine">
      <h3>我的记录 <small>{{ title }}</small></h3>
      <div v-if="loading" class="lb-loading">正在翻账本…</div>
      <template v-else>
        <div class="lb-big">{{ board.bestScore || 0 }}</div>
        <p class="lb-rank"><span>{{ board.rankIcon || '🔧' }}</span> {{ board.rank || '铁铲学徒' }}</p>
        <div class="lb-mini">
          <div><b>{{ board.plays || 0 }}</b><span>游玩次数</span></div>
          <div><b>{{ board.bestCombo || 0 }}</b><span>最佳连击</span></div>
          <div><b>{{ board.myRank ? '#' + board.myRank : '—' }}</b><span>全服排名</span></div>
        </div>
      </template>
    </div>

    <!-- 排行榜 -->
    <div class="lb-panel">
      <h3>{{ title }}榜 <small>全服前 10</small></h3>
      <div v-if="loading" class="lb-loading">正在搬榜单…</div>
      <ol v-else-if="board.leaderboard && board.leaderboard.length" class="lb-list">
        <li v-for="row in board.leaderboard" :key="row.pos" :class="{ me: row.mine }">
          <span class="pos" :class="'pos-' + row.pos">{{ row.pos }}</span>
          <span class="who">{{ row.nickname }}</span>
          <b class="sc">{{ row.score }}</b>
        </li>
      </ol>
      <p v-else class="lb-empty">还没人上榜，第一个就是你！</p>
    </div>
  </div>
</template>

<script setup>
defineProps({
  board: { type: Object, required: true },
  loading: { type: Boolean, default: false },
  title: { type: String, default: '游戏' }
})
</script>

<style scoped>
.lb-grid {
  display: grid;
  grid-template-columns: 1fr 1.2fr;
  gap: 16px;
  margin-top: 22px;
}
.lb-panel {
  background: rgba(255, 255, 255, 0.94);
  border: 3px solid #fff;
  border-radius: 22px;
  padding: 18px 20px;
  box-shadow: 0 5px 0 rgba(4, 74, 110, 0.35), 0 16px 30px rgba(1, 26, 44, 0.3);
}
.lb-panel.mine {
  background: linear-gradient(160deg, #fffdf3, #fff6d8);
  border-color: #ffe082;
}
.lb-panel h3 {
  font-size: 16px;
  color: #06476e;
  margin-bottom: 12px;
  letter-spacing: 1px;
}
.lb-panel h3 small { font-size: 11px; color: #7a8f9c; font-weight: normal; letter-spacing: 0; }
.lb-loading { color: #7a8f9c; font-size: 13px; padding: 12px 0; }
.lb-big {
  font-size: 48px;
  font-weight: bold;
  color: #f57f17;
  line-height: 1;
  text-shadow: 0 2px 0 #ffd54f;
}
.lb-rank { color: #8d6e00; font-size: 14px; margin: 6px 0 14px; font-weight: bold; }
.lb-rank span { font-size: 18px; }
.lb-mini { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; }
.lb-mini div { text-align: center; }
.lb-mini b { display: block; font-size: 18px; color: #0a5c86; }
.lb-mini span { font-size: 11px; color: #7a8f9c; }

.lb-list { list-style: none; display: flex; flex-direction: column; gap: 5px; }
.lb-list li {
  display: flex; align-items: center; gap: 10px;
  padding: 5px 10px; border-radius: 10px;
  background: rgba(126, 226, 255, 0.12);
  font-size: 13px;
}
.lb-list li.me { background: linear-gradient(90deg, #ffe082, #ffecb3); color: #5d3700; font-weight: bold; }
.lb-list .pos { width: 24px; height: 24px; flex-shrink: 0; display: grid; place-items: center; border-radius: 50%; background: #cfd8dc; color: #37474f; font-size: 11px; font-weight: bold; }
.lb-list .pos-1 { background: #ffd54f; color: #5d3700; }
.lb-list .pos-2 { background: #cfd8dc; }
.lb-list .pos-3 { background: #ffab91; color: #5d3700; }
.lb-list .who { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #0a5c86; }
.lb-list li.me .who { color: #5d3700; }
.lb-list .sc { color: #f57f17; }
.lb-empty { color: #7a8f9c; font-size: 13px; text-align: center; padding: 20px 0; }

@media (max-width: 700px) {
  .lb-grid { grid-template-columns: 1fr; }
}
</style>
