<template>
  <div class="games-hub">
    <OceanBackdrop />
    <PageNav active="game" :nickname="displayName" @logout="$emit('logout')" />

    <main class="main">
      <!-- 头部 -->
      <section class="hero">
        <span class="hero-kicker">🎮 比奇堡游戏中心</span>
        <h1 class="title">海底游乐场</h1>
        <p class="sub">蟹堡王打烊之后，来玩几局吧。挑一个，开玩！</p>
      </section>

      <!-- 游戏卡片网格 -->
      <section class="grid">
        <article
          v-for="g in games"
          :key="g.code"
          class="game-card"
          :style="{ '--accent': g.accent, '--accent2': g.accent2 }"
          @click="open(g)"
        >
          <div class="gc-glow"></div>
          <div class="gc-emoji">{{ g.emoji }}</div>
          <div class="gc-body">
            <h2>{{ g.name }}</h2>
            <p>{{ g.desc }}</p>
            <div class="gc-meta">
              <span class="gc-tag">{{ g.tag }}</span>
              <span class="gc-diff">
                <i v-for="n in 3" :key="n" :class="{ on: n <= g.difficulty }"></i>
              </span>
            </div>
          </div>
          <span class="gc-play">开始 ▶</span>
          <span v-if="g.coming" class="gc-soon">即将开放</span>
        </article>
      </section>

      <!-- 说明 -->
      <section class="note">
        <span>🏆</span>
        <p>每个小游戏都有独立排行榜，成绩会自动记录到你的账号。段位从「铁铲学徒」一路升到「蟹堡王之星」。</p>
      </section>
    </main>
  </div>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import OceanBackdrop from './OceanBackdrop.vue'
import PageNav from './PageNav.vue'
import { getNickname } from '../utils/auth.js'

defineEmits(['logout'])

const router = useRouter()
const displayName = computed(() => getNickname() || '海绵宝宝')

const games = [
  {
    code: 'burger',
    name: '出餐大作战',
    desc: '按订单顺序堆叠食材，手快有，手慢顾客就走。普通 / 地狱两种模式。',
    emoji: '🍔',
    tag: '手速 · 反应',
    difficulty: 3,
    accent: '#ffb300',
    accent2: '#ff8f00',
    to: { name: 'game' }
  },
  {
    code: 'memory',
    name: '蟹堡记忆翻牌',
    desc: '翻开卡牌找出成对的比奇堡伙伴，考验你的记忆力，步数越少越厉害。',
    emoji: '🃏',
    tag: '记忆 · 配对',
    difficulty: 2,
    accent: '#7e57c2',
    accent2: '#5e35b1',
    to: { name: 'arcade', query: { game: 'memory' } }
  },
  {
    code: 'catch',
    name: '接蟹堡大作战',
    desc: '限时接住掉下来的蟹堡，躲开海底垃圾。连击越高分越高！',
    emoji: '🧀',
    tag: '反应 · 连击',
    difficulty: 2,
    accent: '#26c6da',
    accent2: '#00838f',
    to: { name: 'arcade', query: { game: 'catch' } }
  },
  {
    code: 'quiz',
    name: '比奇堡知识问答',
    desc: '海绵宝宝宇宙知识大考验，从蟹堡秘方到章鱼哥的假期，你能答对几题？',
    emoji: '🧠',
    tag: '知识 · 闯关',
    difficulty: 1,
    accent: '#66bb6a',
    accent2: '#2e7d32',
    to: { name: 'arcade', query: { game: 'quiz' } }
  },
  {
    code: 'puzzle',
    name: '蟹堡拼图',
    desc: '3×3 滑块拼图，把打乱的海底伙伴复原。步数越少、用时越短，分数越高！',
    emoji: '🧩',
    tag: '益智 · 耐心',
    difficulty: 2,
    accent: '#ffa726',
    accent2: '#ef6c00',
    to: { name: 'arcade', query: { game: 'puzzle' } }
  },
  {
    code: 'bubble',
    name: '泡泡大作战',
    desc: '25 秒限时戳泡泡！连击有加成，金泡泡高分，但千万别碰到水雷。',
    emoji: '🫧',
    tag: '手速 · 连击',
    difficulty: 2,
    accent: '#29b6f6',
    accent2: '#0288d1',
    to: { name: 'arcade', query: { game: 'bubble' } }
  }
]

function open(g) {
  if (g.coming) return
  router.push(g.to)
}

onMounted(() => {
  document.title = '海底游乐场 · 海绵宝宝'
})
</script>

<style scoped>
.games-hub { min-height: 100vh; position: relative; }
.main {
  position: relative;
  z-index: 2;
  max-width: 1180px;
  margin: 0 auto;
  padding: 40px 20px 80px;
}

.hero { text-align: center; margin-bottom: 36px; }
.hero-kicker {
  display: inline-block;
  font-size: 13px;
  letter-spacing: 2px;
  color: #b9e6ff;
  background: rgba(3, 46, 76, 0.6);
  border: 1px solid rgba(126, 226, 255, 0.4);
  padding: 6px 16px;
  border-radius: 999px;
  margin-bottom: 14px;
}
.title {
  font-size: clamp(34px, 6vw, 58px);
  color: #ffe082;
  letter-spacing: 6px;
  text-shadow: 0 3px 0 #c17900, 0 6px 0 rgba(0,0,0,.15), 0 0 30px rgba(255,213,79,.5);
  margin-bottom: 12px;
}
.sub { color: #eaf7ff; font-size: 16px; text-shadow: 0 2px 4px rgba(1,26,44,.6); }

.grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 22px;
}

.game-card {
  position: relative;
  display: flex;
  align-items: center;
  gap: 18px;
  padding: 22px 22px;
  border-radius: 26px;
  border: 2px solid rgba(255, 255, 255, 0.55);
  background:
    radial-gradient(circle at 20% 15%, rgba(255,255,255,.35), transparent 45%),
    linear-gradient(150deg, rgba(255,255,255,.92), rgba(232,246,255,.88));
  box-shadow:
    inset 0 2px 0 #fff,
    0 8px 0 rgba(4, 74, 110, 0.35),
    0 22px 40px rgba(1, 26, 44, 0.4);
  cursor: pointer;
  overflow: hidden;
  transition: transform .28s cubic-bezier(.2,1.3,.4,1), box-shadow .28s;
}
.game-card:hover {
  transform: translateY(-9px) rotate(-.4deg);
  box-shadow:
    inset 0 2px 0 #fff,
    0 14px 0 rgba(4, 74, 110, 0.32),
    0 34px 56px rgba(1, 26, 44, 0.5),
    0 0 34px var(--accent);
}
.gc-glow {
  position: absolute;
  right: -40px; top: -40px;
  width: 160px; height: 160px;
  border-radius: 50%;
  background: radial-gradient(circle, var(--accent), transparent 68%);
  opacity: .22;
  pointer-events: none;
}
.gc-emoji {
  width: 78px; height: 78px;
  flex-shrink: 0;
  display: grid;
  place-items: center;
  font-size: 42px;
  border-radius: 22px;
  background: linear-gradient(150deg, var(--accent), var(--accent2));
  border: 3px solid #fff;
  box-shadow: 0 4px 0 rgba(0,0,0,.15), inset 0 2px 6px rgba(255,255,255,.6), 0 0 20px var(--accent);
}
.gc-body { flex: 1; min-width: 0; }
.gc-body h2 {
  font-size: 21px;
  color: #06476e;
  letter-spacing: 1px;
  margin-bottom: 5px;
}
.gc-body p {
  font-size: 13.5px;
  color: #3a6076;
  line-height: 1.5;
  margin-bottom: 9px;
}
.gc-meta { display: flex; align-items: center; gap: 12px; }
.gc-tag {
  font-size: 12px;
  padding: 3px 11px;
  border-radius: 999px;
  background: rgba(6, 71, 110, 0.1);
  color: #0a5c86;
  border: 1px solid rgba(6, 71, 110, 0.2);
}
.gc-diff { display: inline-flex; gap: 3px; }
.gc-diff i {
  width: 14px; height: 5px; border-radius: 3px;
  background: rgba(6, 71, 110, 0.16);
}
.gc-diff i.on { background: var(--accent2); }
.gc-play {
  position: absolute;
  right: 18px; bottom: 16px;
  font-size: 12px;
  font-weight: bold;
  color: #fff;
  background: linear-gradient(180deg, var(--accent), var(--accent2));
  padding: 5px 12px;
  border-radius: 999px;
  box-shadow: 0 2px 0 rgba(0,0,0,.18);
  opacity: 0;
  transform: translateX(8px);
  transition: opacity .25s, transform .25s;
}
.game-card:hover .gc-play { opacity: 1; transform: translateX(0); }
.gc-soon {
  position: absolute; right: 16px; top: 16px;
  font-size: 11px; color: #7a8f9c;
  background: rgba(122,143,156,.15);
  padding: 3px 10px; border-radius: 999px;
}

.note {
  margin-top: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  color: #d9f2ff;
  font-size: 14px;
  text-align: center;
  background: rgba(3, 46, 76, 0.5);
  border: 1px solid rgba(126, 226, 255, 0.3);
  padding: 14px 20px;
  border-radius: 18px;
  backdrop-filter: blur(6px);
}
.note span { font-size: 22px; }

@media (max-width: 760px) {
  .grid { grid-template-columns: 1fr; }
}
</style>
