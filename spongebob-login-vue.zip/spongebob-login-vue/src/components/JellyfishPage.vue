<template>
  <div class="jelly-page">
    <OceanBackdrop />
    <PageNav active="profile" :nickname="displayName" @logout="$emit('logout')" />

    <main class="main">
      <section class="hero">
        <span class="hero-kicker">🪼 专属伙伴</span>
        <h1 class="title">水母养成日记</h1>
        <p class="sub">照顾一只属于你的水母，陪它一起长大。</p>
      </section>

      <div class="layout">
        <!-- 水母展示 -->
        <section class="tank">
          <div class="tank-water">
            <span v-for="i in 8" :key="i" class="tank-bubble" :style="{ left: (i * 12) + '%', animationDelay: (i * 0.5) + 's' }"></span>
            <div class="jelly" :class="{ happy: jelly.mood >= 70 }" @click="interact">
              <div class="jelly-bell">{{ stage.emoji }}</div>
              <div class="jelly-tails"><i v-for="n in 4" :key="n"></i></div>
            </div>
            <div class="tank-floor"></div>
          </div>
          <div class="jelly-name">
            <span>{{ jelly.name }}</span>
            <button class="rename" @click="openRename" title="改名">✏️</button>
          </div>
          <p class="stage-line">{{ stage.name }} · {{ stage.desc }}</p>
        </section>

        <!-- 状态与操作 -->
        <section class="side">
          <div class="status-card">
            <h3>当前状态</h3>
            <div class="stat">
              <div class="stat-top"><span>🍽️ 饱食度</span><b>{{ jelly.hunger }}/100</b></div>
              <div class="meter"><div class="fill hunger" :style="{ width: jelly.hunger + '%' }"></div></div>
              <small>{{ hungerLabel(jelly.hunger) }}</small>
            </div>
            <div class="stat">
              <div class="stat-top"><span>💗 心情</span><b>{{ jelly.mood }}/100</b></div>
              <div class="meter"><div class="fill mood" :style="{ width: jelly.mood + '%' }"></div></div>
              <small>{{ moodLabel(jelly.mood) }}</small>
            </div>
            <div class="stat">
              <div class="stat-top"><span>✨ 成长</span><b>{{ jelly.exp }} EXP</b></div>
              <div class="meter"><div class="fill exp" :style="{ width: expPercent + '%' }"></div></div>
              <small>{{ nextStage ? '距离「' + nextStage.name + '」还差 ' + (nextStage.min - jelly.exp) + ' EXP' : '已达最终形态！' }}</small>
            </div>
          </div>

          <div class="actions">
            <button class="act feed" @click="doFeed"><span>🍤</span><b>喂食</b><small>饱食 +18</small></button>
            <button class="act play" @click="doPlay"><span>🎾</span><b>玩耍</b><small>心情 +14</small></button>
          </div>
          <p class="care-tip">💡 点击水母也能互动。状态会随时间慢慢下降，记得常回来看看它～</p>
        </section>
      </div>

      <!-- 成长阶段 -->
      <section class="stages">
        <h3>🌟 成长图鉴</h3>
        <div class="stage-list">
          <div v-for="s in all" :key="s.name" class="stage-item" :class="{ reached: jelly.exp >= s.min }">
            <span>{{ s.emoji }}</span>
            <b>{{ s.name }}</b>
            <small>{{ s.min }} EXP</small>
          </div>
        </div>
      </section>

      <div v-if="toast" class="toast">{{ toast }}</div>

      <!-- 改名弹窗 -->
      <div v-if="renaming" class="mask" @click.self="renaming = false">
        <div class="dialog">
          <h3>给水母起个名字</h3>
          <input v-model="newName" maxlength="12" @keyup.enter="saveName" placeholder="输入名字" />
          <div class="dlg-btns">
            <button class="ghost" @click="renaming = false">取消</button>
            <button class="primary" @click="saveName">保存</button>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import OceanBackdrop from './OceanBackdrop.vue'
import PageNav from './PageNav.vue'
import { getNickname } from '../utils/auth.js'
import {
  getJelly, getStage, getNextStage, allStages,
  feed, play, rename, moodLabel, hungerLabel
} from '../utils/jellyfish.js'
import { sfx } from '../utils/sound.js'

defineEmits(['logout'])
const displayName = computed(() => getNickname() || '海绵宝宝')

const jelly = ref(getJelly())
const stage = computed(() => getStage(jelly.value.exp))
const nextStage = computed(() => getNextStage(jelly.value.exp))
const all = allStages()
const expPercent = computed(() => {
  const start = stage.value.min
  const end = nextStage.value ? nextStage.value.min : start
  if (end <= start) return 100
  return Math.min(100, Math.round((jelly.value.exp - start) / (end - start) * 100))
})
const toast = ref('')
const renaming = ref(false)
const newName = ref('')

function flash(msg) { toast.value = msg; setTimeout(() => { toast.value = '' }, 1800) }
function doFeed() {
  jelly.value = feed()
  sfx.coin()
  flash(jelly.value.name + ' 吃得饱饱的！✨')
}
function doPlay() {
  jelly.value = play()
  sfx.good()
  flash('玩得好开心呀！💗')
}
function interact() { doPlay() }
function openRename() { newName.value = jelly.value.name; renaming.value = true }
function saveName() {
  jelly.value = rename(newName.value)
  renaming.value = false
  flash('好名字！以后就叫你 ' + jelly.value.name + ' 啦')
}

onMounted(() => {
  document.title = '水母养成 · 海绵宝宝'
  jelly.value = getJelly()
})
</script>

<style scoped>
.jelly-page { min-height: 100vh; position: relative; }
.main { position: relative; z-index: 2; max-width: 960px; margin: 0 auto; padding: 40px 20px 80px; }
.hero { text-align: center; margin-bottom: 26px; }
.hero-kicker { display: inline-block; font-size: 13px; letter-spacing: 2px; color: #b9e6ff; background: rgba(3,46,76,.6); border: 1px solid rgba(126,226,255,.4); padding: 6px 16px; border-radius: 999px; margin-bottom: 12px; }
.title { font-size: clamp(32px,6vw,50px); color: #ffe082; letter-spacing: 5px; text-shadow: 0 3px 0 #c17900, 0 0 30px rgba(255,213,79,.5); margin-bottom: 8px; }
.sub { color: #eaf7ff; font-size: 15px; }

.layout { display: grid; grid-template-columns: 1.1fr 1fr; gap: 20px; margin-bottom: 20px; }
.tank, .status-card, .stages { background: rgba(3,46,76,.5); border: 2px solid rgba(126,226,255,.3); border-radius: 22px; padding: 20px; backdrop-filter: blur(6px); }
.tank { text-align: center; }
.tank-water { position: relative; height: 300px; border-radius: 18px; overflow: hidden; background: linear-gradient(180deg, rgba(6,90,130,.55), rgba(3,55,90,.75)); border: 2px solid rgba(126,226,255,.4); }
.tank-bubble { position: absolute; bottom: -20px; width: 10px; height: 10px; border-radius: 50%; background: rgba(255,255,255,.5); animation: rise 5s linear infinite; }
@keyframes rise { 0% { transform: translateY(0); opacity: 0; } 20% { opacity: .8; } 100% { transform: translateY(-320px); opacity: 0; } }
.jelly { position: absolute; left: 50%; top: 42%; transform: translate(-50%,-50%); cursor: pointer; animation: swim 3.2s ease-in-out infinite; transition: filter .2s; }
.jelly:hover { filter: brightness(1.15); }
.jelly.happy .jelly-bell { box-shadow: 0 0 30px rgba(255,182,255,.8); }
@keyframes swim { 0%,100% { transform: translate(-50%,-50%) scaleY(1); } 50% { transform: translate(-50%,-58%) scaleY(1.06); } }
.jelly-bell { font-size: 82px; line-height: 1; filter: drop-shadow(0 6px 10px rgba(0,0,0,.3)); }
.jelly-tails { display: flex; justify-content: center; gap: 8px; margin-top: -6px; }
.jelly-tails i { width: 6px; height: 34px; background: linear-gradient(180deg, rgba(200,150,255,.8), transparent); border-radius: 0 0 6px 6px; animation: tail 1.4s ease-in-out infinite; }
.jelly-tails i:nth-child(2) { animation-delay: .2s; height: 42px; }
.jelly-tails i:nth-child(3) { animation-delay: .4s; height: 38px; }
.jelly-tails i:nth-child(4) { animation-delay: .6s; }
@keyframes tail { 0%,100% { transform: skewX(-8deg); } 50% { transform: skewX(8deg); } }
.tank-floor { position: absolute; bottom: 0; left: 0; right: 0; height: 26px; background: linear-gradient(180deg, rgba(255,213,79,.3), rgba(193,121,0,.4)); }
.jelly-name { margin-top: 14px; display: flex; align-items: center; justify-content: center; gap: 8px; }
.jelly-name span { color: #fff8e1; font-size: 20px; font-weight: bold; }
.rename { border: none; background: rgba(126,226,255,.2); border-radius: 8px; padding: 3px 7px; cursor: pointer; font-size: 14px; }
.stage-line { color: #b9e6ff; font-size: 13px; margin-top: 6px; }

.status-card h3, .stages h3 { color: #ffe082; font-size: 17px; margin-bottom: 16px; }
.stat { margin-bottom: 16px; }
.stat-top { display: flex; justify-content: space-between; font-size: 13px; color: #eaf7ff; margin-bottom: 5px; }
.stat-top b { color: #ffe082; }
.meter { height: 12px; background: rgba(0,0,0,.25); border-radius: 999px; overflow: hidden; }
.fill { height: 100%; border-radius: 999px; transition: width .4s; }
.fill.hunger { background: linear-gradient(90deg,#ffb300,#ffd54f); }
.fill.mood { background: linear-gradient(90deg,#ec407a,#f48fb1); }
.fill.exp { background: linear-gradient(90deg,#7e57c2,#b39ddb); }
.stat small { font-size: 11px; color: #8fdcff; }

.actions { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 4px; }
.act { display: flex; flex-direction: column; align-items: center; gap: 2px; border: 2px solid; border-radius: 16px; padding: 14px; font-family: inherit; cursor: pointer; transition: transform .18s; }
.act:hover { transform: translateY(-4px); }
.act.feed { border-color: #ffb300; background: rgba(255,179,0,.16); }
.act.play { border-color: #ec407a; background: rgba(236,64,122,.16); }
.act span { font-size: 30px; }
.act b { color: #fff8e1; font-size: 15px; }
.act small { color: #b9e6ff; font-size: 11px; }
.care-tip { color: #8fdcff; font-size: 12px; line-height: 1.5; margin-top: 14px; }

.stage-list { display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; }
.stage-item { text-align: center; padding: 12px 4px; border-radius: 14px; background: rgba(120,140,155,.14); border: 1px solid rgba(150,170,180,.25); opacity: .5; }
.stage-item.reached { opacity: 1; background: rgba(186,104,200,.2); border-color: #ce93d8; }
.stage-item span { font-size: 28px; display: block; }
.stage-item b { display: block; color: #eaf7ff; font-size: 12px; margin-top: 4px; }
.stage-item small { color: #b9e6ff; font-size: 10px; }

.toast { position: fixed; bottom: 40px; left: 50%; transform: translateX(-50%); z-index: 90; background: rgba(255,253,235,.98); border: 3px solid #ba68c8; color: #6a1b9a; font-weight: bold; font-size: 14px; padding: 12px 24px; border-radius: 999px; box-shadow: 0 8px 24px rgba(0,0,0,.4); }
.mask { position: fixed; inset: 0; z-index: 80; display: grid; place-items: center; padding: 20px; background: rgba(2,20,36,.65); backdrop-filter: blur(4px); }
.dialog { width: min(340px,100%); text-align: center; background: linear-gradient(160deg,#fffdf5,#f3eafb); border: 3px solid #ba68c8; border-radius: 22px; padding: 24px; box-shadow: 0 12px 0 rgba(106,27,154,.35); }
.dialog h3 { color: #6a1b9a; font-size: 19px; margin-bottom: 16px; }
.dialog input { width: 100%; box-sizing: border-box; border: 2px solid #ce93d8; border-radius: 12px; padding: 10px 12px; font-family: inherit; font-size: 15px; outline: none; }
.dlg-btns { display: flex; gap: 10px; justify-content: center; margin-top: 16px; }
.ghost, .primary { font-family: inherit; font-size: 14px; font-weight: bold; padding: 8px 22px; border-radius: 999px; cursor: pointer; }
.ghost { border: 2px solid #ce93d8; background: transparent; color: #6a1b9a; }
.primary { border: none; background: #ab47bc; color: #fff; }

@media (max-width: 760px) { .layout { grid-template-columns: 1fr; } .stage-list { grid-template-columns: repeat(3, 1fr); } }
</style>
