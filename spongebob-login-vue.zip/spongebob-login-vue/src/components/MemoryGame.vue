<template>
  <div class="mini-game">
    <OceanBackdrop />
    <PageNav active="game" :nickname="displayName" @logout="$emit('logout')" />

    <main class="main">
      <router-link to="/games" class="back">‹ 游戏中心</router-link>

      <section class="head">
        <span class="g-icon">🃏</span>
        <div>
          <h1>蟹堡记忆翻牌</h1>
          <p>翻开卡牌，找出成对的比奇堡伙伴。步数越少、用时越短，分越高！</p>
        </div>
      </section>

      <!-- 开始面板 -->
      <section v-if="phase === 'idle'" class="start-panel">
        <div class="preview-cards" aria-hidden="true">
          <span v-for="(e, i) in previewEmojis" :key="i" :style="{ transform: `rotate(${(i - 3) * 8}deg) translateY(${Math.abs(i - 3) * 4}px)` }">{{ e }}</span>
        </div>
        <h2>准备好了吗？</h2>
        <p>16 张卡牌 · 8 对伙伴 · 记住位置</p>
        <button class="cta" @click="start">开始翻牌</button>
        <GameLeaderboard :board="board" :loading="loading" title="记忆" />
      </section>

      <!-- 游戏面板 -->
      <section v-else class="play-panel">
        <div class="hud">
          <div class="hs"><span>步数</span><b>{{ moves }}</b></div>
          <div class="hs"><span>用时</span><b>{{ elapsed }}s</b></div>
          <div class="hs"><span>已配对</span><b>{{ matchedPairs }}/8</b></div>
          <button class="quit" @click="reset">重开</button>
        </div>

        <div class="cards">
          <button
            v-for="(card, i) in cards"
            :key="card.uid"
            type="button"
            class="card"
            :class="{ flipped: card.flipped || card.matched, matched: card.matched, wrong: card.wrong }"
            @click="flip(i)"
            :disabled="card.flipped || card.matched || locked"
          >
            <span class="face back">🫧</span>
            <span class="face front">{{ card.emoji }}</span>
          </button>
        </div>
        <p class="tip">点击卡牌翻开 · 连续翻到两张相同的即可配对</p>
      </section>

      <!-- 结算弹窗 -->
      <div v-if="phase === 'done'" class="overlay" @click.self="closeResult">
        <div class="result-card">
          <div class="r-emoji">{{ newRecord ? '🏆' : '🎉' }}</div>
          <h2>{{ newRecord ? '新纪录！' : '挑战完成！' }}</h2>
          <div class="r-score">{{ finalScore }} <small>分</small></div>
          <p>步数 {{ finalMoves }} · 用时 {{ finalTime }}s</p>
          <p v-if="saved" class="r-saved">成绩已记录 ✓</p>
          <div class="r-btns">
            <button class="cta small" @click="start">再来一局</button>
            <button class="ghost" @click="closeResult">看排行榜</button>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue'
import OceanBackdrop from './OceanBackdrop.vue'
import PageNav from './PageNav.vue'
import GameLeaderboard from './GameLeaderboard.vue'
import { getNickname } from '../utils/auth.js'
import { useGameBoard } from '../utils/useGameBoard.js'

defineEmits(['logout'])
const displayName = computed(() => getNickname() || '海绵宝宝')

const { board, loading, lastResult, commit } = useGameBoard('memory')

const EMOJIS = ['🧽', '⭐', '🐙', '🦀', '🐿️', '🍍', '🐟', '🦐']
const previewEmojis = ['🧽', '⭐', '🐙', '🦀', '🐿️', '🍍']

const phase = ref('idle')
const cards = ref([])
const moves = ref(0)
const matchedPairs = ref(0)
const locked = ref(false)
const first = ref(-1)
const second = ref(-1)
const elapsed = ref(0)
let timer = null

const finalScore = ref(0)
const finalMoves = ref(0)
const finalTime = ref(0)
const newRecord = ref(false)
const saved = ref(false)

function shuffle(arr) {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

function start() {
  const deck = shuffle([...EMOJIS, ...EMOJIS]).map((emoji, idx) => ({
    uid: idx, emoji, flipped: false, matched: false, wrong: false
  }))
  cards.value = shuffle(deck)
  moves.value = 0
  matchedPairs.value = 0
  first.value = -1
  second.value = -1
  locked.value = false
  elapsed.value = 0
  saved.value = false
  newRecord.value = false
  phase.value = 'playing'
  clearInterval(timer)
  timer = setInterval(() => { elapsed.value++ }, 1000)
}

function reset() {
  clearInterval(timer)
  phase.value = 'idle'
}

function flip(i) {
  const card = cards.value[i]
  if (!card || card.flipped || card.matched || locked.value) return
  card.flipped = true

  if (first.value === -1) {
    first.value = i
    return
  }

  second.value = i
  moves.value++
  const a = cards.value[first.value]
  const b = cards.value[second.value]

  if (a.emoji === b.emoji) {
    a.matched = true
    b.matched = true
    matchedPairs.value++
    first.value = -1
    second.value = -1
    if (matchedPairs.value === EMOJIS.length) finish()
  } else {
    locked.value = true
    a.wrong = true
    b.wrong = true
    setTimeout(() => {
      a.flipped = false; b.flipped = false
      a.wrong = false; b.wrong = false
      first.value = -1
      second.value = -1
      locked.value = false
    }, 750)
  }
}

async function finish() {
  clearInterval(timer)
  const base = 1600
  const score = Math.max(100, Math.round(base - moves.value * 12 - elapsed.value * 3))
  finalScore.value = score
  finalMoves.value = moves.value
  finalTime.value = elapsed.value
  phase.value = 'done'
  const r = await commit({ score, combo: matchedPairs.value, count: matchedPairs.value })
  saved.value = r.ok
  newRecord.value = Boolean(lastResult.value?.newRecord)
}

function closeResult() { phase.value = 'idle' }

onMounted(() => { document.title = '蟹堡记忆翻牌 · 海绵宝宝' })
onUnmounted(() => clearInterval(timer))
</script>

<style scoped>
.mini-game { min-height: 100vh; position: relative; }
.main { position: relative; z-index: 2; max-width: 900px; margin: 0 auto; padding: 24px 20px 80px; }
.back { display: inline-block; color: #b9e6ff; text-decoration: none; font-size: 14px; margin-bottom: 16px; }
.back:hover { color: #ffe082; }
.head { display: flex; align-items: center; gap: 16px; margin-bottom: 24px; }
.g-icon { font-size: 50px; filter: drop-shadow(0 4px 6px rgba(1,26,44,.5)); }
.head h1 { font-size: 30px; color: #ffe082; letter-spacing: 2px; text-shadow: 0 2px 0 #c17900, 0 0 20px rgba(255,213,79,.4); }
.head p { color: #eaf7ff; font-size: 14px; margin-top: 4px; }

.start-panel { text-align: center; background: rgba(3,46,76,.55); border: 2px solid rgba(126,226,255,.35); border-radius: 28px; padding: 34px 24px; backdrop-filter: blur(8px); }
.preview-cards { display: flex; justify-content: center; margin-bottom: 8px; height: 70px; }
.preview-cards span { width: 54px; height: 64px; margin: 0 -8px; display: grid; place-items: center; font-size: 30px; border-radius: 10px; background: linear-gradient(150deg,#fff,#e3f2fd); border: 3px solid #fff; box-shadow: 0 4px 10px rgba(1,26,44,.4); }
.start-panel h2 { color: #fff8e1; font-size: 24px; }
.start-panel > p { color: #b9e6ff; margin: 8px 0 20px; }
.cta { border: none; border-radius: 999px; padding: 13px 40px; font-family: inherit; font-size: 17px; font-weight: bold; color: #5d3700; background: linear-gradient(180deg,#ffd54f,#ffb300); box-shadow: 0 4px 0 #c17900, 0 8px 20px rgba(1,26,44,.4); cursor: pointer; transition: transform .2s, box-shadow .2s; }
.cta:hover { transform: translateY(-2px); box-shadow: 0 6px 0 #c17900, 0 0 24px rgba(255,213,79,.7); }
.cta.small { padding: 10px 26px; font-size: 15px; }

.play-panel { background: rgba(3,46,76,.5); border: 2px solid rgba(126,226,255,.35); border-radius: 28px; padding: 22px; backdrop-filter: blur(8px); }
.hud { display: flex; gap: 12px; align-items: center; margin-bottom: 20px; flex-wrap: wrap; }
.hs { flex: 1; min-width: 80px; text-align: center; background: rgba(255,255,255,.12); border-radius: 14px; padding: 8px; }
.hs span { display: block; font-size: 11px; color: #b9e6ff; }
.hs b { display: block; font-size: 22px; color: #ffe082; }
.quit { border: 2px solid rgba(126,226,255,.5); background: rgba(126,226,255,.1); color: #eaf7ff; border-radius: 12px; padding: 8px 16px; font-family: inherit; font-weight: bold; cursor: pointer; }
.quit:hover { background: rgba(126,226,255,.25); }

.cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; }
.card { position: relative; aspect-ratio: 1; border: none; background: transparent; cursor: pointer; perspective: 600px; padding: 0; }
.card .face { position: absolute; inset: 0; display: grid; place-items: center; border-radius: 14px; backface-visibility: hidden; transition: transform .4s, box-shadow .3s; font-size: 40px; }
.card .back { background: linear-gradient(150deg,#ffd54f,#ff8f00); border: 3px solid #fff; box-shadow: 0 4px 0 #c17900, 0 6px 12px rgba(1,26,44,.4); }
.card .front { background: linear-gradient(150deg,#fff,#e3f2fd); border: 3px solid #fff; transform: rotateY(180deg); box-shadow: 0 4px 0 rgba(4,74,110,.5); }
.card.flipped .back { transform: rotateY(180deg); }
.card.flipped .front { transform: rotateY(0); }
.card.matched .front { background: linear-gradient(150deg,#c8ffc4,#81c784); box-shadow: 0 0 18px #81c784; }
.card.wrong .front { background: linear-gradient(150deg,#ffcdd2,#ef9a9a); }
.card:disabled { cursor: default; }
.tip { text-align: center; color: #b9e6ff; font-size: 13px; margin-top: 16px; }

.overlay { position: fixed; inset: 0; z-index: 100; display: grid; place-items: center; background: rgba(1,20,35,.65); backdrop-filter: blur(4px); padding: 20px; }
.result-card { width: min(380px, 100%); text-align: center; background: linear-gradient(160deg,#fffdf3,#fff3cf); border: 4px solid #ffe082; border-radius: 28px; padding: 30px 24px; box-shadow: 0 20px 50px rgba(0,0,0,.5); }
.r-emoji { font-size: 60px; }
.result-card h2 { color: #e65100; font-size: 26px; margin: 6px 0; }
.r-score { font-size: 52px; font-weight: bold; color: #f57f17; text-shadow: 0 2px 0 #ffd54f; }
.r-score small { font-size: 18px; }
.result-card p { color: #6d4c00; margin: 6px 0; }
.r-saved { color: #2e7d32 !important; font-weight: bold; }
.r-btns { display: flex; gap: 12px; justify-content: center; margin-top: 18px; }
.ghost { border: 2px solid #ffb300; background: #fff; color: #e65100; border-radius: 999px; padding: 9px 22px; font-family: inherit; font-weight: bold; cursor: pointer; }
.ghost:hover { background: #fff8e1; }

@media (max-width: 560px) {
  .cards { gap: 8px; }
  .card .face { font-size: 30px; }
}
</style>
