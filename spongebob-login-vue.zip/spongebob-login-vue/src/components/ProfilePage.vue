<template>
  <div class="profile-page">
    <OceanBackdrop />
    <PageNav active="profile" :nickname="summary.nickname" @logout="$emit('logout')" />

    <main class="main">
      <section class="hero">
        <span class="hero-kicker">🌟 我的海底家园</span>
        <h1 class="title">玩家名片</h1>
        <p class="sub">这一路在比奇堡的点点滴滴，都记录在这里。</p>
      </section>

      <!-- 名片主体 -->
      <section class="idcard">
        <div class="idcard-glow"></div>
        <div class="avatar-wrap">
          <span class="avatar">🧽</span>
          <span class="avatar-badge">{{ topGame.rankIcon }}</span>
        </div>
        <div class="idcard-info">
          <h2>{{ summary.nickname }}</h2>
          <p class="idline">比奇堡荣誉居民 · <span>{{ topGame.rank }}</span></p>
          <div class="id-stats">
            <div><b>{{ summary.gamePlays }}</b><span>总场次</span></div>
            <div><b>{{ summary.collectionOwned }}/{{ summary.collectionTotal }}</b><span>图鉴</span></div>
            <div><b>{{ summary.rapport }}</b><span>默契</span></div>
            <div><b>{{ summary.checkinTotal }}</b><span>签到</span></div>
          </div>
        </div>
      </section>

      <!-- 五项数据总览 -->
      <section class="overview">
        <div class="ov-card" v-for="o in overviews" :key="o.label" :style="{ '--c': o.color }">
          <span class="ov-icon">{{ o.icon }}</span>
          <div class="ov-num">{{ o.value }}<small>{{ o.suffix }}</small></div>
          <div class="ov-label">{{ o.label }}</div>
        </div>
      </section>

      <!-- 游戏成绩 -->
      <section class="panel">
        <div class="panel-head">
          <h3>🎮 游戏成绩</h3>
          <button class="mini-btn" @click="refresh" :disabled="refreshing">{{ refreshing ? '刷新中…' : '刷新成绩' }}</button>
        </div>
        <div class="game-list">
          <div class="game-row" v-for="g in games" :key="g.code">
            <span class="gr-emoji">{{ g.emoji }}</span>
            <span class="gr-name">{{ g.name }}</span>
            <span class="gr-rank">{{ g.rankIcon }} {{ g.rank }}</span>
            <span class="gr-score">{{ g.bestScore }} <small>分</small></span>
            <span class="gr-plays">{{ g.plays }} 局</span>
          </div>
        </div>
      </section>

      <!-- 我的小屋：通往四个新模块 -->
      <section class="panel">
        <div class="panel-head"><h3>🏠 我的小屋</h3></div>
        <div class="links-grid">
          <router-link to="/achievements" class="link-card" style="--c:#ffb300">
            <span class="lc-icon">🏅</span>
            <b>成就徽章</b>
            <small>{{ achSummary.unlocked }}/{{ achSummary.total }} 已解锁</small>
            <span class="lc-go">进入 ›</span>
          </router-link>
          <router-link to="/checkin" class="link-card" style="--c:#4fc3f7">
            <span class="lc-icon">📅</span>
            <b>每日签到</b>
            <small>连续 {{ summary.checkinStreak }} 天</small>
            <span class="lc-go">进入 ›</span>
          </router-link>
          <router-link to="/jellyfish" class="link-card" style="--c:#ba68c8">
            <span class="lc-icon">🪼</span>
            <b>水母日记</b>
            <small>成长 {{ summary.jellyExp }} 点</small>
            <span class="lc-go">进入 ›</span>
          </router-link>
          <router-link to="/wishes" class="link-card" style="--c:#81c784">
            <span class="lc-icon">💭</span>
            <b>许愿池</b>
            <small>{{ summary.wishes }} 条心愿</small>
            <span class="lc-go">进入 ›</span>
          </router-link>
        </div>
      </section>

      <p class="foot-note">数据来自你的本地游玩记录与游戏排行榜 · 每次进入自动刷新成绩</p>
    </main>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import OceanBackdrop from './OceanBackdrop.vue'
import PageNav from './PageNav.vue'
import { getProfileSummary, getGameStats, refreshGameStats } from '../utils/statsCenter.js'
import { getAchievementSummary, syncUnlocked } from '../utils/achievements.js'

defineEmits(['logout'])

const summary = ref(getProfileSummary())
const games = ref(getGameStats())
const achSummary = ref(getAchievementSummary())
const refreshing = ref(false)

const topGame = computed(() => {
  const played = games.value.filter(g => g.plays > 0)
  if (!played.length) return { rank: '初来乍到', rankIcon: '🐚' }
  return played.reduce((a, b) => (b.bestScore > a.bestScore ? b : a))
})

const overviews = computed(() => [
  { icon: '🎮', label: '游戏总场次', value: summary.value.gamePlays, suffix: '局', color: '#ffb300' },
  { icon: '🏅', label: '成就解锁', value: achSummary.value.unlocked, suffix: '/' + achSummary.value.total, color: '#ff7043' },
  { icon: '📖', label: '图鉴收集', value: summary.value.collectionOwned, suffix: '/' + summary.value.collectionTotal, color: '#42a5f5' },
  { icon: '💬', label: '角色默契', value: summary.value.rapport, suffix: '点', color: '#ab47bc' },
  { icon: '📅', label: '累计签到', value: summary.value.checkinTotal, suffix: '天', color: '#26c6da' }
])

async function refresh() {
  if (refreshing.value) return
  refreshing.value = true
  try {
    await refreshGameStats()
    games.value = getGameStats()
    summary.value = getProfileSummary()
    syncUnlocked()
    achSummary.value = getAchievementSummary()
  } finally {
    refreshing.value = false
  }
}

onMounted(() => {
  document.title = '玩家名片 · 海绵宝宝'
  syncUnlocked()
  achSummary.value = getAchievementSummary()
  refresh()
})
</script>

<style scoped>
.profile-page { min-height: 100vh; position: relative; }
.main { position: relative; z-index: 2; max-width: 960px; margin: 0 auto; padding: 40px 20px 80px; }
.hero { text-align: center; margin-bottom: 26px; }
.hero-kicker { display: inline-block; font-size: 13px; letter-spacing: 2px; color: #b9e6ff; background: rgba(3,46,76,.6); border: 1px solid rgba(126,226,255,.4); padding: 6px 16px; border-radius: 999px; margin-bottom: 12px; }
.title { font-size: clamp(32px,6vw,52px); color: #ffe082; letter-spacing: 5px; text-shadow: 0 3px 0 #c17900, 0 0 30px rgba(255,213,79,.5); margin-bottom: 8px; }
.sub { color: #eaf7ff; font-size: 15px; text-shadow: 0 2px 4px rgba(1,26,44,.6); }

.idcard { position: relative; display: flex; align-items: center; gap: 22px; padding: 26px 28px; border-radius: 26px; overflow: hidden; background: linear-gradient(135deg, rgba(255,213,79,.95), rgba(255,167,0,.9)); border: 3px solid #fff; box-shadow: 0 8px 0 rgba(193,121,0,.55), 0 22px 44px rgba(1,26,44,.4); margin-bottom: 22px; }
.idcard-glow { position: absolute; right: -30px; top: -60px; width: 220px; height: 220px; border-radius: 50%; background: radial-gradient(circle, rgba(255,255,255,.6), transparent 65%); pointer-events: none; }
.avatar-wrap { position: relative; flex-shrink: 0; }
.avatar { width: 92px; height: 92px; display: grid; place-items: center; font-size: 52px; background: #fff; border: 4px solid #fff; border-radius: 26px; box-shadow: 0 6px 0 rgba(193,121,0,.5); }
.avatar-badge { position: absolute; right: -8px; bottom: -8px; font-size: 26px; background: #fff; border-radius: 50%; padding: 2px; box-shadow: 0 3px 8px rgba(0,0,0,.2); }
.idcard-info { position: relative; z-index: 1; color: #5d3700; }
.idcard-info h2 { font-size: 28px; letter-spacing: 2px; margin-bottom: 2px; }
.idline { font-size: 14px; font-weight: bold; opacity: .85; }
.id-stats { display: flex; gap: 22px; margin-top: 14px; flex-wrap: wrap; }
.id-stats div { text-align: center; }
.id-stats b { display: block; font-size: 20px; }
.id-stats span { font-size: 12px; opacity: .75; }

.overview { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-bottom: 22px; }
.ov-card { text-align: center; background: rgba(255,255,255,.92); border: 2px solid var(--c); border-radius: 18px; padding: 16px 8px; box-shadow: 0 4px 0 rgba(4,74,110,.3); }
.ov-icon { font-size: 26px; }
.ov-num { font-size: 24px; font-weight: bold; color: #0a5c86; margin-top: 4px; }
.ov-num small { font-size: 13px; color: #5a7a8a; }
.ov-label { font-size: 12px; color: #3a6076; margin-top: 2px; }

.panel { background: rgba(3,46,76,.5); border: 2px solid rgba(126,226,255,.3); border-radius: 22px; padding: 20px 22px; margin-bottom: 20px; backdrop-filter: blur(6px); }
.panel-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }
.panel-head h3 { color: #ffe082; font-size: 18px; letter-spacing: 1px; }
.mini-btn { border: 2px solid rgba(126,226,255,.5); background: rgba(126,226,255,.12); color: #b9e6ff; font-family: inherit; font-size: 12px; padding: 6px 14px; border-radius: 999px; cursor: pointer; }
.mini-btn:hover:not(:disabled) { background: rgba(126,226,255,.24); color: #fff; }
.mini-btn:disabled { opacity: .6; cursor: default; }

.game-list { display: flex; flex-direction: column; gap: 8px; }
.game-row { display: flex; align-items: center; gap: 12px; background: rgba(255,255,255,.08); border: 1px solid rgba(126,226,255,.2); border-radius: 12px; padding: 10px 14px; font-size: 14px; }
.gr-emoji { font-size: 22px; }
.gr-name { flex: 1; color: #eaf7ff; font-weight: bold; }
.gr-rank { color: #8fdcff; font-size: 12px; }
.gr-score { color: #ffe082; font-weight: bold; min-width: 72px; text-align: right; }
.gr-score small { font-size: 11px; font-weight: normal; }
.gr-plays { color: #b9e6ff; font-size: 12px; min-width: 44px; text-align: right; }

.links-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }
.link-card { position: relative; text-align: center; padding: 20px 10px 16px; border-radius: 18px; text-decoration: none; background: rgba(255,255,255,.92); border: 2px solid var(--c); box-shadow: 0 4px 0 rgba(4,74,110,.3); transition: transform .2s, box-shadow .2s; }
.link-card:hover { transform: translateY(-6px); box-shadow: 0 10px 0 rgba(4,74,110,.28), 0 0 24px var(--c); }
.lc-icon { font-size: 34px; display: block; }
.link-card b { display: block; color: #0a5c86; font-size: 15px; margin-top: 6px; }
.link-card small { display: block; color: #5a7a8a; font-size: 12px; margin-top: 3px; }
.lc-go { display: inline-block; margin-top: 10px; font-size: 12px; color: #fff; background: var(--c); padding: 3px 12px; border-radius: 999px; }
.foot-note { text-align: center; color: #8fdcff; font-size: 12px; margin-top: 24px; opacity: .85; }

@media (max-width: 760px) {
  .overview { grid-template-columns: repeat(3, 1fr); }
  .links-grid { grid-template-columns: repeat(2, 1fr); }
  .idcard { flex-direction: column; text-align: center; }
  .id-stats { justify-content: center; }
}
@media (max-width: 460px) { .overview { grid-template-columns: repeat(2, 1fr); } }
</style>
