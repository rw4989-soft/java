<template>
  <div class="mini-game">
    <OceanBackdrop />
    <PageNav active="game" :nickname="displayName" @logout="$emit('logout')" />

    <main class="main">
      <router-link to="/games" class="back">‹ 游戏中心</router-link>

      <section class="head">
        <span class="g-icon">🧩</span>
        <div>
          <h1>蟹堡拼图</h1>
          <p>把打乱的海底拼图复原！点击与空格相邻的图片滑动，步数越少分越高。</p>
        </div>
      </section>

      <section v-if="phase === 'idle'" class="start-panel">
        <div class="preview-tiles" aria-hidden="true">
          <span v-for="(e, i) in PREVIEW" :key="i">{{ e }}</span>
        </div>
        <h2>拼出完整的比奇堡</h2>
        <p>3 × 3 滑块拼图 · 9 格挑战</p>
        <button class="cta" @click="start">开始拼图</button>
        <GameLeaderboard :board="board" :loading="loading" title="拼图" />
      </section>

      <section v-else class="play-panel">
        <div class="hud">
          <div class="hs"><span>步数</span><b>{{ moves }}</b></div>
          <div class="hs"><span>用时</span><b>{{ elapsed }}s</b></div>
          <div class="hs"><span>已归位</span><b>{{ correctCount }}/8</b></div>
          <button class="quit" @click="start">重开</button>
        </div>

        <div class="puzzle">
          <button
            v-for="(tile, i) in tiles"
            :key="i"
            type="button"
            class="tile"
            :class="{ blank: tile === 8, placed: tile !== 8 && tile === correctAt(i) }"
            :disabled="!canMove(i)"
            @click="move(i)"
          >
            <span v-if="tile !== 8">{{ TILES[tile] }}</span>
          </button>
        </div>
        <p class="tip">点击空格旁边的图片，把它滑到空位上</p>
      </section>

      <div v-if="phase === 'done'" class="overlay" @click.self="phase = 'idle'">
        <div class="result-card">
          <div class="r-emoji">{{ isNewRecord ? '🏆' : '🎉' }}</div>
          <h2>{{ isNewRecord ? '新纪录！' : '拼好啦！' }}</h2>
          <div class="r-score">{{ finalScore }} <small>分</small></div>
          <p>步数 {{ finalMoves }} · 用时 {{ finalTime }}s</p>
          <p v-if="saved" class="r-saved">成绩已记录 ✓</p>
          <div class="r-btns">
            <button class="cta small" @click="start">再来一局</button>
            <button class="ghost" @click="phase = 'idle'">看排行榜</button>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { computed, onUnmounted, ref } from 'vue'
import OceanBackdrop from './OceanBackdrop.vue'
import PageNav from './PageNav.vue'
import GameLeaderboard from './GameLeaderboard.vue'
import { getNickname } from '../utils/auth.js'
import { useGameBoard } from '../utils/useGameBoard.js'
import { sfx } from '../utils/sound.js'

defineEmits(['logout'])
const displayName = computed(() => getNickname() || '海绵宝宝')
const { board, loading, commit } = useGameBoard('puzzle')

const TILES = ['🧽', '⭐', '🐙', '🦀', '🐿️', '🍍', '🪼', '🐟']
const PREVIEW = ['🧽', '⭐', '🐙', '🦀', '🐿️', '🍍', '🪼', '🐟']

const phase = ref('idle')
const tiles = ref([])
const moves = ref(0)
const elapsed = ref(0)
const finalScore = ref(0)
const finalMoves = ref(0)
const finalTime = ref(0)
const isNewRecord = ref(false)
const saved = ref(false)
let timer = null

const correctCount = computed(() => tiles.value.filter((t, i) => t !== 8 && t === i).length)
function correctAt(i) { return i }

function solved(arr) {
  return arr.every((t, i) => t === i)
}

function shuffleSolvable() {
  // 从已完成状态随机走步，保证一定有解
  const arr = [0, 1, 2, 3, 4, 5, 6, 7, 8]
  let blank = 8
  for (let step = 0; step < 200; step++) {
    const neighbors = []
    const r = Math.floor(blank / 3), c = blank % 3
    if (r > 0) neighbors.push(blank - 3)
    if (r < 2) neighbors.push(blank + 3)
    if (c > 0) neighbors.push(blank - 1)
    if (c < 2) neighbors.push(blank + 1)
    const pick = neighbors[Math.floor(Math.random() * neighbors.length)]
    arr[blank] = arr[pick]
    arr[pick] = 8
    blank = pick
  }
  return solved(arr) ? shuffleSolvable() : arr
}

function canMove(i) {
  if (phase.value !== 'playing') return false
  const blank = tiles.value.indexOf(8)
  if (blank < 0) return false
  const r1 = Math.floor(i / 3), c1 = i % 3
  const r2 = Math.floor(blank / 3), c2 = blank % 3
  return Math.abs(r1 - r2) + Math.abs(c1 - c2) === 1
}

function move(i) {
  if (!canMove(i)) return
  const blank = tiles.value.indexOf(8)
  const arr = tiles.value.slice()
  arr[blank] = arr[i]
  arr[i] = 8
  tiles.value = arr
  moves.value++
  sfx.click()
  elapsed.value = Math.floor((Date.now() - startTime) / 1000)
  if (solved(arr)) finish()
}

let startTime = 0
function start() {
  clearInterval(timer)
  tiles.value = shuffleSolvable()
  moves.value = 0
  elapsed.value = 0
  saved.value = false
  phase.value = 'playing'
  startTime = Date.now()
  timer = setInterval(() => {
    elapsed.value = Math.floor((Date.now() - startTime) / 1000)
  }, 1000)
}

async function finish() {
  clearInterval(timer)
  finalMoves.value = moves.value
  finalTime.value = elapsed.value
  finalScore.value = Math.max(30, 1200 - moves.value * 12 - elapsed.value * 3)
  isNewRecord.value = finalScore.value > (board.value.bestScore || 0)
  phase.value = 'done'
  sfx.win()
  try {
    await commit({ score: finalScore.value, combo: 0, count: moves.value })
    saved.value = true
  } catch (e) { /* 成绩提交失败不影响结算展示 */ }
}

onUnmounted(() => clearInterval(timer))
</script>

<style scoped>
.mini-game { min-height: 100vh; position: relative; }
.main { position: relative; z-index: 2; max-width: 720px; margin: 0 auto; padding: 32px 20px 80px; }
.back { display: inline-block; color: #b9e6ff; text-decoration: none; font-size: 14px; margin-bottom: 16px; }
.back:hover { color: #ffe082; }
.head { display: flex; align-items: center; gap: 16px; margin-bottom: 24px; }
.g-icon { font-size: 48px; filter: drop-shadow(0 4px 6px rgba(0,0,0,.3)); }
.head h1 { font-size: 28px; color: #ffe082; letter-spacing: 2px; text-shadow: 0 3px 0 #c17900; margin-bottom: 4px; }
.head p { color: #d9f2ff; font-size: 14px; line-height: 1.5; }

.start-panel { text-align: center; background: rgba(3,46,76,.55); border: 2px solid rgba(126,226,255,.35); border-radius: 24px; padding: 32px 24px; backdrop-filter: blur(6px); }
.preview-tiles { display: flex; justify-content: center; flex-wrap: wrap; gap: 8px; margin-bottom: 18px; }
.preview-tiles span { width: 46px; height: 46px; display: grid; place-items: center; font-size: 24px; background: linear-gradient(150deg,#ffe082,#ffb300); border: 2px solid #fff; border-radius: 12px; box-shadow: 0 3px 0 #c17900; }
.start-panel h2 { color: #fff8e1; font-size: 22px; margin-bottom: 8px; }
.start-panel > p { color: #b9e6ff; font-size: 14px; margin-bottom: 20px; }

.cta { border: none; background: linear-gradient(180deg,#ffd54f,#ffb300); color: #5d3700; font-family: inherit; font-size: 16px; font-weight: bold; padding: 12px 34px; border-radius: 999px; cursor: pointer; box-shadow: 0 4px 0 #c17900, 0 0 22px rgba(255,193,7,.5); transition: transform .18s, filter .18s; }
.cta:hover { transform: translateY(-2px); filter: brightness(1.06); }
.cta:active { transform: translateY(2px); box-shadow: 0 1px 0 #c17900; }
.cta.small { font-size: 14px; padding: 9px 22px; }
.ghost { border: 2px solid rgba(126,226,255,.5); background: transparent; color: #b9e6ff; font-family: inherit; font-size: 14px; padding: 8px 20px; border-radius: 999px; cursor: pointer; }
.ghost:hover { background: rgba(126,226,255,.18); color: #fff; }

.play-panel { background: rgba(3,46,76,.5); border: 2px solid rgba(126,226,255,.3); border-radius: 24px; padding: 20px; backdrop-filter: blur(6px); }
.hud { display: flex; gap: 10px; align-items: center; margin-bottom: 18px; flex-wrap: wrap; }
.hs { flex: 1; min-width: 70px; background: rgba(126,226,255,.12); border: 1px solid rgba(126,226,255,.3); border-radius: 12px; padding: 8px 10px; text-align: center; }
.hs span { display: block; font-size: 11px; color: #8fdcff; }
.hs b { font-size: 20px; color: #ffe082; }
.quit { border: 2px solid rgba(255,193,7,.5); background: rgba(255,193,7,.12); color: #ffe082; font-family: inherit; font-size: 13px; font-weight: bold; padding: 8px 16px; border-radius: 999px; cursor: pointer; }
.quit:hover { background: rgba(255,193,7,.25); }

.puzzle { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; max-width: 360px; margin: 0 auto; }
.tile { aspect-ratio: 1; border: 2px solid #fff; border-radius: 14px; background: linear-gradient(150deg,#eaf8ff,#bfe6f7); font-size: 44px; cursor: pointer; box-shadow: 0 4px 0 rgba(4,74,110,.5); transition: transform .15s, box-shadow .15s; display: grid; place-items: center; }
.tile:hover:not(:disabled) { transform: translateY(-2px); }
.tile:disabled { cursor: default; opacity: .75; }
.tile.blank { background: rgba(3,30,50,.5); border-style: dashed; box-shadow: none; }
.tile.placed { box-shadow: 0 4px 0 rgba(4,74,110,.5), 0 0 16px rgba(255,213,79,.7); }
.tip { text-align: center; color: #b9e6ff; font-size: 13px; margin-top: 16px; }

.overlay { position: absolute; inset: 0; z-index: 20; display: grid; place-items: center; padding: 20px; background: rgba(2,20,36,.6); backdrop-filter: blur(4px); border-radius: 24px; }
.result-card { width: min(360px,100%); text-align: center; background: linear-gradient(160deg,#fffdf5,#eaf8ff); border: 3px solid #ffd54f; border-radius: 24px; padding: 28px; box-shadow: 0 10px 0 rgba(193,121,0,.4), 0 24px 50px rgba(0,0,0,.5); }
.r-emoji { font-size: 46px; }
.result-card h2 { color: #0a5c86; font-size: 22px; margin: 6px 0; }
.r-score { font-size: 44px; font-weight: bold; color: #f57f17; }
.r-score small { font-size: 16px; }
.result-card p { color: #4a6b7d; font-size: 14px; margin: 4px 0; }
.r-saved { color: #2e7d32 !important; }
.r-btns { display: flex; gap: 10px; justify-content: center; margin-top: 18px; }

@media (max-width: 520px) {
  .r-btns { flex-direction: column; }
  .tile { font-size: 34px; }
}
</style>
