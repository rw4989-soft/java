<template>
  <div class="mini-game">
    <OceanBackdrop />
    <PageNav active="game" :nickname="displayName" @logout="$emit('logout')" />

    <main class="main">
      <router-link to="/games" class="back">‹ 游戏中心</router-link>

      <section class="head">
        <span class="g-icon">🧠</span>
        <div>
          <h1>比奇堡知识问答</h1>
          <p>关于海绵宝宝的一切，你到底懂多少？10 道题，答得越快分越高！</p>
        </div>
      </section>

      <!-- 开始 -->
      <section v-if="phase === 'idle'" class="start-panel">
        <div class="wiki" aria-hidden="true">
          <span>📖</span><span>❓</span><span>🧠</span>
        </div>
        <h2>比奇堡常识大考验</h2>
        <p>10 道题 · 答对得分 · 连对有加成</p>
        <button class="cta" @click="start">开始答题</button>
        <GameLeaderboard :board="board" :loading="loading" title="知识问答" />
      </section>

      <!-- 答题 -->
      <section v-else-if="phase === 'playing'" class="quiz-panel">
        <div class="progress">
          <div class="bar"><i :style="{ width: ((qIndex) / QUESTIONS.length) * 100 + '%' }"></i></div>
          <span>第 {{ qIndex + 1 }} / {{ QUESTIONS.length }} 题</span>
        </div>
        <div class="hud">
          <div class="hs"><span>得分</span><b>{{ score }}</b></div>
          <div class="hs"><span>连对</span><b :class="{ lit: streak >= 2 }">×{{ streak }}</b></div>
          <div class="hs"><span>题目</span><b>{{ qIndex }}/{{ QUESTIONS.length }}</b></div>
        </div>

        <div class="question" :class="{ correct: answered && lastCorrect, wrong: answered && !lastCorrect }">
          <span class="q-emoji">{{ q.emoji }}</span>
          <h2>{{ q.q }}</h2>
        </div>

        <div class="options">
          <button
            v-for="(opt, i) in q.options"
            :key="i"
            type="button"
            class="opt"
            :class="optClass(i)"
            @click="answer(i)"
            :disabled="answered"
          >
            <span class="opt-key">{{ 'ABCD'[i] }}</span>
            <span>{{ opt }}</span>
          </button>
        </div>

        <p v-if="answered" class="feedback">{{ feedback }}</p>
        <button v-if="answered" class="next" @click="nextQuestion">
          {{ qIndex >= QUESTIONS.length - 1 ? '查看结果' : '下一题 ›' }}
        </button>
      </section>

      <!-- 结算 -->
      <div v-if="phase === 'done'" class="overlay" @click.self="closeResult">
        <div class="result-card">
          <div class="r-emoji">{{ correctCount >= 8 ? '🏆' : correctCount >= 5 ? '🎉' : '🧽' }}</div>
          <h2>{{ correctCount >= 8 ? '比奇堡博士！' : correctCount >= 5 ? '不错嘛！' : '再多逛逛吧' }}</h2>
          <div class="r-score">{{ finalScore }} <small>分</small></div>
          <p>答对 {{ correctCount }}/{{ QUESTIONS.length }} 题</p>
          <p v-if="saved" class="r-saved">成绩已记录 ✓</p>
          <div class="r-btns">
            <button class="cta small" @click="start">再来一次</button>
            <button class="ghost" @click="closeResult">看排行榜</button>
          </div>
        </div>
      </div>
    </main>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import OceanBackdrop from './OceanBackdrop.vue'
import PageNav from './PageNav.vue'
import GameLeaderboard from './GameLeaderboard.vue'
import { getNickname } from '../utils/auth.js'
import { useGameBoard } from '../utils/useGameBoard.js'

defineEmits(['logout'])
const displayName = computed(() => getNickname() || '海绵宝宝')
const { board, loading, lastResult, commit } = useGameBoard('quiz')

const QUESTIONS = [
  { emoji: '🍔', q: '蟹堡王最出名的招牌美食是什么？', options: ['蟹黄堡', '炸鱼排', '海藻沙拉', '珊瑚卷'], answer: 0 },
  { emoji: '🦀', q: '蟹堡王的老板是谁？', options: ['章鱼哥', '蟹老板', '派大星', '珊迪'], answer: 1 },
  { emoji: '🧽', q: '海绵宝宝住在哪里？', options: ['菠萝屋', '石头屋', '沉船', '水母洞'], answer: 0 },
  { emoji: '⭐', q: '派大星 Best Friend 是谁？', options: ['章鱼哥', '海绵宝宝', '蟹老板', '小蜗'], answer: 1 },
  { emoji: '🐙', q: '章鱼哥最喜欢的乐器是什么？', options: ['钢琴', '竖笛', '吉他', '小号'], answer: 1 },
  { emoji: '🐿️', q: '珊迪来自哪里？', options: ['比奇堡', '德克萨斯州', '海底城', '石头滩'], answer: 1 },
  { emoji: '🐌', q: '海绵宝宝的宠物叫什么名字？', options: ['小蜗', '加里', '点点', '泡泡'], answer: 0 },
  { emoji: '🥪', q: '蟹黄堡的秘方藏在谁那里？', options: ['蟹老板', '海绵宝宝', '派大星', '章鱼哥'], answer: 0 },
  { emoji: '🪼', q: '海绵宝宝和派大星喜欢去哪里抓水母？', options: ['水母田', '珊瑚林', '沉船谷', '沙丘'], answer: 0 },
  { emoji: '🌊', q: '比奇堡所在的大洋中，海绵宝宝的邻居章鱼哥住在？', options: ['复活节岛人像屋', '菠萝屋', '蘑菇屋', '灯塔'], answer: 0 }
]

const phase = ref('idle')
const qIndex = ref(0)
const score = ref(0)
const streak = ref(0)
const correctCount = ref(0)
const answered = ref(false)
const lastCorrect = ref(false)
const selected = ref(-1)
const feedback = ref('')

const q = computed(() => QUESTIONS[qIndex.value] || QUESTIONS[0])

const finalScore = ref(0)
const newRecord = ref(false)
const saved = ref(false)

function start() {
  // 打乱题目顺序
  QUESTIONS.sort(() => Math.random() - 0.5)
  qIndex.value = 0
  score.value = 0
  streak.value = 0
  correctCount.value = 0
  answered.value = false
  selected.value = -1
  feedback.value = ''
  saved.value = false
  newRecord.value = false
  phase.value = 'playing'
}

function optClass(i) {
  if (!answered.value) return ''
  if (i === q.value.answer) return 'right'
  if (i === selected.value) return 'wrong'
  return ''
}

function answer(i) {
  if (answered.value) return
  answered.value = true
  selected.value = i
  const ok = i === q.value.answer
  lastCorrect.value = ok
  if (ok) {
    correctCount.value++
    streak.value++
    const gain = 100 + Math.min(streak.value - 1, 5) * 20
    score.value += gain
    feedback.value = `答对了！+${gain} 分 🎉`
  } else {
    streak.value = 0
    const right = q.value.options[q.value.answer]
    feedback.value = `答错了，正确答案是「${right}」`
  }
}

async function nextQuestion() {
  if (qIndex.value >= QUESTIONS.length - 1) {
    return finish()
  }
  qIndex.value++
  answered.value = false
  selected.value = -1
  feedback.value = ''
}

async function finish() {
  finalScore.value = score.value
  phase.value = 'done'
  const r = await commit({ score: score.value, combo: streak.value, count: correctCount.value })
  saved.value = r.ok
  newRecord.value = Boolean(lastResult.value?.newRecord)
}

function closeResult() { phase.value = 'idle' }

onMounted(() => { document.title = '比奇堡知识问答 · 海绵宝宝' })
</script>

<style scoped>
.mini-game { min-height: 100vh; position: relative; }
.main { position: relative; z-index: 2; max-width: 820px; margin: 0 auto; padding: 24px 20px 80px; }
.back { display: inline-block; color: #b9e6ff; text-decoration: none; font-size: 14px; margin-bottom: 16px; }
.back:hover { color: #ffe082; }
.head { display: flex; align-items: center; gap: 16px; margin-bottom: 24px; }
.g-icon { font-size: 50px; filter: drop-shadow(0 4px 6px rgba(1,26,44,.5)); }
.head h1 { font-size: 30px; color: #ffe082; letter-spacing: 2px; text-shadow: 0 2px 0 #c17900, 0 0 20px rgba(255,213,79,.4); }
.head p { color: #eaf7ff; font-size: 14px; margin-top: 4px; }

.start-panel { text-align: center; background: rgba(3,46,76,.55); border: 2px solid rgba(126,226,255,.35); border-radius: 28px; padding: 30px 24px; backdrop-filter: blur(8px); }
.wiki { display: flex; justify-content: center; gap: 16px; margin-bottom: 12px; }
.wiki span { font-size: 40px; animation: bob 2s ease-in-out infinite; }
.wiki span:nth-child(2) { animation-delay: .3s; } .wiki span:nth-child(3) { animation-delay: .6s; }
@keyframes bob { 0%,100% { transform: translateY(0) } 50% { transform: translateY(-12px) } }
.start-panel h2 { color: #fff8e1; font-size: 24px; }
.start-panel > p { color: #b9e6ff; margin: 8px 0 20px; }
.cta { border: none; border-radius: 999px; padding: 13px 40px; font-family: inherit; font-size: 17px; font-weight: bold; color: #5d3700; background: linear-gradient(180deg,#ffd54f,#ffb300); box-shadow: 0 4px 0 #c17900, 0 8px 20px rgba(1,26,44,.4); cursor: pointer; transition: transform .2s, box-shadow .2s; }
.cta:hover { transform: translateY(-2px); box-shadow: 0 6px 0 #c17900, 0 0 24px rgba(255,213,79,.7); }
.cta.small { padding: 10px 26px; font-size: 15px; }

.quiz-panel { background: rgba(3,46,76,.55); border: 2px solid rgba(126,226,255,.35); border-radius: 28px; padding: 24px; backdrop-filter: blur(8px); }
.progress { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; }
.progress .bar { flex: 1; height: 10px; border-radius: 999px; background: rgba(255,255,255,.18); overflow: hidden; }
.progress .bar i { display: block; height: 100%; background: linear-gradient(90deg,#7ee2ff,#ffd54f); border-radius: 999px; transition: width .3s; }
.progress span { color: #b9e6ff; font-size: 13px; white-space: nowrap; }
.hud { display: flex; gap: 12px; margin-bottom: 18px; }
.hs { flex: 1; text-align: center; background: rgba(255,255,255,.12); border-radius: 14px; padding: 8px; }
.hs span { display: block; font-size: 11px; color: #b9e6ff; }
.hs b { display: block; font-size: 20px; color: #ffe082; }
.hs b.lit { color: #ff7043; text-shadow: 0 0 10px #ff7043; }

.question { display: flex; align-items: center; gap: 16px; background: linear-gradient(150deg, rgba(255,255,255,.96), rgba(232,246,255,.92)); border: 3px solid #fff; border-radius: 20px; padding: 18px 22px; margin-bottom: 18px; }
.question.correct { border-color: #81c784; box-shadow: 0 0 20px rgba(129,199,132,.6); }
.question.wrong { border-color: #ef9a9a; box-shadow: 0 0 20px rgba(239,154,154,.6); }
.q-emoji { font-size: 42px; flex-shrink: 0; }
.question h2 { font-size: 20px; color: #06476e; line-height: 1.4; }

.options { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.opt { display: flex; align-items: center; gap: 12px; text-align: left; border: 2px solid rgba(126,226,255,.5); background: rgba(255,255,255,.94); border-radius: 16px; padding: 14px 16px; font-family: inherit; font-size: 15px; color: #0a4a70; cursor: pointer; transition: transform .18s, box-shadow .2s, border-color .2s; font-weight: bold; }
.opt:hover:not(:disabled) { transform: translateY(-2px); border-color: #ffb300; box-shadow: 0 0 16px rgba(255,213,79,.5); }
.opt:disabled { cursor: default; }
.opt-key { width: 28px; height: 28px; flex-shrink: 0; display: grid; place-items: center; border-radius: 8px; background: #e3f2fd; color: #0a5c86; font-size: 13px; }
.opt.right { border-color: #66bb6a; background: #e8f5e9; box-shadow: 0 0 16px rgba(102,187,106,.6); }
.opt.right .opt-key { background: #66bb6a; color: #fff; }
.opt.wrong { border-color: #e57373; background: #ffebee; }
.opt.wrong .opt-key { background: #e57373; color: #fff; }
.feedback { text-align: center; color: #fff8e1; font-size: 15px; font-weight: bold; margin-top: 16px; }
.next { display: block; margin: 16px auto 0; border: none; border-radius: 999px; padding: 11px 32px; font-family: inherit; font-size: 15px; font-weight: bold; color: #fff; background: linear-gradient(180deg,#42a5f5,#1565c0); box-shadow: 0 4px 0 #0d47a1; cursor: pointer; }
.next:hover { transform: translateY(-2px); }

.overlay { position: fixed; inset: 0; z-index: 100; display: grid; place-items: center; background: rgba(1,20,35,.65); backdrop-filter: blur(4px); padding: 20px; }
.result-card { width: min(380px, 100%); text-align: center; background: linear-gradient(160deg,#fffdf3,#fff3cf); border: 4px solid #ffe082; border-radius: 28px; padding: 30px 24px; box-shadow: 0 20px 50px rgba(0,0,0,.5); }
.r-emoji { font-size: 60px; }
.result-card h2 { color: #e65100; font-size: 26px; margin: 6px 0; }
.r-score { font-size: 52px; font-weight: bold; color: #f57f17; text-shadow: 0 2px 0 #ffd54f; }
.r-score small { font-size: 18px; }
.result-card p { color: #6d4c00; margin: 6px 0; }
.r-saved { color: #2e7d32 !important; font-weight: bold; }
.r-btns { display: flex; gap: 12px; justify-content: center; margin-top: 18px; }
.ghost { border: 2px solid #ffb300; background: #fff; color: #e65100; border-radius: 999px; padding: 9px 22px; font-family: inherit; font-weight: bold; cursor: pointer; }
.ghost:hover { background: #fff8e1; }

@media (max-width: 560px) {
  .options { grid-template-columns: 1fr; }
}
</style>
