<template>
  <div class="wishes-page">
    <OceanBackdrop />
    <PageNav active="profile" :nickname="displayName" @logout="$emit('logout')" />

    <main class="main">
      <section class="hero">
        <span class="hero-kicker">💭 海底许愿池</span>
        <h1 class="title">留言许愿池</h1>
        <p class="sub">把心愿装进泡泡，让它漂向比奇堡的每一个角落。</p>
      </section>

      <!-- 发布框 -->
      <section class="compose">
        <div class="compose-avatar">🫧</div>
        <div class="compose-body">
          <textarea v-model="draft" maxlength="120" rows="3" placeholder="写下你的心愿或留言……（最多 120 字）"></textarea>
          <div class="compose-foot">
            <span class="count">{{ draft.length }}/120</span>
            <button class="send" :disabled="!draft.trim()" @click="send">🎈 放飞心愿</button>
          </div>
        </div>
      </section>

      <!-- 留言墙 -->
      <section class="wall-head">
        <h3>🫧 心愿泡泡墙 <small>共 {{ wishes.length }} 条</small></h3>
      </section>
      <section class="wall">
        <article v-for="w in wishes" :key="w.id" class="wish" :style="{ '--delay': (w.id.length % 5) * 0.3 + 's' }">
          <div class="wish-bubble">
            <span class="wb-tail"></span>
            <p>{{ w.text }}</p>
          </div>
          <div class="wish-meta">
            <span class="w-avatar">{{ w.avatar }}</span>
            <span class="w-name">{{ w.nickname }}</span>
            <span class="w-time">{{ timeAgo(w.time) }}</span>
            <button v-if="w.nickname === displayName" class="w-del" @click="del(w.id)" title="删除">🗑</button>
          </div>
        </article>
      </section>

      <p v-if="!wishes.length" class="empty">还没有心愿，来做第一个放飞泡泡的人吧～</p>
      <div v-if="toast" class="toast">{{ toast }}</div>
    </main>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import OceanBackdrop from './OceanBackdrop.vue'
import PageNav from './PageNav.vue'
import { getNickname } from '../utils/auth.js'
import { getWishes, addWish, removeWish, timeAgo } from '../utils/wishes.js'
import { sfx } from '../utils/sound.js'

defineEmits(['logout'])
const displayName = computed(() => getNickname() || '海绵宝宝')

const draft = ref('')
const wishes = ref([])
const toast = ref('')

function load() { wishes.value = getWishes() }
function send() {
  const w = addWish({ nickname: displayName.value, text: draft.value })
  if (!w) return
  draft.value = ''
  load()
  sfx.coin()
  flash('心愿已放飞！🎈')
}
function del(id) {
  removeWish(id)
  load()
  sfx.click()
}
function flash(msg) { toast.value = msg; setTimeout(() => { toast.value = '' }, 1800) }

onMounted(() => {
  document.title = '许愿池 · 海绵宝宝'
  load()
})
</script>

<style scoped>
.wishes-page { min-height: 100vh; position: relative; }
.main { position: relative; z-index: 2; max-width: 860px; margin: 0 auto; padding: 40px 20px 80px; }
.hero { text-align: center; margin-bottom: 26px; }
.hero-kicker { display: inline-block; font-size: 13px; letter-spacing: 2px; color: #b9e6ff; background: rgba(3,46,76,.6); border: 1px solid rgba(126,226,255,.4); padding: 6px 16px; border-radius: 999px; margin-bottom: 12px; }
.title { font-size: clamp(32px,6vw,50px); color: #ffe082; letter-spacing: 5px; text-shadow: 0 3px 0 #c17900, 0 0 30px rgba(255,213,79,.5); margin-bottom: 8px; }
.sub { color: #eaf7ff; font-size: 15px; }

.compose { display: flex; gap: 14px; background: rgba(255,255,255,.95); border: 3px solid #81c784; border-radius: 22px; padding: 18px 20px; box-shadow: 0 6px 0 rgba(46,125,50,.4), 0 18px 36px rgba(1,26,44,.3); margin-bottom: 30px; }
.compose-avatar { width: 46px; height: 46px; flex-shrink: 0; display: grid; place-items: center; font-size: 26px; background: linear-gradient(150deg,#b9e6ff,#7ec8e3); border-radius: 50%; }
.compose-body { flex: 1; }
.compose textarea { width: 100%; box-sizing: border-box; border: none; outline: none; resize: vertical; font-family: inherit; font-size: 15px; color: #2c4a3a; background: transparent; line-height: 1.5; min-height: 64px; }
.compose textarea::placeholder { color: #9ab5a5; }
.compose-foot { display: flex; align-items: center; justify-content: space-between; margin-top: 6px; }
.count { font-size: 12px; color: #90a89a; }
.send { border: none; background: linear-gradient(180deg,#81c784,#4caf50); color: #fff; font-family: inherit; font-size: 14px; font-weight: bold; padding: 9px 22px; border-radius: 999px; cursor: pointer; box-shadow: 0 3px 0 #2e7d32; transition: transform .18s; }
.send:hover:not(:disabled) { transform: translateY(-2px); }
.send:disabled { opacity: .5; cursor: default; }

.wall-head h3 { color: #ffe082; font-size: 18px; margin-bottom: 18px; }
.wall-head small { color: #8fdcff; font-size: 13px; font-weight: normal; }
.wall { display: grid; grid-template-columns: repeat(2, 1fr); gap: 18px; }
.wish { animation: floatIn .5s ease-out backwards; animation-delay: var(--delay); }
@keyframes floatIn { from { transform: translateY(20px); opacity: 0; } }
.wish-bubble { position: relative; background: rgba(255,255,255,.95); border: 2px solid rgba(255,255,255,.8); border-radius: 22px 22px 22px 6px; padding: 16px 18px; box-shadow: 0 4px 0 rgba(4,74,110,.3), 0 10px 22px rgba(1,26,44,.25); }
.wish-bubble::before { content: ''; position: absolute; left: 16px; top: 12px; width: 40%; height: 8px; border-radius: 999px; background: rgba(255,255,255,.9); }
.wb-tail { position: absolute; left: -2px; bottom: -12px; width: 18px; height: 18px; background: rgba(255,255,255,.95); clip-path: polygon(0 0, 100% 0, 0 100%); }
.wish-bubble p { color: #2c4a3a; font-size: 14px; line-height: 1.6; word-break: break-word; padding-top: 8px; }
.wish-meta { display: flex; align-items: center; gap: 8px; margin: 10px 0 0 6px; }
.w-avatar { font-size: 18px; }
.w-name { color: #eaf7ff; font-size: 13px; font-weight: bold; }
.w-time { color: #8fdcff; font-size: 12px; }
.w-del { margin-left: auto; border: none; background: transparent; cursor: pointer; font-size: 14px; opacity: .7; }
.w-del:hover { opacity: 1; }
.empty { text-align: center; color: #b9e6ff; font-size: 14px; padding: 40px; }
.toast { position: fixed; bottom: 40px; left: 50%; transform: translateX(-50%); z-index: 90; background: rgba(255,253,235,.98); border: 3px solid #81c784; color: #2e7d32; font-weight: bold; font-size: 14px; padding: 12px 24px; border-radius: 999px; box-shadow: 0 8px 24px rgba(0,0,0,.4); }

@media (max-width: 640px) { .wall { grid-template-columns: 1fr; } }
</style>
