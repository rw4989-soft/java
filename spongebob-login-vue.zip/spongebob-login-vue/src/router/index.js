import { createRouter, createWebHashHistory } from 'vue-router'
import LoginView from '../views/LoginView.vue'
import HomePage from '../components/HomePage.vue'
import WorkPage from '../components/WorkPage.vue'
import GamePage from '../components/GamePage.vue'
import GamesHub from '../components/GamesHub.vue'
import ArcadeRouter from '../components/ArcadeRouter.vue'
import AboutPage from '../components/AboutPage.vue'
import CharactersPage from '../components/CharactersPage.vue'
import CollectionPage from '../components/CollectionPage.vue'
import ProfilePage from '../components/ProfilePage.vue'
import AchievementsPage from '../components/AchievementsPage.vue'
import CheckinPage from '../components/CheckinPage.vue'
import JellyfishPage from '../components/JellyfishPage.vue'
import WishesPage from '../components/WishesPage.vue'
import AdminLoginView from '../views/AdminLoginView.vue'
import AdminDashboard from '../views/AdminDashboard.vue'
import { getToken, getNickname, isAdminLoggedIn, isAdminUser } from '../utils/auth.js'

const routes = [
  {
    path: '/',
    redirect: '/home'
  },
  {
    path: '/login',
    name: 'login',
    component: LoginView,
    // 已登录的用户不该再看到登录页
    meta: { guestOnly: true, title: '比奇堡登录' }
  },
  {
    path: '/home',
    name: 'home',
    component: HomePage,
    // 没 token 进不来
    meta: { requiresAuth: true, title: '比奇堡首页' },
    // 首页需要的昵称直接从本地存储取
    props: () => ({ nickname: getNickname() || '海绵宝宝' })
  },
  {
    path: '/work',
    name: 'work',
    component: WorkPage,
    meta: { requiresAuth: true, title: '打工日常' },
    props: () => ({ nickname: getNickname() || '海绵宝宝' })
  },
  {
    path: '/game',
    name: 'game',
    component: GamePage,
    meta: { requiresAuth: true, title: '出餐大作战' },
    props: () => ({ nickname: getNickname() || '海绵宝宝' })
  },
  {
    // 游戏中心：所有小游戏的入口列表
    path: '/games',
    name: 'games',
    component: GamesHub,
    meta: { requiresAuth: true, title: '海底游乐场' }
  },
  {
    // 小游戏容器：按 ?game=memory|catch|quiz 渲染对应玩法
    path: '/arcade',
    name: 'arcade',
    component: ArcadeRouter,
    meta: { requiresAuth: true, title: '小游戏' }
  },
  {
    // 关于本站：站点介绍、功能导览、技术栈与玩法指南
    path: '/about',
    name: 'about',
    component: AboutPage,
    meta: { requiresAuth: true, title: '关于比奇堡' }
  },
  {
    // 角色互动：和比奇堡居民聊天，互动即解锁图鉴
    path: '/characters',
    name: 'characters',
    component: CharactersPage,
    meta: { requiresAuth: true, title: '角色互动' }
  },
  {
    // 图鉴收集：查看已解锁的居民图鉴与收集进度
    path: '/collection',
    name: 'collection',
    component: CollectionPage,
    meta: { requiresAuth: true, title: '图鉴收集' }
  },
  {
    // 玩家名片：聚合成绩、图鉴、默契、签到等成长数据（我的海底家园枢纽）
    path: '/profile',
    name: 'profile',
    component: ProfilePage,
    meta: { requiresAuth: true, title: '玩家名片' }
  },
  {
    path: '/achievements',
    name: 'achievements',
    component: AchievementsPage,
    meta: { requiresAuth: true, title: '成就徽章' }
  },
  {
    path: '/checkin',
    name: 'checkin',
    component: CheckinPage,
    meta: { requiresAuth: true, title: '每日签到' }
  },
  {
    path: '/jellyfish',
    name: 'jellyfish',
    component: JellyfishPage,
    meta: { requiresAuth: true, title: '水母养成' }
  },
  {
    path: '/wishes',
    name: 'wishes',
    component: WishesPage,
    meta: { requiresAuth: true, title: '许愿池' }
  },
  {
    // 后台管理登录页：只有登录功能，没有注册
    path: '/admin/login',
    name: 'adminLogin',
    component: AdminLoginView,
    meta: { adminGuestOnly: true, title: '管理后台登录' }
  },
  {
    // 后台管理系统：对首页展示的分类 / 地点做数据管理
    path: '/admin',
    name: 'admin',
    component: AdminDashboard,
    meta: { requiresAdmin: true, title: '比奇堡管理后台' }
  },
  {
    // 兜底：乱敲地址一律回首页，再由守卫决定要不要踢去登录
    path: '/:pathMatch(.*)*',
    redirect: '/home'
  }
]

const router = createRouter({
  // 用 hash 模式：Spring Boot 里不需要额外的 history fallback 配置，
  // 直接访问 /#/home 也能打开
  history: createWebHashHistory(),
  routes,
  scrollBehavior: () => ({ top: 0 })
})

/**
 * 全局前置守卫
 * 1. 目标页要登录、但本地没 token → 拦截，跳登录页，并记住原本想去哪
 * 2. 已登录还想去登录页 → 直接送去首页
 * 3. 前台已登录的普通用户（permission=1）不能进后台登录页；未登录或管理员可进
 * 4. 后台主页必须持有后台 token；能否登录由后端按 permission=0 严格校验
 * 5. 已是管理员还想去管理登录页 → 直接进后台
 */
router.beforeEach((to) => {
  const hasToken = Boolean(getToken())
  const hasAdminToken = isAdminLoggedIn()
  // 前台已登录但权限不是 0 → 普通用户；未登录时允许打开后台登录页
  const isNormalUser = hasToken && !isAdminUser()

  if (to.meta.requiresAuth && !hasToken) {
    return {
      name: 'login',
      query: to.fullPath && to.fullPath !== '/home' ? { redirect: to.fullPath } : {}
    }
  }

  if (to.meta.guestOnly && hasToken) {
    return { name: 'home' }
  }

  // 普通用户看不到、也进不了后台登录页
  if (to.meta.adminGuestOnly && isNormalUser) {
    return { name: 'home' }
  }

  // 后台主页：必须持有后台登录 token
  if (to.meta.requiresAdmin && !hasAdminToken) {
    return {
      name: 'adminLogin',
      query: to.fullPath && to.fullPath !== '/admin' ? { redirect: to.fullPath } : {}
    }
  }

  if (to.meta.adminGuestOnly && hasAdminToken) {
    return { name: 'admin' }
  }

  return true
})

router.afterEach((to) => {
  document.title = to.meta.title ? `${to.meta.title} · 海绵宝宝` : '比奇堡'
})

export default router
