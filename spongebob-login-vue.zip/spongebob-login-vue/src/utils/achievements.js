/**
 * 成就徽章系统：判定逻辑基于玩家名片聚合数据，解锁状态存 localStorage。
 * 每个成就 { code, name, emoji, desc, goal, value(summary)->number }
 * 当 value >= goal 即达成。
 */
import { getProfileSummary } from './statsCenter.js'

const KEY = 'sb_achievements'

export const ACHIEVEMENTS = [
  { code: 'first_step', name: '初来乍到', emoji: '🐚', desc: '玩过第一款小游戏', goal: 1, value: s => s.gameCount, hint: '去游戏中心玩一局' },
  { code: 'game_lover', name: '游戏达人', emoji: '🎮', desc: '累计游玩 10 局小游戏', goal: 10, value: s => s.gamePlays, hint: '多玩几局吧' },
  { code: 'score_500', name: '小有身手', emoji: '🏅', desc: '单项最高分累计达 500', goal: 500, value: s => s.gameBestTotal, hint: '提升你的最高分' },
  { code: 'score_2000', name: '蟹堡王之星', emoji: '🌟', desc: '各项最高分累计达 2000', goal: 2000, value: s => s.gameBestTotal, hint: '成为游戏高手' },
  { code: 'collector', name: '图鉴收集家', emoji: '📖', desc: '解锁 3 位居民图鉴', goal: 3, value: s => s.collectionOwned, hint: '和居民们聊聊天' },
  { code: 'collector_all', name: '比奇堡全知己', emoji: '👑', desc: '集齐全部 6 位居民图鉴', goal: 6, value: s => s.collectionOwned, hint: '集齐所有图鉴' },
  { code: 'chatter', name: '交际海绵', emoji: '💬', desc: '累计默契 6 点', goal: 6, value: s => s.rapport, hint: '选对角色的回应' },
  { code: 'checkin3', name: '坚持不懈', emoji: '📅', desc: '连续签到 3 天', goal: 3, value: s => s.checkinStreak, hint: '连续签到 3 天' },
  { code: 'checkin7', name: '常驻居民', emoji: '🏠', desc: '累计签到 7 天', goal: 7, value: s => s.checkinTotal, hint: '累计签到 7 天' },
  { code: 'jelly_friend', name: '水母之友', emoji: '🪼', desc: '照顾水母获得 60 点成长', goal: 60, value: s => s.jellyExp, hint: '多喂喂你的水母' },
  { code: 'wisher', name: '许愿达人', emoji: '💭', desc: '在许愿池留下 3 条心愿', goal: 3, value: s => s.wishes, hint: '写下你的愿望' }
]

function readUnlocked() {
  try {
    const raw = localStorage.getItem(KEY)
    const arr = raw ? JSON.parse(raw) : []
    return Array.isArray(arr) ? arr : []
  } catch (e) { return [] }
}

/** 计算成就当前进度（依据实时数据） */
export function computeProgress() {
  const summary = getProfileSummary()
  return ACHIEVEMENTS.map(a => {
    const cur = Math.max(0, Number(a.value(summary)) || 0)
    return {
      ...a,
      current: Math.min(cur, a.goal),
      raw: cur,
      unlocked: cur >= a.goal,
      percent: a.goal > 0 ? Math.min(100, Math.round(cur / a.goal * 100)) : 0
    }
  })
}

/** 同步已达成成就到存储，返回本次新解锁的成就列表 */
export function syncUnlocked() {
  const list = readUnlocked()
  const progress = computeProgress()
  const fresh = []
  progress.forEach(a => {
    if (a.unlocked && !list.includes(a.code)) {
      list.push(a.code)
      fresh.push(a)
    }
  })
  if (fresh.length) {
    try { localStorage.setItem(KEY, JSON.stringify(list)) } catch (e) { /* ignore */ }
  }
  return fresh
}

/** 读取已永久解锁的 code */
export function getUnlockedCodes() {
  return readUnlocked()
}

/** 汇总：已解锁数 / 总数 / 完成度 */
export function getAchievementSummary() {
  const codes = readUnlocked()
  const unlocked = ACHIEVEMENTS.filter(a => codes.includes(a.code)).length
  return { unlocked, total: ACHIEVEMENTS.length, percent: ACHIEVEMENTS.length ? Math.round(unlocked / ACHIEVEMENTS.length * 100) : 0 }
}

export function resetAchievements() {
  try { localStorage.removeItem(KEY) } catch (e) { /* ignore */ }
}
