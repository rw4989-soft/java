/**
 * 每日签到：纯前端模拟，localStorage 持久化。
 * sb_checkin = { dates: ['YYYY-MM-DD', ...], streak: 连续天数, last: 最近签到日期 }
 */
const KEY = 'sb_checkin'

function todayStr(d = new Date()) {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

function dayDiff(a, b) {
  const pa = a.split('-').map(Number)
  const pb = b.split('-').map(Number)
  const da = new Date(pa[0], pa[1] - 1, pa[2])
  const db = new Date(pb[0], pb[1] - 1, pb[2])
  return Math.round((db - da) / 86400000)
}

function read() {
  try {
    const raw = localStorage.getItem(KEY)
    const obj = raw ? JSON.parse(raw) : null
    if (obj && Array.isArray(obj.dates)) {
      return { dates: obj.dates, streak: Number(obj.streak) || 0, last: obj.last || '' }
    }
  } catch (e) { /* 静默降级 */ }
  return { dates: [], streak: 0, last: '' }
}

function write(state) {
  try { localStorage.setItem(KEY, JSON.stringify(state)) } catch (e) { /* ignore */ }
}

/** 今天是否已签到 */
export function isCheckedToday() {
  const s = read()
  return s.last === todayStr()
}

/** 读取签到状态，附带连续天数、累计天数 */
export function getCheckinState() {
  const s = read()
  return { dates: s.dates, streak: s.streak, total: s.dates.length, checkedToday: s.last === todayStr() }
}

/** 今日签到，返回 { ok, already, streak, total, reward } */
export function checkIn() {
  const s = read()
  const today = todayStr()
  if (s.last === today) {
    return { ok: false, already: true, streak: s.streak, total: s.dates.length, reward: 0 }
  }
  // 连续：上次签到是昨天则 +1，否则重置为 1
  s.streak = s.last && dayDiff(s.last, today) === 1 ? s.streak + 1 : 1
  s.last = today
  if (!s.dates.includes(today)) s.dates.push(today)
  write(s)
  const reward = 10 + Math.min(s.streak, 7) * 5
  return { ok: true, already: false, streak: s.streak, total: s.dates.length, reward }
}

/** 某个日期是否已签到（YYYY-MM-DD） */
export function isDateChecked(date) {
  return read().dates.includes(date)
}

/** 生成某月的日历格子（含前后补位），每年 1/7 月对应索引 */
export function buildMonth(year, month) {
  const first = new Date(year, month, 1)
  const startIdx = first.getDay() // 0=周日
  const days = new Date(year, month + 1, 0).getDate()
  const cells = []
  for (let i = 0; i < startIdx; i++) cells.push(null)
  for (let d = 1; d <= days; d++) cells.push(d)
  return cells
}

/** 只用于调试：清空签到 */
export function resetCheckin() {
  try { localStorage.removeItem(KEY) } catch (e) { /* ignore */ }
}
