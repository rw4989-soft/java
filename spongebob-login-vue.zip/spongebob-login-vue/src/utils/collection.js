/**
 * 图鉴解锁状态：纯前端模拟，用 localStorage 持久化。
 *
 * 解锁规则（有难度）：
 *   - 与角色进行多轮选项对话，每轮选中最契合角色的回应（best）记 1 点默契
 *   - 累计默契达到角色要求（need）后，图鉴自动点亮解锁
 *   - 选错不会扣进度，但也不加默契，可以重来再聊
 *
 * 存储结构：
 *   sb_collection = ['spongebob', ...]              已解锁的角色 code
 *   sb_chat_state = { spongebob: { correct: 2, chats: 3 }, ... }  每个角色的默契与对话次数
 */

const STORAGE_KEY = 'sb_collection'
const CHAT_KEY = 'sb_chat_state'

/* ==================== 已解锁图鉴 ==================== */

/** 读取已解锁的角色 code 列表 */
export function getUnlocked() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    const arr = raw ? JSON.parse(raw) : []
    return Array.isArray(arr) ? arr : []
  } catch (e) {
    return []
  }
}

/** 是否已解锁某角色 */
export function isUnlocked(code) {
  return getUnlocked().includes(code)
}

/** 直接解锁某角色（内部用；满足条件时调用），返回是否本次新解锁 */
export function unlock(code) {
  const list = getUnlocked()
  if (list.includes(code)) return false
  list.push(code)
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list))
  } catch (e) {
    /* 静默降级 */
  }
  return true
}

/** 收集进度：{ owned, total, percent } */
export function getProgress(total) {
  const owned = getUnlocked().length
  return {
    owned,
    total,
    percent: total > 0 ? Math.round((owned / total) * 100) : 0
  }
}

/* ==================== 对话 / 默契状态 ==================== */

/** 读取全部对话状态 */
function readChatState() {
  try {
    const raw = localStorage.getItem(CHAT_KEY)
    const obj = raw ? JSON.parse(raw) : {}
    return obj && typeof obj === 'object' && !Array.isArray(obj) ? obj : {}
  } catch (e) {
    return {}
  }
}

/** 读取某角色的对话状态：{ correct: 已选对次数, chats: 已完成对话轮数 } */
export function getChatState(code) {
  const state = readChatState()
  const s = state[code]
  return {
    correct: Number(s && s.correct) || 0,
    chats: Number(s && s.chats) || 0
  }
}

/**
 * 记录一次对话选择。
 * @param {string} code 角色 code
 * @param {boolean} isBest 本次是否选中了 best 选项
 * @param {number} need 解锁所需默契点
 * @returns {{ correct:number, chats:number, justUnlocked:boolean }}
 *   返回更新后的状态，以及是否因本次达到条件而新解锁图鉴
 */
export function recordChoice(code, isBest, need) {
  const state = readChatState()
  const cur = state[code] || { correct: 0, chats: 0 }
  cur.chats = (Number(cur.chats) || 0) + 1
  if (isBest) cur.correct = (Number(cur.correct) || 0) + 1
  state[code] = cur
  try {
    localStorage.setItem(CHAT_KEY, JSON.stringify(state))
  } catch (e) {
    /* 静默降级 */
  }

  // 达到默契要求 → 解锁图鉴
  let justUnlocked = false
  if (cur.correct >= need && !isUnlocked(code)) {
    justUnlocked = unlock(code)
  }
  return { correct: cur.correct, chats: cur.chats, justUnlocked }
}

/* ==================== 重置 ==================== */

/** 清空收集与对话进度（调试 / 重置图鉴用） */
export function resetCollection() {
  try {
    localStorage.removeItem(STORAGE_KEY)
    localStorage.removeItem(CHAT_KEY)
  } catch (e) {
    /* ignore */
  }
}
