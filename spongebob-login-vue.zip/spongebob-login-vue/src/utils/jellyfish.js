/**
 * 水母养成：纯前端模拟，localStorage 持久化。
 * sb_jelly = { name, hunger, mood, exp, last, feeds }
 *  - hunger 饱食度 0-100，随时间下降
 *  - mood 心情 0-100，随时间缓慢下降
 *  - exp 成长经验，喂食/互动增加，决定成长阶段
 */
const KEY = 'sb_jelly'
const HOUR = 3600000

const STAGES = [
  { min: 0, name: '水母宝宝', emoji: '🪼', desc: '刚孵化出来，小小的一只' },
  { min: 60, name: '小小水母', emoji: '🪼', desc: '开始好奇地探索海底' },
  { min: 160, name: '活泼水母', emoji: '🎐', desc: '喜欢跟着你游来游去' },
  { min: 320, name: '闪耀水母', emoji: '✨', desc: '在暗处会发出温柔的光' },
  { min: 560, name: '水母之王', emoji: '👑', desc: '比奇堡最优雅的伙伴' }
]

function defaults() {
  return { name: '小果冻', hunger: 70, mood: 75, exp: 0, last: Date.now(), feeds: 0 }
}

function read() {
  try {
    const raw = localStorage.getItem(KEY)
    const obj = raw ? JSON.parse(raw) : null
    if (obj && typeof obj === 'object') return { ...defaults(), ...obj }
  } catch (e) { /* ignore */ }
  return defaults()
}

function write(s) {
  try { localStorage.setItem(KEY, JSON.stringify(s)) } catch (e) { /* ignore */ }
}

/** 按时间流逝衰减状态，返回最新状态 */
export function getJelly() {
  const s = read()
  const now = Date.now()
  const hours = Math.max(0, (now - (s.last || now)) / HOUR)
  if (hours > 0.05) {
    s.hunger = Math.max(0, Math.round(s.hunger - hours * 4))
    s.mood = Math.max(0, Math.round(s.mood - hours * 2.5))
    s.last = now
    write(s)
  }
  return s
}

/** 当前成长阶段 */
export function getStage(exp) {
  let stage = STAGES[0]
  for (const s of STAGES) if ((exp || 0) >= s.min) stage = s
  return stage
}

/** 下一阶段信息（已满级返回 null） */
export function getNextStage(exp) {
  for (const s of STAGES) if ((exp || 0) < s.min) return s
  return null
}

/** 全部阶段（展示用） */
export function allStages() { return STAGES.slice() }

/** 喂食：+饱食 +经验 */
export function feed() {
  const s = getJelly()
  s.hunger = Math.min(100, s.hunger + 18)
  s.mood = Math.min(100, s.mood + 5)
  s.exp += 12
  s.feeds += 1
  s.last = Date.now()
  write(s)
  return s
}

/** 互动（摸摸/玩耍）：+心情 +经验 */
export function play() {
  const s = getJelly()
  s.mood = Math.min(100, s.mood + 14)
  s.hunger = Math.max(0, s.hunger - 4)
  s.exp += 8
  s.last = Date.now()
  write(s)
  return s
}

/** 改名 */
export function rename(name) {
  const s = getJelly()
  s.name = String(name || '').trim().slice(0, 12) || '小果冻'
  write(s)
  return s
}

/** 状态文案 */
export function moodLabel(mood) {
  if (mood >= 80) return '超开心'
  if (mood >= 55) return '心情不错'
  if (mood >= 30) return '有点无聊'
  return '有点想你'
}

export function hungerLabel(hunger) {
  if (hunger >= 75) return '吃得饱饱'
  if (hunger >= 45) return '有点饿'
  return '饿扁啦'
}

export function resetJelly() {
  try { localStorage.removeItem(KEY) } catch (e) { /* ignore */ }
}
