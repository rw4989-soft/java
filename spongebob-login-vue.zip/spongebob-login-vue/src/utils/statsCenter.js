/**
 * 数据中心：聚合各模块数据，供「玩家名片」与「成就」使用。
 * 纯读取现有数据源（collection / checkin / jellyfish / wishes / auth），
 * 游戏成绩通过后端接口拉取后缓存在 localStorage，避免每次都等网络。
 */
import { getUnlocked } from './collection.js'
import { getCheckinState } from './checkin.js'
import { getJelly } from './jellyfish.js'
import { getWishes } from './wishes.js'
import { getNickname, getUsername } from './auth.js'
import { getGameOverview } from '../api/game.js'

const GAME_CACHE_KEY = 'sb_game_cache'
const GAMES = [
  { code: 'burger', name: '出餐大作战', emoji: '🍔' },
  { code: 'memory', name: '记忆翻牌', emoji: '🃏' },
  { code: 'catch', name: '接蟹堡', emoji: '🧀' },
  { code: 'quiz', name: '知识问答', emoji: '🧠' },
  { code: 'puzzle', name: '蟹堡拼图', emoji: '🧩' },
  { code: 'bubble', name: '泡泡大作战', emoji: '🫧' }
]

export const GAME_LIST = GAMES.slice()

function readCache() {
  try {
    const raw = localStorage.getItem(GAME_CACHE_KEY)
    const obj = raw ? JSON.parse(raw) : null
    return obj && typeof obj === 'object' ? obj : {}
  } catch (e) { return {} }
}

/** 读取缓存的各游戏概览（没有则返回零值） */
export function getGameStats() {
  const cache = readCache()
  return GAMES.map(g => {
    const d = cache[g.code]
    return {
      ...g,
      bestScore: Number(d && d.bestScore) || 0,
      plays: Number(d && d.plays) || 0,
      rank: (d && d.rank) || '铁铲学徒',
      rankIcon: (d && d.rankIcon) || '🔧'
    }
  })
}

/** 静默刷新所有游戏成绩缓存（失败不影响页面） */
export async function refreshGameStats() {
  const cache = readCache()
  await Promise.all(GAMES.map(async g => {
    try {
      const r = await getGameOverview(g.code)
      if (r && r.ok && r.data) cache[g.code] = r.data
    } catch (e) { /* 静默降级，用旧缓存 */ }
  }))
  try { localStorage.setItem(GAME_CACHE_KEY, JSON.stringify(cache)) } catch (e) { /* ignore */ }
  return getGameStats()
}

/** 一句话聚合所有模块数据，成就判定与名片共用 */
export function getProfileSummary() {
  const chat = safeChatState()
  const checkin = getCheckinState()
  const jelly = getJelly()
  const gameStats = getGameStats()
  const totalBest = gameStats.reduce((s, g) => s + g.bestScore, 0)
  const totalPlays = gameStats.reduce((s, g) => s + g.plays, 0)
  const rapport = Object.values(chat).reduce((s, v) => s + (Number(v.correct) || 0), 0)
  return {
    nickname: getNickname() || '海绵宝宝',
    username: getUsername(),
    collectionOwned: getUnlocked().length,
    collectionTotal: 6,
    rapport,
    checkinStreak: checkin.streak,
    checkinTotal: checkin.total,
    jellyExp: jelly.exp || 0,
    jellyFeeds: jelly.feeds || 0,
    wishes: getWishes().length,
    gameBestTotal: totalBest,
    gamePlays: totalPlays,
    gameCount: gameStats.filter(g => g.plays > 0).length
  }
}

function safeChatState() {
  try {
    const raw = localStorage.getItem('sb_chat_state')
    const obj = raw ? JSON.parse(raw) : null
    return obj && typeof obj === 'object' && !Array.isArray(obj) ? obj : {}
  } catch (e) { return {} }
}
