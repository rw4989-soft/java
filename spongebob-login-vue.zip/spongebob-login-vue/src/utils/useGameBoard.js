/**
 * 小游戏排行榜逻辑复用：读取最佳成绩/榜单、提交成绩。
 * 各小游戏引入后自己负责展示 UI。
 */
import { ref } from 'vue'
import { getGameOverview, submitScore } from '../api/game.js'

export function useGameBoard(gameCode) {
  const board = ref({
    bestScore: 0,
    bestCombo: 0,
    plays: 0,
    rank: '铁铲学徒',
    rankIcon: '🔧',
    myRank: 0,
    leaderboard: []
  })
  const loading = ref(false)
  const lastResult = ref(null)

  async function load() {
    loading.value = true
    try {
      const r = await getGameOverview(gameCode)
      if (r.ok) board.value = r.data || board.value
    } finally {
      loading.value = false
    }
  }

  /** 提交一局；commits = { score, combo, burgers } */
  async function commit({ score, combo = 0, count = 0 }) {
    const r = await submitScore({ score, combo, burgers: count, gameCode })
    if (r.ok) {
      lastResult.value = r.data || {}
      board.value = {
        ...board.value,
        bestScore: r.data?.bestScore ?? board.value.bestScore,
        bestCombo: r.data?.bestCombo ?? board.value.bestCombo,
        plays: r.data?.plays ?? board.value.plays,
        rank: r.data?.rank ?? board.value.rank,
        rankIcon: r.data?.rankIcon ?? board.value.rankIcon,
        myRank: r.data?.myRank ?? board.value.myRank,
        leaderboard: r.data?.leaderboard ?? board.value.leaderboard
      }
    }
    return r
  }

  load()
  return { board, loading, lastResult, load, commit }
}
