/**
 * 留言许愿池：纯前端模拟，localStorage 持久化。
 * sb_wishes = [{ id, nickname, avatar, text, time }]
 */
const KEY = 'sb_wishes'

const AVATARS = ['🧽', '⭐', '🐙', '🐿️', '🦀', '🐌', '🪼', '🐟']

function read() {
  try {
    const raw = localStorage.getItem(KEY)
    const arr = raw ? JSON.parse(raw) : null
    return Array.isArray(arr) ? arr : []
  } catch (e) { return [] }
}

function write(list) {
  try { localStorage.setItem(KEY, JSON.stringify(list)) } catch (e) { /* ignore */ }
}

const SEED = [
  { id: 'seed-1', nickname: '海绵宝宝', avatar: '🧽', text: '我准备好了！祝大家每天都像吃到蟹黄堡一样开心！', time: Date.now() - 86400000 * 3 },
  { id: 'seed-2', nickname: '派大星', avatar: '⭐', text: '如果泡泡是方形的，那我们是不是就住在方块里啦？', time: Date.now() - 86400000 * 2 },
  { id: 'seed-3', nickname: '小蜗', avatar: '🐌', text: '螺～（今天也要慢慢来）', time: Date.now() - 86400000 }
]

/** 读取全部留言（按时间倒序），首次自动放入几条示例 */
export function getWishes() {
  let list = read()
  if (list.length === 0 && !localStorage.getItem(KEY + '_seeded')) {
    list = SEED.slice()
    write(list)
    try { localStorage.setItem(KEY + '_seeded', '1') } catch (e) { /* ignore */ }
  }
  return list.slice().sort((a, b) => b.time - a.time)
}

/** 发布留言 */
export function addWish({ nickname, text }) {
  const list = read()
  const wish = {
    id: 'w-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
    nickname: nickname || '匿名游客',
    avatar: AVATARS[Math.floor(Math.random() * AVATARS.length)],
    text: String(text || '').trim().slice(0, 120),
    time: Date.now()
  }
  if (!wish.text) return null
  list.push(wish)
  write(list)
  return wish
}

/** 删除留言（按 id） */
export function removeWish(id) {
  write(read().filter(w => w.id !== id))
}

/** 相对时间文案 */
export function timeAgo(ts) {
  const diff = Date.now() - ts
  const min = Math.floor(diff / 60000)
  if (min < 1) return '刚刚'
  if (min < 60) return min + ' 分钟前'
  const h = Math.floor(min / 60)
  if (h < 24) return h + ' 小时前'
  const d = Math.floor(h / 24)
  if (d < 30) return d + ' 天前'
  return new Date(ts).toLocaleDateString('zh-CN')
}
