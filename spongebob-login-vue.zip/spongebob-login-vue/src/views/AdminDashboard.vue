<template>
  <div class="admin">
    <!-- ================= 顶栏 ================= -->
    <header class="topbar">
      <div class="brand">
        <span class="brand-logo">🛠️</span>
        <span class="brand-text">
          <strong>比奇堡管理后台</strong>
          <em>BIKINI BOTTOM ADMIN</em>
        </span>
      </div>
      <div class="right">
        <div class="user-chip" :title="adminName">
          <span class="avatar">👑</span>
          <span class="user-name">{{ adminName }}</span>
        </div>
        <button class="logout" type="button" @click="logout">退出后台</button>
      </div>
    </header>

    <main class="main">
      <!-- 统计卡片 -->
      <section class="stats">
        <div class="stat-card" v-for="s in statCards" :key="s.label">
          <span class="stat-icon">{{ s.icon }}</span>
          <span class="stat-value">{{ s.value }}</span>
          <span class="stat-label">{{ s.label }}</span>
        </div>
      </section>

      <!-- 选项卡 -->
      <nav class="tabs">
        <button :class="['tab', { active: tab === 'category' }]" @click="tab = 'category'">🗂️ 分类管理</button>
        <button :class="['tab', { active: tab === 'place' }]" @click="tab = 'place'">📍 地点管理</button>
      </nav>

      <!-- ============ 分类管理 ============ -->
      <section v-show="tab === 'category'" class="panel">
        <div class="toolbar">
          <h2>分类数据 <small>首页导航与筛选都来自这里</small></h2>
          <button class="primary" @click="openCategoryModal('create')">＋ 新增分类</button>
        </div>

        <div v-if="catLoading" class="hint">加载中…</div>
        <table v-else class="tbl">
          <thead>
            <tr>
              <th>图标</th><th>名称</th><th>编码</th><th>父级</th>
              <th>排序</th><th>子分类</th><th>地点数</th><th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="c in categories" :key="c.id">
              <td class="center">{{ c.icon || '—' }}</td>
              <td>{{ c.name }}</td>
              <td><code>{{ c.code }}</code></td>
              <td>{{ c.parentName || '（一级）' }}</td>
              <td class="center">{{ c.sortNo }}</td>
              <td class="center">{{ c.childCount }}</td>
              <td class="center">{{ c.placeCount }}</td>
              <td class="center ops">
                <button class="mini" @click="openCategoryModal('edit', c)">编辑</button>
                <button class="mini danger" @click="removeCategory(c)">删除</button>
              </td>
            </tr>
            <tr v-if="!categories.length"><td colspan="8" class="empty">还没有分类数据</td></tr>
          </tbody>
        </table>
      </section>

      <!-- ============ 地点管理 ============ -->
      <section v-show="tab === 'place'" class="panel">
        <div class="toolbar">
          <h2>地点数据 <small>首页卡片展示的内容</small></h2>
          <button class="primary" @click="openPlaceModal('create')">＋ 新增地点</button>
        </div>

        <div class="filters">
          <input v-model="filters.keyword" class="f-input" placeholder="搜索名称 / 标签 / 简介" @input="onFilter">
          <select v-model="filters.categoryId" class="f-input" @change="onFilter">
            <option :value="null">全部分类</option>
            <option v-for="c in categoryOptions" :key="c.id" :value="c.id">{{ c.label }}</option>
          </select>
          <select v-model="filters.grade" class="f-input" @change="onFilter">
            <option value="">全部分级</option>
            <option value="S">S 传说级</option>
            <option value="A">A 稀有级</option>
            <option value="B">B 常见级</option>
            <option value="C">C 普通级</option>
          </select>
          <span class="count">共 {{ places.length }} 条</span>
        </div>

        <div v-if="placeLoading" class="hint">加载中…</div>
        <table v-else class="tbl">
          <thead>
            <tr>
              <th>图标</th><th>名称</th><th>分类</th><th>分级</th>
              <th>评分</th><th>热度</th><th>浏览</th><th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="p in places" :key="p.id">
              <td class="center">{{ p.emoji || '—' }}</td>
              <td>{{ p.name }}</td>
              <td>{{ p.parentName }}<template v-if="p.categoryName"> / {{ p.categoryName }}</template></td>
              <td class="center">
                <span class="grade" :class="'g-' + (p.grade || '')">{{ p.grade }}</span>
              </td>
              <td class="center">{{ p.rating }}</td>
              <td class="center">{{ p.heat }}</td>
              <td class="center">{{ p.viewCount }}</td>
              <td class="center ops">
                <button class="mini" @click="openPlaceModal('edit', p)">编辑</button>
                <button class="mini danger" @click="removePlace(p)">删除</button>
              </td>
            </tr>
            <tr v-if="!places.length"><td colspan="8" class="empty">没有符合条件的地点</td></tr>
          </tbody>
        </table>
      </section>
    </main>

    <!-- ============ 分类弹窗 ============ -->
    <transition name="modal">
      <div v-if="catModal" class="mask" @click.self="catModal = false">
        <div class="dialog">
          <h3>{{ catMode === 'create' ? '新增分类' : '编辑分类' }}</h3>
          <div class="fld">
            <label>名称</label>
            <input v-model="catForm.name" placeholder="如：美食">
          </div>
          <div class="fld">
            <label>编码 <small>（前端筛选用，唯一）</small></label>
            <input v-model="catForm.code" placeholder="如：food">
          </div>
          <div class="fld">
            <label>图标</label>
            <input v-model="catForm.icon" placeholder="如：🍔（emoji）">
          </div>
          <div class="fld">
            <label>父级</label>
            <select v-model.number="catForm.parentId">
              <option :value="0">（作为一级分类）</option>
              <option v-for="c in topCategories" :key="c.id" :value="c.id">{{ c.name }}</option>
            </select>
          </div>
          <div class="fld">
            <label>排序号</label>
            <input v-model.number="catForm.sortNo" type="number" placeholder="数字越小越靠前">
          </div>
          <div class="dialog-ops">
            <button class="ghost" @click="catModal = false">取消</button>
            <button class="primary" :disabled="saving" @click="saveCategory">{{ saving ? '保存中…' : '保存' }}</button>
          </div>
        </div>
      </div>
    </transition>

    <!-- ============ 地点弹窗 ============ -->
    <transition name="modal">
      <div v-if="placeModal" class="mask" @click.self="placeModal = false">
        <div class="dialog">
          <h3>{{ placeMode === 'create' ? '新增地点' : '编辑地点' }}</h3>
          <div class="fld">
            <label>名称</label>
            <input v-model="placeForm.name" placeholder="如：蟹黄堡小屋">
          </div>
          <div class="fld">
            <label>图标</label>
            <input v-model="placeForm.emoji" placeholder="如：🍔">
          </div>
          <div class="fld">
            <label>所属分类</label>
            <select v-model.number="placeForm.categoryId">
              <option :value="null">请选择分类</option>
              <option v-for="c in categoryOptions" :key="c.id" :value="c.id">{{ c.label }}</option>
            </select>
          </div>
          <div class="fld">
            <label>分级</label>
            <select v-model="placeForm.grade">
              <option value="">不评级</option>
              <option value="S">S 传说级</option>
              <option value="A">A 稀有级</option>
              <option value="B">B 常见级</option>
              <option value="C">C 普通级</option>
            </select>
          </div>
          <div class="row">
            <div class="fld">
              <label>评分</label>
              <input v-model.number="placeForm.rating" type="number" step="0.1" placeholder="0-5">
            </div>
            <div class="fld">
              <label>热度</label>
              <input v-model.number="placeForm.heat" type="number" placeholder="整数">
            </div>
          </div>
          <div class="fld">
            <label>一句话简介</label>
            <input v-model="placeForm.summary" placeholder="简短描述">
          </div>
          <div class="fld">
            <label>详细介绍</label>
            <textarea v-model="placeForm.detail" rows="3" placeholder="详细介绍（支持多行）"></textarea>
          </div>
          <div class="fld">
            <label>标签 <small>（逗号分隔）</small></label>
            <input v-model="placeForm.tags" placeholder="如：美食,必吃,蟹堡王">
          </div>
          <div class="dialog-ops">
            <button class="ghost" @click="placeModal = false">取消</button>
            <button class="primary" :disabled="saving" @click="savePlace">{{ saving ? '保存中…' : '保存' }}</button>
          </div>
        </div>
      </div>
    </transition>

    <transition name="toast">
      <div v-if="toast" class="toast" :class="toastType">{{ toast }}</div>
    </transition>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import {
  adminLogout, adminMe, createCategory, createPlace, deleteCategory, deletePlace,
  getStats, listCategories, listPlaces, updateCategory, updatePlace
} from '../api/admin.js'
import { clearAdminSession, getAdminUsername } from '../utils/auth.js'

const router = useRouter()

const adminName = ref(getAdminUsername() || '管理员')
const tab = ref('category')

const stats = ref({ categoryCount: 0, placeCount: 0, totalViews: 0, avgRating: '0' })
const statCards = computed(() => [
  { icon: '🗂️', label: '分类数量', value: stats.value.categoryCount },
  { icon: '📍', label: '地点数量', value: stats.value.placeCount },
  { icon: '👀', label: '累计浏览', value: stats.value.totalViews },
  { icon: '⭐', label: '平均评分', value: stats.value.avgRating }
])

const categories = ref([])
const catLoading = ref(false)
const places = ref([])
const placeLoading = ref(false)

const filters = reactive({ keyword: '', categoryId: null, grade: '' })

const toast = ref('')
const toastType = ref('')
let toastTimer = null

// 一级分类（用于分类表单的父级下拉）
const topCategories = computed(() => categories.value.filter((c) => !c.parentName))
// 全部分类（用于地点表单的分类下拉，带层级前缀）
const categoryOptions = computed(() =>
  categories.value.map((c) => ({
    id: c.id,
    label: c.parentName ? `${c.parentName} / ${c.name}` : c.name
  }))
)

// ============ 弹窗状态 ============
const catModal = ref(false)
const catMode = ref('create')
const catForm = reactive({ id: null, name: '', code: '', icon: '', parentId: 0, sortNo: 0 })

const placeModal = ref(false)
const placeMode = ref('create')
const placeForm = reactive({
  id: null, name: '', emoji: '', categoryId: null, grade: '',
  rating: null, heat: null, summary: '', detail: '', tags: ''
})

const saving = ref(false)

// ============ 工具 ============
function showToast(text, type = 'ok') {
  toast.value = text
  toastType.value = type
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toast.value = '' }, 2400)
}

function emptyCatForm() {
  Object.assign(catForm, { id: null, name: '', code: '', icon: '', parentId: 0, sortNo: 0 })
}
function emptyPlaceForm() {
  Object.assign(placeForm, {
    id: null, name: '', emoji: '', categoryId: null, grade: '',
    rating: null, heat: null, summary: '', detail: '', tags: ''
  })
}

// ============ 数据加载 ============
async function loadStats() {
  const r = await getStats()
  if (r.ok) stats.value = r.data
}
async function loadCategories() {
  catLoading.value = true
  const r = await listCategories()
  catLoading.value = false
  if (r.ok) categories.value = r.data || []
  else if (r.code === 401) return goLogin()
  else showToast(r.message, 'err')
}
async function loadPlaces() {
  placeLoading.value = true
  const r = await listPlaces({
    keyword: filters.keyword,
    categoryId: filters.categoryId || undefined,
    grade: filters.grade || undefined,
    page: 1,
    size: 200
  })
  placeLoading.value = false
  if (r.ok) places.value = (r.data?.list || [])
  else if (r.code === 401) return goLogin()
  else showToast(r.message, 'err')
}

function onFilter() {
  loadPlaces()
}

function goLogin() {
  clearAdminSession()
  router.replace({ name: 'adminLogin' })
}

// ============ 分类弹窗 ============
function openCategoryModal(mode, item) {
  catMode.value = mode
  emptyCatForm()
  if (mode === 'edit' && item) {
    catForm.id = item.id
    catForm.name = item.name
    catForm.code = item.code
    catForm.icon = item.icon || ''
    catForm.parentId = item.parentId || 0
    catForm.sortNo = item.sortNo || 0
  }
  catModal.value = true
}

async function saveCategory() {
  saving.value = true
  const payload = {
    name: catForm.name.trim(),
    code: catForm.code.trim(),
    icon: catForm.icon.trim(),
    parentId: catForm.parentId || 0,
    sortNo: catForm.sortNo || 0
  }
  const r = catMode.value === 'create'
    ? await createCategory(payload)
    : await updateCategory(catForm.id, payload)
  saving.value = false
  if (r.ok) {
    catModal.value = false
    showToast(r.message)
    await loadCategories()
  } else {
    showToast(r.message, 'err')
  }
}

async function removeCategory(item) {
  if (!confirm(`确定删除分类「${item.name}」吗？若有子分类或地点会先被拦截。`)) return
  const r = await deleteCategory(item.id)
  if (r.ok) {
    showToast(r.message)
    await loadCategories()
  } else {
    showToast(r.message, 'err')
  }
}

// ============ 地点弹窗 ============
function openPlaceModal(mode, item) {
  placeMode.value = mode
  emptyPlaceForm()
  if (mode === 'edit' && item) {
    placeForm.id = item.id
    placeForm.name = item.name
    placeForm.emoji = item.emoji || ''
    placeForm.categoryId = item.categoryId
    placeForm.grade = item.grade || ''
    placeForm.rating = item.rating ?? null
    placeForm.heat = item.heat ?? null
    placeForm.summary = item.summary || ''
    placeForm.detail = item.detail || ''
    placeForm.tags = item.tags || ''
  }
  placeModal.value = true
}

async function savePlace() {
  saving.value = true
  const payload = {
    name: placeForm.name.trim(),
    emoji: placeForm.emoji.trim(),
    categoryId: placeForm.categoryId,
    grade: placeForm.grade || '',
    rating: placeForm.rating === '' || placeForm.rating === null ? null : Number(placeForm.rating),
    heat: placeForm.heat === '' || placeForm.heat === null ? 0 : Number(placeForm.heat),
    summary: placeForm.summary,
    detail: placeForm.detail,
    tags: placeForm.tags
  }
  const r = placeMode.value === 'create'
    ? await createPlace(payload)
    : await updatePlace(placeForm.id, payload)
  saving.value = false
  if (r.ok) {
    placeModal.value = false
    showToast(r.message)
    await loadPlaces()
  } else {
    showToast(r.message, 'err')
  }
}

async function removePlace(item) {
  if (!confirm(`确定删除地点「${item.name}」吗？`)) return
  const r = await deletePlace(item.id)
  if (r.ok) {
    showToast(r.message)
    await loadPlaces()
  } else {
    showToast(r.message, 'err')
  }
}

// ============ 退出 ============
async function logout() {
  await adminLogout()
  clearAdminSession()
  router.replace({ name: 'adminLogin' })
}

onMounted(async () => {
  // 先确认管理员 token 仍然有效（防止服务端重启 / 过期）
  const me = await adminMe()
  if (!me.ok) {
    goLogin()
    return
  }
  adminName.value = me.data?.username || adminName.value
  await Promise.all([loadStats(), loadCategories(), loadPlaces()])
})
</script>

<style scoped>
.admin {
  min-height: 100vh;
  color: #eaf7ff;
  background: linear-gradient(180deg, #2a1a4a 0%, #1d2b54 45%, #0f2a4a 100%);
}

/* 顶栏 */
.topbar {
  position: sticky;
  top: 0;
  z-index: 50;
  background: rgba(30, 18, 60, 0.85);
  backdrop-filter: blur(14px);
  box-shadow: 0 6px 24px rgba(0, 0, 0, 0.35);
  border-bottom: 3px solid rgba(186, 142, 255, 0.6);
}
.topbar .brand { display: flex; align-items: center; gap: 10px; }
.brand-logo {
  width: 42px; height: 42px;
  display: grid; place-items: center;
  font-size: 22px;
  background: linear-gradient(180deg, #d9c2ff, #9b66e6);
  border: 3px solid #c9a3ff;
  border-radius: 14px;
  box-shadow: 0 3px 0 #6a3fb0;
}
.brand-text { display: flex; flex-direction: column; line-height: 1.15; }
.brand-text strong { color: #fff; font-size: 18px; letter-spacing: 2px; }
.brand-text em { font-style: normal; font-size: 10px; letter-spacing: 1.5px; color: #c9a3ff; }

.topbar {
  display: flex; align-items: center; justify-content: space-between;
  max-width: 1180px; margin: 0 auto; padding: 10px 20px;
}
.right { display: flex; align-items: center; gap: 10px; }
.user-chip {
  display: flex; align-items: center; gap: 7px;
  padding: 5px 14px 5px 6px;
  background: rgba(186, 142, 255, 0.16);
  border: 2px solid rgba(186, 142, 255, 0.45);
  border-radius: 999px;
}
.avatar {
  width: 28px; height: 28px; display: grid; place-items: center;
  font-size: 16px; background: rgba(255,255,255,.9); border-radius: 50%;
}
.user-name { font-size: 14px; font-weight: bold; color: #eaf7ff; }
.logout {
  border: 2px solid rgba(186, 142, 255, 0.45);
  background: transparent; color: #e7c8ff;
  padding: 6px 14px; border-radius: 999px;
  font-family: inherit; font-size: 13px; font-weight: bold; cursor: pointer;
  transition: all .2s;
}
.logout:hover { background: rgba(255,205,210,.18); border-color: #ff8a80; color: #ffcdd2; }

/* 主区 */
.main { max-width: 1180px; margin: 0 auto; padding: 28px 20px 60px; }

/* 统计 */
.stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; margin-bottom: 24px; }
.stat-card {
  display: flex; flex-direction: column; align-items: center; gap: 4px;
  padding: 18px; border-radius: 18px;
  background: rgba(255,255,255,.08);
  border: 2px solid rgba(186,142,255,.35);
}
.stat-icon { font-size: 24px; }
.stat-value { font-size: 26px; font-weight: bold; color: #ffe082; }
.stat-label { font-size: 12px; color: #d9c2ff; }

/* 选项卡 */
.tabs { display: flex; gap: 8px; margin-bottom: 18px; }
.tab {
  border: 2px solid rgba(186,142,255,.4);
  background: rgba(255,255,255,.06);
  color: #d9c2ff; padding: 10px 20px; border-radius: 14px;
  font-family: inherit; font-size: 15px; font-weight: bold; cursor: pointer;
  transition: all .2s;
}
.tab.active {
  background: linear-gradient(180deg, #c9a3ff, #9b66e6);
  border-color: #c9a3ff; color: #fff;
  box-shadow: 0 3px 0 #6a3fb0;
}

/* 面板 */
.panel {
  background: rgba(255,255,255,.07);
  border: 2px solid rgba(186,142,255,.28);
  border-radius: 20px; padding: 20px;
}
.toolbar { display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; }
.toolbar h2 { font-size: 18px; color: #fff; }
.toolbar h2 small { font-size: 12px; font-weight: normal; color: #c9a3ff; margin-left: 8px; }

.primary {
  border: none; padding: 9px 18px; border-radius: 12px;
  background: linear-gradient(180deg, #ffd54f, #ffb300);
  color: #5d3700; font-family: inherit; font-size: 14px; font-weight: bold;
  cursor: pointer; box-shadow: 0 3px 0 #c17900; transition: transform .1s, filter .2s;
}
.primary:hover { filter: brightness(1.05); }
.primary:active { transform: translateY(2px); }
.primary:disabled { opacity: .6; cursor: default; }

.hint { text-align: center; padding: 30px; color: #c9a3ff; }
.empty { text-align: center; padding: 24px; color: #c9a3ff; }

/* 筛选 */
.filters { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; margin-bottom: 14px; }
.f-input {
  border: 2px solid rgba(186,142,255,.4);
  background: rgba(255,255,255,.1); color: #fff;
  padding: 8px 12px; border-radius: 10px; font-family: inherit; font-size: 14px;
  outline: none; min-width: 160px;
}
.f-input option { color: #222; }
.count { font-size: 12px; color: #c9a3ff; margin-left: auto; }

/* 表格 */
.tbl { width: 100%; border-collapse: collapse; font-size: 14px; }
.tbl th, .tbl td { padding: 10px 12px; text-align: left; }
.tbl thead th {
  color: #c9a3ff; font-size: 12px; letter-spacing: 1px;
  border-bottom: 2px solid rgba(186,142,255,.4);
}
.tbl tbody tr { border-bottom: 1px dashed rgba(186,142,255,.18); }
.tbl tbody tr:hover { background: rgba(186,142,255,.08); }
.center { text-align: center; }
code { background: rgba(186,142,255,.18); padding: 2px 6px; border-radius: 6px; font-size: 12px; }
.grade {
  display: inline-block; padding: 2px 9px; border-radius: 999px; font-size: 11px; font-weight: bold;
}
.g-S { background: linear-gradient(180deg,#ffd54f,#ffb300); color: #5d3700; }
.g-A { background: linear-gradient(180deg,#9fe5ff,#4fc3f7); color: #04334d; }
.g-B { background: linear-gradient(180deg,#dbeaf3,#a9c6d7); color: #24414f; }
.g-C { background: linear-gradient(180deg,#ececec,#c2c2c2); color: #454545; }

.ops { white-space: nowrap; }
.mini {
  border: 2px solid rgba(186,142,255,.4); background: transparent; color: #e7c8ff;
  padding: 4px 12px; border-radius: 8px; font-family: inherit; font-size: 12px; cursor: pointer;
  transition: all .2s; margin: 0 2px;
}
.mini:hover { background: rgba(186,142,255,.2); }
.mini.danger { border-color: rgba(255,138,128,.5); color: #ffcdd2; }
.mini.danger:hover { background: rgba(255,138,128,.18); }

/* 弹窗 */
.mask {
  position: fixed; inset: 0; z-index: 80;
  display: grid; place-items: center; padding: 20px;
  background: rgba(8, 6, 24, .62); backdrop-filter: blur(4px);
}
.dialog {
  width: min(480px, 100%); max-height: 86vh; overflow: auto;
  padding: 24px; border-radius: 22px;
  background: linear-gradient(160deg,#fffdf5,#eaf8ff);
  border: 3px solid #9b66e6; color: #2c2350;
  box-shadow: 0 12px 0 rgba(106,63,176,.4), 0 30px 60px rgba(0,0,0,.5);
}
.dialog h3 { font-size: 19px; color: #6a3fb0; margin-bottom: 16px; }
.fld { margin-bottom: 12px; display: flex; flex-direction: column; gap: 5px; }
.fld label { font-size: 13px; font-weight: bold; color: #5d4a8a; }
.fld label small { font-weight: normal; color: #9b8abf; }
.fld input, .fld select, .fld textarea {
  border: 2px solid #d9c2ff; border-radius: 10px; padding: 9px 11px;
  font-family: inherit; font-size: 14px; color: #2c2350; background: #faf6ff; outline: none;
}
.fld input:focus, .fld select:focus, .fld textarea:focus { border-color: #9b66e6; }
.fld textarea { resize: vertical; }
.row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.dialog-ops { display: flex; justify-content: flex-end; gap: 10px; margin-top: 8px; }
.ghost {
  border: 2px solid #d9c2ff; background: transparent; color: #6a3fb0;
  padding: 9px 18px; border-radius: 12px; font-family: inherit; font-size: 14px; font-weight: bold; cursor: pointer;
}
.ghost:hover { background: #f1e9ff; }

.modal-enter-active, .modal-leave-active { transition: opacity .2s; }
.modal-enter-from, .modal-leave-to { opacity: 0; }

/* toast */
.toast {
  position: fixed; left: 50%; bottom: 40px; transform: translateX(-50%);
  z-index: 99; padding: 12px 22px; border-radius: 999px;
  background: rgba(255,253,240,.98); border: 3px solid #9b66e6;
  color: #5d3700; font-size: 14px; font-weight: bold; box-shadow: 0 8px 24px rgba(0,0,0,.4);
  max-width: 88vw; text-align: center;
}
.toast.err { border-color: #ff8a80; color: #b71c1c; }
.toast-enter-active, .toast-leave-active { transition: opacity .25s, transform .25s; }
.toast-enter-from, .toast-leave-to { opacity: 0; transform: translate(-50%, 12px); }

@media (max-width: 860px) {
  .stats { grid-template-columns: repeat(2, 1fr); }
  .user-name { display: none; }
  .brand-text { display: none; }
}
</style>
