<template>
  <div class="admin">
    <!-- ================= 顶栏 ================= -->
    <header class="topbar">
      <div class="brand">
        <span class="brand-logo">🛠️</span>
        <span class="brand-text">
          <strong>比奇堡管理后台</strong>
          <em>BIKINI BOTTOM ADMIN</em>
        </span>
      </div>
      <div class="right">
        <div class="user-chip" :title="adminName">
          <span class="avatar">👑</span>
          <span class="user-name">{{ adminName }}</span>
        </div>
        <button v-if="embedded" class="logout" type="button" @click="$emit('close')">✕ 返回首页</button>
        <button v-else class="logout" type="button" @click="logout">退出后台</button>
      </div>
    </header>

    <main class="main">
      <!-- 统计卡片 -->
      <section class="stats">
        <div class="stat-card" v-for="s in statCards" :key="s.label">
          <span class="stat-icon">{{ s.icon }}</span>
          <span class="stat-value">{{ s.value }}</span>
          <span class="stat-label">{{ s.label }}</span>
        </div>
      </section>

      <!-- 选项卡 -->
      <nav class="tabs">
        <button :class="['tab', { active: tab === 'category' }]" @click="tab = 'category'">🗂️ 分类管理</button>
        <button :class="['tab', { active: tab === 'place' }]" @click="tab = 'place'">📍 地点管理</button>
        <button :class="['tab', { active: tab === 'user' }]" @click="switchTab('user')">👥 用户管理</button>
      </nav>

      <!-- ============ 分类管理 ============ -->
      <section v-show="tab === 'category'" class="panel">
        <div class="toolbar">
          <h2>分类数据 <small>首页导航与筛选都来自这里</small></h2>
          <button class="primary" @click="openCategoryModal('create')">＋ 新增分类</button>
        </div>

        <div v-if="catLoading" class="hint">加载中…</div>
        <table v-else class="tbl">
          <thead>
            <tr>
              <th>图标</th><th>名称</th><th>编码</th><th>父级</th>
              <th>排序</th><th>子分类</th><th>地点数</th><th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="c in categories" :key="c.id">
              <td class="center">{{ c.icon || '—' }}</td>
              <td>{{ c.name }}</td>
              <td><code>{{ c.code }}</code></td>
              <td>{{ c.parentName || '（一级）' }}</td>
              <td class="center">{{ c.sortNo }}</td>
              <td class="center">{{ c.childCount }}</td>
              <td class="center">{{ c.placeCount }}</td>
              <td class="center ops">
                <button class="mini" @click="openCategoryModal('edit', c)">编辑</button>
                <button class="mini danger" @click="removeCategory(c)">删除</button>
              </td>
            </tr>
            <tr v-if="!categories.length"><td colspan="8" class="empty">还没有分类数据</td></tr>
          </tbody>
        </table>
      </section>

      <!-- ============ 地点管理 ============ -->
      <section v-show="tab === 'place'" class="panel">
        <div class="toolbar">
          <h2>地点数据 <small>首页卡片展示的内容</small></h2>
          <button class="primary" @click="openPlaceModal('create')">＋ 新增地点</button>
        </div>

        <div class="filters">
          <input v-model="filters.keyword" class="f-input" placeholder="搜索名称 / 标签 / 简介" @input="onFilter">
          <select v-model="filters.categoryId" class="f-input" @change="onFilter">
            <option :value="null">全部分类</option>
            <option v-for="c in categoryOptions" :key="c.id" :value="c.id">{{ c.label }}</option>
          </select>
          <select v-model="filters.grade" class="f-input" @change="onFilter">
            <option value="">全部分级</option>
            <option value="S">S 传说级</option>
            <option value="A">A 稀有级</option>
            <option value="B">B 常见级</option>
            <option value="C">C 普通级</option>
          </select>
          <span class="count">共 {{ places.length }} 条</span>
        </div>

        <div v-if="placeLoading" class="hint">加载中…</div>
        <table v-else class="tbl">
          <thead>
            <tr>
              <th>图标</th><th>名称</th><th>分类</th><th>分级</th>
              <th>评分</th><th>热度</th><th>浏览</th><th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="p in places" :key="p.id">
              <td class="center">{{ p.emoji || '—' }}</td>
              <td>{{ p.name }}</td>
              <td>{{ p.parentName }}<template v-if="p.categoryName"> / {{ p.categoryName }}</template></td>
              <td class="center">
                <span class="grade" :class="'g-' + (p.grade || '')">{{ p.grade }}</span>
              </td>
              <td class="center">{{ p.rating }}</td>
              <td class="center">{{ p.heat }}</td>
              <td class="center">{{ p.viewCount }}</td>
              <td class="center ops">
                <button class="mini" @click="openPlaceModal('edit', p)">编辑</button>
                <button class="mini danger" @click="removePlace(p)">删除</button>
              </td>
            </tr>
            <tr v-if="!places.length"><td colspan="8" class="empty">没有符合条件的地点</td></tr>
          </tbody>
        </table>
      </section>

      <!-- ============ 注册用户管理 ============ -->
      <section v-show="tab === 'user'" class="panel">
        <div class="toolbar">
          <h2>注册用户 <small>管理登录账号、明文密码与权限</small></h2>
          <span class="count">共 {{ userTotal }} 个用户</span>
        </div>

        <div class="filters">
          <input
            v-model="userFilters.keyword"
            class="f-input"
            placeholder="搜索用户名 / 昵称"
            @input="onUserFilter"
          >
          <button class="mini" :disabled="userPage <= 1" @click="changeUserPage(-1)">上一页</button>
          <span class="count">第 {{ userPage }} 页</span>
          <button class="mini" :disabled="!userHasNext" @click="changeUserPage(1)">下一页</button>
        </div>

        <div v-if="userLoading" class="hint">加载中…</div>
        <table v-else class="tbl">
          <thead>
            <tr>
              <th>ID</th><th>用户名</th><th>昵称</th><th>密码（明文）</th>
              <th>权限</th><th>注册时间</th><th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="u in users" :key="u.id">
              <td class="center">{{ u.id }}</td>
              <td>{{ u.username }}</td>
              <td>{{ u.nickname || '—' }}</td>
              <td><code>{{ u.password }}</code></td>
              <td class="center">
                <span class="perm" :class="u.permission === 0 ? 'perm-admin' : 'perm-user'">
                  {{ u.permission === 0 ? '管理员' : '普通用户' }}
                </span>
              </td>
              <td>{{ u.createTime }}</td>
              <td class="center ops">
                <button class="mini" @click="openUserModal(u)">编辑</button>
                <button class="mini danger" @click="removeUser(u)">删除</button>
              </td>
            </tr>
            <tr v-if="!users.length"><td colspan="7" class="empty">没有符合条件的用户</td></tr>
          </tbody>
        </table>
      </section>
    </main>

    <!-- ============ 分类弹窗 ============ -->
    <transition name="modal">
      <div v-if="catModal" class="mask" @click.self="catModal = false">
        <div class="dialog">
          <h3>{{ catMode === 'create' ? '新增分类' : '编辑分类' }}</h3>
          <div class="fld">
            <label>名称</label>
            <input v-model="catForm.name" placeholder="如：美食">
          </div>
          <div class="fld">
            <label>编码 <small>（前端筛选用，唯一）</small></label>
            <input v-model="catForm.code" placeholder="如：food">
          </div>
          <div class="fld">
            <label>图标</label>
            <input v-model="catForm.icon" placeholder="如：🍔（emoji）">
          </div>
          <div class="fld">
            <label>父级</label>
            <select v-model.number="catForm.parentId">
              <option :value="0">（作为一级分类）</option>
              <option v-for="c in topCategories" :key="c.id" :value="c.id">{{ c.name }}</option>
            </select>
          </div>
          <div class="fld">
            <label>排序号</label>
            <input v-model.number="catForm.sortNo" type="number" placeholder="数字越小越靠前">
          </div>
          <div class="dialog-ops">
            <button class="ghost" @click="catModal = false">取消</button>
            <button class="primary" :disabled="saving" @click="saveCategory">{{ saving ? '保存中…' : '保存' }}</button>
          </div>
        </div>
      </div>
    </transition>

    <!-- ============ 地点弹窗 ============ -->
    <transition name="modal">
      <div v-if="placeModal" class="mask" @click.self="placeModal = false">
        <div class="dialog">
          <h3>{{ placeMode === 'create' ? '新增地点' : '编辑地点' }}</h3>
          <div class="fld">
            <label>名称</label>
            <input v-model="placeForm.name" placeholder="如：蟹黄堡小屋">
          </div>
          <div class="fld">
            <label>图标</label>
            <input v-model="placeForm.emoji" placeholder="如：🍔">
          </div>
          <div class="fld">
            <label>所属分类</label>
            <select v-model.number="placeForm.categoryId">
              <option :value="null">请选择分类</option>
              <option v-for="c in categoryOptions" :key="c.id" :value="c.id">{{ c.label }}</option>
            </select>
          </div>
          <div class="fld">
            <label>分级</label>
            <select v-model="placeForm.grade">
              <option value="">不评级</option>
              <option value="S">S 传说级</option>
              <option value="A">A 稀有级</option>
              <option value="B">B 常见级</option>
              <option value="C">C 普通级</option>
            </select>
          </div>
          <div class="row">
            <div class="fld">
              <label>评分</label>
              <input v-model.number="placeForm.rating" type="number" step="0.1" placeholder="0-5">
            </div>
            <div class="fld">
              <label>热度</label>
              <input v-model.number="placeForm.heat" type="number" placeholder="整数">
            </div>
          </div>
          <div class="fld">
            <label>一句话简介</label>
            <input v-model="placeForm.summary" placeholder="简短描述">
          </div>
          <div class="fld">
            <label>详细介绍</label>
            <textarea v-model="placeForm.detail" rows="3" placeholder="详细介绍（支持多行）"></textarea>
          </div>
          <div class="fld">
            <label>标签 <small>（逗号分隔）</small></label>
            <input v-model="placeForm.tags" placeholder="如：美食,必吃,蟹堡王">
          </div>
          <div class="dialog-ops">
            <button class="ghost" @click="placeModal = false">取消</button>
            <button class="primary" :disabled="saving" @click="savePlace">{{ saving ? '保存中…' : '保存' }}</button>
          </div>
        </div>
      </div>
    </transition>

    <!-- ============ 用户弹窗 ============ -->
    <transition name="modal">
      <div v-if="userModal" class="mask" @click.self="userModal = false">
        <div class="dialog">
          <h3>编辑用户 · {{ userForm.username }}</h3>
          <div class="fld">
            <label>昵称</label>
            <input v-model="userForm.nickname" placeholder="用户昵称">
          </div>
          <div class="fld">
            <label>密码 <small>（明文存储）</small></label>
            <input v-model="userForm.password" placeholder="登录密码">
          </div>
          <div class="fld">
            <label>权限</label>
            <select v-model.number="userForm.permission">
              <option :value="1">1 · 普通用户</option>
              <option :value="0">0 · 管理员</option>
            </select>
          </div>
          <p class="tip">管理员（0）可以看到首页后台入口并登录后台；普通用户（1）不行。</p>
          <div class="dialog-ops">
            <button class="ghost" @click="userModal = false">取消</button>
            <button class="primary" :disabled="saving" @click="saveUser">{{ saving ? '保存中…' : '保存' }}</button>
          </div>
        </div>
      </div>
    </transition>

    <transition name="toast">
      <div v-if="toast" class="toast" :class="toastType">{{ toast }}</div>
    </transition>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'

// embedded=true 时作为首页内嵌面板使用：不跳转路由，关闭/退出由外层处理
const props = defineProps({
  embedded: { type: Boolean, default: false }
})
const emit = defineEmits(['close'])
import {
  adminLogout, adminMe, createCategory, createPlace, deleteCategory, deletePlace,
  deleteUser, getStats, listCategories, listPlaces, listUsers, updateCategory,
  updatePlace, updateUser
} from '../api/admin.js'
import { clearAdminSession, getAdminUsername } from '../utils/auth.js'

const router = useRouter()

const adminName = ref(getAdminUsername() || '管理员')
const tab = ref('category')

const stats = ref({ categoryCount: 0, placeCount: 0, userCount: 0, totalViews: 0, avgRating: '0' })
const statCards = computed(() => [
  { icon: '🗂️', label: '分类数量', value: stats.value.categoryCount },
  { icon: '📍', label: '地点数量', value: stats.value.placeCount },
  { icon: '👥', label: '注册用户', value: stats.value.userCount },
  { icon: '👀', label: '累计浏览', value: stats.value.totalViews },
  { icon: '⭐', label: '平均评分', value: stats.value.avgRating }
])

const categories = ref([])
const catLoading = ref(false)
const places = ref([])
const placeLoading = ref(false)
const users = ref([])
const userLoading = ref(false)
const userPage = ref(1)
const userTotal = ref(0)
const userHasNext = ref(false)

const filters = reactive({ keyword: '', categoryId: null, grade: '' })
const userFilters = reactive({ keyword: '' })

const toast = ref('')
const toastType = ref('')
let toastTimer = null

// 一级分类（用于分类表单的父级下拉）
const topCategories = computed(() => categories.value.filter((c) => !c.parentName))
// 全部分类（用于地点表单的分类下拉，带层级前缀）
const categoryOptions = computed(() =>
  categories.value.map((c) => ({
    id: c.id,
    label: c.parentName ? `${c.parentName} / ${c.name}` : c.name
  }))
)

// ============ 弹窗状态 ============
const catModal = ref(false)
const catMode = ref('create')
const catForm = reactive({ id: null, name: '', code: '', icon: '', parentId: 0, sortNo: 0 })

const placeModal = ref(false)
const placeMode = ref('create')
const placeForm = reactive({
  id: null, name: '', emoji: '', categoryId: null, grade: '',
  rating: null, heat: null, summary: '', detail: '', tags: ''
})

const userModal = ref(false)
const userForm = reactive({ id: null, username: '', nickname: '', password: '', permission: 1 })

const saving = ref(false)

// 切到用户管理时再加载数据
function switchTab(next) {
  tab.value = next
  if (next === 'user' && !users.value.length) loadUsers()
}

// ============ 工具 ============
function showToast(text, type = 'ok') {
  toast.value = text
  toastType.value = type
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { toast.value = '' }, 2400)
}

function emptyCatForm() {
  Object.assign(catForm, { id: null, name: '', code: '', icon: '', parentId: 0, sortNo: 0 })
}
function emptyPlaceForm() {
  Object.assign(placeForm, {
    id: null, name: '', emoji: '', categoryId: null, grade: '',
    rating: null, heat: null, summary: '', detail: '', tags: ''
  })
}

// ============ 数据加载 ============
async function loadStats() {
  const r = await getStats()
  if (r.ok) stats.value = r.data
}
async function loadCategories() {
  catLoading.value = true
  const r = await listCategories()
  catLoading.value = false
  if (r.ok) categories.value = r.data || []
  else if (r.code === 401) return goLogin()
  else showToast(r.message, 'err')
}
async function loadPlaces() {
  placeLoading.value = true
  const r = await listPlaces({
    keyword: filters.keyword,
    categoryId: filters.categoryId || undefined,
    grade: filters.grade || undefined,
    page: 1,
    size: 200
  })
  placeLoading.value = false
  if (r.ok) places.value = (r.data?.list || [])
  else if (r.code === 401) return goLogin()
  else showToast(r.message, 'err')
}

function onFilter() {
  loadPlaces()
}

async function loadUsers() {
  userLoading.value = true
  const r = await listUsers({
    keyword: userFilters.keyword,
    page: userPage.value,
    size: 20
  })
  userLoading.value = false
  if (r.ok) {
    users.value = r.data?.list || []
    userTotal.value = r.data?.total || 0
    userHasNext.value = Boolean(r.data?.hasNext)
  } else if (r.code === 401) {
    goLogin()
  } else {
    showToast(r.message, 'err')
  }
}

function onUserFilter() {
  userPage.value = 1
  loadUsers()
}

function changeUserPage(delta) {
  const next = userPage.value + delta
  if (next < 1) return
  userPage.value = next
  loadUsers()
}

function openUserModal(u) {
  Object.assign(userForm, {
    id: u.id,
    username: u.username,
    nickname: u.nickname || '',
    password: u.password || '',
    permission: u.permission === 0 ? 0 : 1
  })
  userModal.value = true
}

async function saveUser() {
  saving.value = true
  const r = await updateUser(userForm.id, {
    nickname: userForm.nickname.trim(),
    password: userForm.password.trim(),
    permission: userForm.permission
  })
  saving.value = false
  if (r.ok) {
    userModal.value = false
    showToast(r.message)
    await loadUsers()
  } else {
    showToast(r.message, 'err')
  }
}

async function removeUser(u) {
  if (!confirm(`确定删除用户「${u.username}」吗？`)) return
  const r = await deleteUser(u.id)
  if (r.ok) {
    showToast(r.message)
    await loadUsers()
  } else {
    showToast(r.message, 'err')
  }
}

function goLogin() {
  clearAdminSession()
  if (props.embedded) {
    emit('close')
    return
  }
  router.replace({ name: 'adminLogin' })
}

// ============ 分类弹窗 ============
function openCategoryModal(mode, item) {
  catMode.value = mode
  emptyCatForm()
  if (mode === 'edit' && item) {
    catForm.id = item.id
    catForm.name = item.name
    catForm.code = item.code
    catForm.icon = item.icon || ''
    catForm.parentId = item.parentId || 0
    catForm.sortNo = item.sortNo || 0
  }
  catModal.value = true
}

async function saveCategory() {
  saving.value = true
  const payload = {
    name: catForm.name.trim(),
    code: catForm.code.trim(),
    icon: catForm.icon.trim(),
    parentId: catForm.parentId || 0,
    sortNo: catForm.sortNo || 0
  }
  const r = catMode.value === 'create'
    ? await createCategory(payload)
    : await updateCategory(catForm.id, payload)
  saving.value = false
  if (r.ok) {
    catModal.value = false
    showToast(r.message)
    await loadCategories()
  } else {
    showToast(r.message, 'err')
  }
}

async function removeCategory(item) {
  if (!confirm(`确定删除分类「${item.name}」吗？若有子分类或地点会先被拦截。`)) return
  const r = await deleteCategory(item.id)
  if (r.ok) {
    showToast(r.message)
    await loadCategories()
  } else {
    showToast(r.message, 'err')
  }
}

// ============ 地点弹窗 ============
function openPlaceModal(mode, item) {
  placeMode.value = mode
  emptyPlaceForm()
  if (mode === 'edit' && item) {
    placeForm.id = item.id
    placeForm.name = item.name
    placeForm.emoji = item.emoji || ''
    placeForm.categoryId = item.categoryId
    placeForm.grade = item.grade || ''
    placeForm.rating = item.rating ?? null
    placeForm.heat = item.heat ?? null
    placeForm.summary = item.summary || ''
    placeForm.detail = item.detail || ''
    placeForm.tags = item.tags || ''
  }
  placeModal.value = true
}

async function savePlace() {
  saving.value = true
  const payload = {
    name: placeForm.name.trim(),
    emoji: placeForm.emoji.trim(),
    categoryId: placeForm.categoryId,
    grade: placeForm.grade || '',
    rating: placeForm.rating === '' || placeForm.rating === null ? null : Number(placeForm.rating),
    heat: placeForm.heat === '' || placeForm.heat === null ? 0 : Number(placeForm.heat),
    summary: placeForm.summary,
    detail: placeForm.detail,
    tags: placeForm.tags
  }
  const r = placeMode.value === 'create'
    ? await createPlace(payload)
    : await updatePlace(placeForm.id, payload)
  saving.value = false
  if (r.ok) {
    placeModal.value = false
    showToast(r.message)
    await loadPlaces()
  } else {
    showToast(r.message, 'err')
  }
}

async function removePlace(item) {
  if (!confirm(`确定删除地点「${item.name}」吗？`)) return
  const r = await deletePlace(item.id)
  if (r.ok) {
    showToast(r.message)
    await loadPlaces()
  } else {
    showToast(r.message, 'err')
  }
}

// ============ 退出 ============
async function logout() {
  await adminLogout()
  clearAdminSession()
  if (props.embedded) {
    emit('close')
    return
  }
  router.replace({ name: 'adminLogin' })
}

onMounted(async () => {
  // 先确认管理员 token 仍然有效（防止服务端重启 / 过期）
  const me = await adminMe()
  if (!me.ok) {
    goLogin()
    return
  }
  adminName.value = me.data?.username || adminName.value
  await Promise.all([loadStats(), loadCategories(), loadPlaces()])
})
</script>

<style scoped>
.admin {
  min-height: 100vh;
  color: #eaf7ff;
  position: relative;
  background:
    radial-gradient(120% 60% at 50% -10%, rgba(126, 226, 255, 0.2), transparent 60%),
    linear-gradient(180deg, #0a6ea6 0%, #075b8e 30%, #04476f 62%, #022b46 100%);
  background-attachment: fixed;
}

/* 顶栏：统一半透深蓝 */
.topbar {
  position: sticky;
  top: 0;
  z-index: 50;
  background: rgba(3, 46, 76, 0.86);
  backdrop-filter: blur(16px) saturate(145%);
  box-shadow: 0 6px 24px rgba(1, 26, 44, 0.4);
  border-bottom: 3px solid rgba(255, 213, 79, 0.7);
}
.topbar .brand { display: flex; align-items: center; gap: 10px; }
.brand-logo {
  width: 42px; height: 42px;
  display: grid; place-items: center;
  font-size: 22px;
  background: linear-gradient(180deg, #ffe082, #ffb300);
  border: 3px solid #ffd54f;
  border-radius: 14px;
  box-shadow: 0 3px 0 #c17900, 0 0 16px rgba(255, 193, 7, 0.5);
}
.brand-text { display: flex; flex-direction: column; line-height: 1.15; }
.brand-text strong { color: #fff8e1; font-size: 18px; letter-spacing: 2px; text-shadow: 0 2px 0 rgba(0,0,0,.25), 0 0 14px rgba(255,213,79,.4); }
.brand-text em { font-style: normal; font-size: 10px; letter-spacing: 1.5px; color: #8fdcff; }

.topbar {
  display: flex; align-items: center; justify-content: space-between;
  max-width: 1180px; margin: 0 auto; padding: 10px 20px;
}
.right { display: flex; align-items: center; gap: 10px; }
.user-chip {
  display: flex; align-items: center; gap: 7px;
  padding: 5px 14px 5px 6px;
  background: rgba(126, 226, 255, 0.14);
  border: 2px solid rgba(126, 226, 255, 0.5);
  border-radius: 999px;
  box-shadow: inset 0 2px 4px rgba(255,255,255,.2);
}
.avatar {
  width: 28px; height: 28px; display: grid; place-items: center;
  font-size: 16px; background: rgba(255,255,255,.92); border-radius: 50%;
  box-shadow: 0 0 8px rgba(255,213,79,.5);
}
.user-name { font-size: 14px; font-weight: bold; color: #eaf7ff; }
.logout {
  border: 2px solid rgba(126, 226, 255, 0.55);
  background:
    radial-gradient(circle at 32% 26%, rgba(255,255,255,.5), rgba(255,255,255,0) 52%),
    radial-gradient(circle at 50% 60%, rgba(126,226,255,.28), rgba(9,90,138,.4));
  color: #eaf7ff;
  padding: 8px 18px; border-radius: 999px;
  font-family: inherit; font-size: 13px; font-weight: bold; cursor: pointer;
  box-shadow: inset 0 2px 5px rgba(255,255,255,.4), 0 3px 8px rgba(1,26,44,.3);
  transition: transform .25s cubic-bezier(.2,1.3,.4,1), box-shadow .25s, border-color .25s;
}
.logout:hover { transform: translateY(-2px); border-color: #ffd54f; color: #5d3700; background: linear-gradient(180deg,#ffe082,#ffb300); box-shadow: 0 6px 16px rgba(1,26,44,.4), 0 0 18px rgba(255,213,79,.6); }

/* 主区 */
.main { max-width: 1180px; margin: 0 auto; padding: 28px 20px 60px; }

/* 统计：透亮泡泡卡 */
.stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 14px; margin-bottom: 24px; }
.stat-card {
  position: relative;
  display: flex; flex-direction: column; align-items: center; gap: 4px;
  padding: 18px; border-radius: 22px;
  background:
    radial-gradient(circle at 30% 20%, rgba(255,255,255,.4), rgba(255,255,255,0) 50%),
    rgba(126,226,255,.14);
  border: 1px solid rgba(190,240,255,.5);
  box-shadow: inset 0 2px 5px rgba(255,255,255,.3), inset 0 -3px 6px rgba(3,40,66,.25), 0 6px 14px rgba(1,26,44,.3);
  transition: transform .28s cubic-bezier(.2,1.3,.4,1), box-shadow .28s;
}
.stat-card:hover {
  transform: translateY(-6px);
  box-shadow: inset 0 2px 5px rgba(255,255,255,.4), 0 12px 22px rgba(1,26,44,.4), 0 0 20px rgba(255,213,79,.5);
}
.stat-icon {
  font-size: 20px; line-height: 1;
  width: 38px; height: 38px; display: grid; place-items: center; border-radius: 50%;
  background: radial-gradient(circle at 34% 28%, rgba(255,255,255,.9), rgba(255,236,179,.6) 60%, rgba(255,193,7,.5));
  border: 1px solid rgba(255,230,150,.85);
  box-shadow: inset 0 1px 3px rgba(255,255,255,.6), 0 0 10px rgba(255,213,79,.45);
  margin-bottom: 4px;
}
.stat-value { font-size: 26px; font-weight: bold; color: #ffe082; text-shadow: 0 0 12px rgba(255,213,79,.4); }
.stat-label { font-size: 12px; color: #b9e6ff; }

/* 选项卡：泡泡圆角 */
.tabs { display: flex; gap: 8px; margin-bottom: 18px; flex-wrap: wrap; }
.tab {
  position: relative; overflow: hidden;
  border: 1px solid rgba(190,240,255,.5);
  background:
    radial-gradient(circle at 28% 22%, rgba(255,255,255,.35), rgba(255,255,255,0) 50%),
    rgba(126,226,255,.14);
  color: #b9e6ff; padding: 10px 20px; border-radius: 999px;
  font-family: inherit; font-size: 15px; font-weight: bold; cursor: pointer;
  box-shadow: inset 0 2px 4px rgba(255,255,255,.25), 0 3px 8px rgba(1,26,44,.25);
  transition: transform .25s cubic-bezier(.2,1.3,.4,1), box-shadow .25s, color .2s, border-color .2s;
}
.tab:hover { transform: translateY(-2px); color: #fff; border-color: #ffe082; box-shadow: 0 6px 12px rgba(1,26,44,.3), 0 0 14px rgba(126,226,255,.4); }
.tab.active {
  background: linear-gradient(180deg, #ffd54f, #ffb300);
  border-color: #fff0b3; color: #5d3700;
  box-shadow: inset 0 2px 5px rgba(255,255,255,.6), 0 3px 0 #c17900, 0 0 18px rgba(255,213,79,.6);
}

/* 面板：玻璃舱 */
.panel {
  background: rgba(255,255,255,.07);
  border: 2px solid rgba(126,226,255,.32);
  border-radius: 22px; padding: 20px;
  backdrop-filter: blur(8px);
  box-shadow: inset 0 2px 0 rgba(255,255,255,.15), 0 10px 30px rgba(1,26,44,.25);
}
.toolbar { display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; }
.toolbar h2 { font-size: 18px; color: #fff8e1; }
.toolbar h2 small { font-size: 12px; font-weight: normal; color: #8fdcff; margin-left: 8px; }

.primary {
  border: none; padding: 9px 18px; border-radius: 12px;
  background: linear-gradient(180deg, #ffd54f, #ffb300);
  color: #5d3700; font-family: inherit; font-size: 14px; font-weight: bold;
  cursor: pointer; box-shadow: 0 3px 0 #c17900; transition: transform .1s, filter .2s;
}
.primary:hover { filter: brightness(1.05); }
.primary:active { transform: translateY(2px); }
.primary:disabled { opacity: .6; cursor: default; }

.hint { text-align: center; padding: 30px; color: #8fdcff; }
.empty { text-align: center; padding: 24px; color: #8fdcff; }

/* 筛选：泡泡圆角 */
.filters { display: flex; flex-wrap: wrap; gap: 10px; align-items: center; margin-bottom: 14px; }
.f-input {
  border: 1px solid rgba(190,240,255,.5);
  background:
    radial-gradient(circle at 28% 22%, rgba(255,255,255,.35), rgba(255,255,255,0) 50%),
    rgba(126,226,255,.14);
  color: #eaf7ff;
  padding: 9px 14px; border-radius: 999px; font-family: inherit; font-size: 14px;
  outline: none; min-width: 160px;
  box-shadow: inset 0 2px 4px rgba(255,255,255,.25), 0 3px 7px rgba(1,26,44,.22);
  transition: border-color .2s, box-shadow .2s;
}
.f-input:focus { border-color: #ffd54f; box-shadow: inset 0 2px 4px rgba(255,255,255,.3), 0 0 14px rgba(255,213,79,.5); }
.f-input option { color: #222; }
.count { font-size: 12px; color: #8fdcff; margin-left: auto; }

/* 表格 */
.tbl { width: 100%; border-collapse: collapse; font-size: 14px; }
.tbl th, .tbl td { padding: 10px 12px; text-align: left; }
.tbl thead th {
  color: #8fdcff; font-size: 12px; letter-spacing: 1px;
  border-bottom: 2px solid rgba(126,226,255,.4);
}
.tbl tbody tr { border-bottom: 1px dashed rgba(126,226,255,.2); }
.tbl tbody tr:hover { background: rgba(255,213,79,.12); }
.center { text-align: center; }
code { background: rgba(126,226,255,.18); color: #b9e6ff; padding: 2px 6px; border-radius: 6px; font-size: 12px; }
.grade {
  display: inline-block; padding: 2px 9px; border-radius: 999px; font-size: 11px; font-weight: bold;
}
.g-S { background: linear-gradient(180deg,#ffd54f,#ffb300); color: #5d3700; }
.g-A { background: linear-gradient(180deg,#9fe5ff,#4fc3f7); color: #04334d; }
.g-B { background: linear-gradient(180deg,#dbeaf3,#a9c6d7); color: #24414f; }
.g-C { background: linear-gradient(180deg,#ececec,#c2c2c2); color: #454545; }

.perm {
  display: inline-block; padding: 3px 10px; border-radius: 999px;
  font-size: 11px; font-weight: bold;
}
.perm-admin { background: linear-gradient(180deg,#ffd54f,#ffb300); color: #5d3700; }
.perm-user { background: rgba(126,226,255,.22); color: #b9e6ff; }

.tip { margin: 2px 0 10px; font-size: 12px; color: #8fdcff; line-height: 1.5; }

.ops { white-space: nowrap; }
.mini {
  border: 1px solid rgba(126,226,255,.5);
  background: rgba(126,226,255,.1); color: #b9e6ff;
  padding: 4px 12px; border-radius: 999px; font-family: inherit; font-size: 12px; font-weight: bold; cursor: pointer;
  transition: all .2s; margin: 0 2px;
}
.mini:hover:not(:disabled) { background: linear-gradient(180deg,#ffe082,#ffb300); color: #5d3700; border-color: #ffd54f; box-shadow: 0 0 12px rgba(255,213,79,.5); }
.mini:disabled { opacity: .4; cursor: default; }
.mini.danger { border-color: rgba(255,138,128,.5); color: #ffcdd2; background: rgba(255,138,128,.08); }
.mini.danger:hover { background: rgba(255,138,128,.25); color: #fff; border-color: #ff8a80; }

/* 弹窗：海底卡片 */
.mask {
  position: fixed; inset: 0; z-index: 80;
  display: grid; place-items: center; padding: 20px;
  background: rgba(1, 26, 44, .66); backdrop-filter: blur(5px);
}
.dialog {
  width: min(480px, 100%); max-height: 86vh; overflow: auto;
  padding: 24px; border-radius: 24px;
  background: linear-gradient(160deg,#fffdf5,#eaf8ff);
  border: 3px solid #ffd54f; color: #0a4a70;
  box-shadow: 0 12px 0 rgba(193,121,0,.5), 0 30px 60px rgba(0,0,0,.5);
}
.dialog h3 { font-size: 19px; color: #e65100; margin-bottom: 16px; }
.fld { margin-bottom: 12px; display: flex; flex-direction: column; gap: 5px; }
.fld label { font-size: 13px; font-weight: bold; color: #0a5c86; }
.fld label small { font-weight: normal; color: #7a8f9c; }
.fld input, .fld select, .fld textarea {
  border: 2px solid #b9e6ff; border-radius: 12px; padding: 9px 11px;
  font-family: inherit; font-size: 14px; color: #0a4a70; background: #f4fbff; outline: none;
  transition: border-color .2s, box-shadow .2s;
}
.fld input:focus, .fld select:focus, .fld textarea:focus { border-color: #ffb300; box-shadow: 0 0 12px rgba(255,193,7,.35); }
.fld textarea { resize: vertical; }
.row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.dialog-ops { display: flex; justify-content: flex-end; gap: 10px; margin-top: 8px; }
.ghost {
  border: 2px solid #b9e6ff; background: #f4fbff; color: #0a5c86;
  padding: 9px 18px; border-radius: 12px; font-family: inherit; font-size: 14px; font-weight: bold; cursor: pointer;
}
.ghost:hover { background: #e3f2fd; }
.ghost:hover { background: #f1e9ff; }

.modal-enter-active, .modal-leave-active { transition: opacity .2s; }
.modal-enter-from, .modal-leave-to { opacity: 0; }

/* toast */
.toast {
  position: fixed; left: 50%; bottom: 40px; transform: translateX(-50%);
  z-index: 99; padding: 12px 22px; border-radius: 999px;
  background: rgba(255,253,240,.98); border: 3px solid #ffd54f;
  color: #5d3700; font-size: 14px; font-weight: bold; box-shadow: 0 8px 24px rgba(0,0,0,.4), 0 0 20px rgba(255,213,79,.5);
  max-width: 88vw; text-align: center;
}
.toast.err { border-color: #ff8a80; color: #b71c1c; }
.toast-enter-active, .toast-leave-active { transition: opacity .25s, transform .25s; }
.toast-enter-from, .toast-leave-to { opacity: 0; transform: translate(-50%, 12px); }

@media (max-width: 860px) {
  .stats { grid-template-columns: repeat(2, 1fr); }
  .user-name { display: none; }
  .brand-text { display: none; }
}
</style>
