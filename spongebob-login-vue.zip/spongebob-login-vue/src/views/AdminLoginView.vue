<template>
  <div class="page">
    <OceanDecor />

    <div class="card">
      <div class="badge">🛠️</div>
      <h1>管理后台</h1>
      <p class="subtitle">比奇堡数据管理中心 · 仅限管理员登录</p>

      <form @submit.prevent="handleLogin" class="form">
        <div class="field">
          <span class="icon">👑</span>
          <input
            type="text"
            v-model="username"
            placeholder="管理员账号（试试 admin）"
            autocomplete="username"
          >
        </div>
        <div class="field">
          <span class="icon">🔑</span>
          <input
            type="password"
            v-model="password"
            placeholder="管理员密码（试试 admin123）"
            autocomplete="current-password"
          >
        </div>

        <button type="submit" class="btn" :disabled="loading">
          {{ loading ? '登录中…' : '进 入 后 台' }}
        </button>

        <div class="message" :class="messageType">{{ message }}</div>
      </form>

      <router-link to="/home" class="back">← 返回比奇堡首页</router-link>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import OceanDecor from '../components/OceanDecor.vue'
import { adminLogin } from '../api/admin.js'
import { setAdminSession } from '../utils/auth.js'

const router = useRouter()
const route = useRoute()

const username = ref('')
const password = ref('')
const message = ref('')
const messageType = ref('')
const loading = ref(false)

async function handleLogin() {
  const u = username.value.trim()
  const p = password.value.trim()

  if (!u || !p) {
    messageType.value = 'err'
    message.value = '管理员账号和密码都不能空！'
    return
  }

  loading.value = true
  messageType.value = ''
  message.value = '正在核对蟹老板的钥匙…'
  try {
    const r = await adminLogin(u, p)
    if (r.ok) {
      const token = r.data?.token
      if (!token) {
        messageType.value = 'err'
        message.value = '登录成功但后端没返回 token，请确认后端已是最新代码'
        return
      }
      setAdminSession({ token, username: r.data?.username || u })
      messageType.value = 'ok'
      message.value = '登录成功，正在进入管理后台…'

      const redirect = typeof route.query.redirect === 'string' ? route.query.redirect : ''
      const target = redirect.startsWith('/') ? redirect : '/admin'
      router.replace(target)
    } else {
      messageType.value = 'err'
      message.value = r.message
    }
  } catch (e) {
    messageType.value = 'err'
    message.value = '🐠 网络开小差了，连不上后端！请确认 Spring Boot 已启动在 8081。'
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  position: relative;
}

.card {
  position: relative;
  z-index: 5;
  width: 380px;
  max-width: 92vw;
  background: rgba(255, 253, 240, .96);
  border: 4px solid #9b66e6;
  border-radius: 28px;
  padding: 44px 32px 26px;
  box-shadow: 0 20px 50px rgba(60, 20, 110, .45);
  animation: cardIn .7s cubic-bezier(.2, 1.4, .4, 1);
  text-align: center;
}
@keyframes cardIn {
  from { transform: translateY(60px) scale(.85); opacity: 0; }
  to   { transform: translateY(0) scale(1); opacity: 1; }
}

.badge {
  width: 64px; height: 64px;
  margin: 0 auto 10px;
  display: grid; place-items: center;
  font-size: 32px;
  background: linear-gradient(180deg, #d9c2ff, #9b66e6);
  border: 4px solid #c9a3ff;
  border-radius: 18px;
  box-shadow: 0 4px 0 #6a3fb0, 0 0 20px rgba(170, 120, 255, .5);
}

h1 {
  color: #6a3fb0;
  font-size: 26px;
  letter-spacing: 4px;
  text-shadow: 2px 2px 0 #efe6ff;
  margin-bottom: 6px;
}

.subtitle {
  color: #8e7bbf;
  font-size: 12px;
  margin-bottom: 22px;
}

.form { text-align: left; }

.field { position: relative; margin-bottom: 16px; }
.field input {
  width: 100%;
  padding: 13px 14px 13px 44px;
  border: 3px solid #d9c2ff;
  border-radius: 14px;
  background: #faf6ff;
  font-size: 15px;
  color: #4e342e;
  outline: none;
  transition: border-color .2s, box-shadow .2s;
}
.field input:focus {
  border-color: #9b66e6;
  box-shadow: 0 0 0 4px rgba(155, 102, 230, .2);
}
.field .icon {
  position: absolute;
  left: 14px; top: 50%;
  transform: translateY(-50%);
  font-size: 18px;
}

.btn {
  width: 100%;
  padding: 14px;
  border: none;
  border-radius: 16px;
  background: linear-gradient(180deg, #c9a3ff, #9b66e6);
  color: #fff;
  font-size: 17px;
  font-weight: bold;
  letter-spacing: 3px;
  cursor: pointer;
  box-shadow: 0 5px 0 #6a3fb0, 0 8px 14px rgba(0, 0, 0, .15);
  transition: transform .1s, box-shadow .1s, filter .2s;
}
.btn:hover { filter: brightness(1.05); }
.btn:active {
  transform: translateY(4px);
  box-shadow: 0 1px 0 #6a3fb0, 0 3px 6px rgba(0, 0, 0, .15);
}
.btn:disabled { opacity: .7; cursor: default; }

.message {
  text-align: center;
  margin-top: 12px;
  font-size: 14px;
  font-weight: bold;
  min-height: 20px;
}
.message.ok { color: #2e7d32; }
.message.err { color: #c62828; }

.back {
  display: block;
  text-align: center;
  margin-top: 16px;
  font-size: 13px;
  color: #9b66e6;
  text-decoration: none;
}
.back:hover { text-decoration: underline; }
</style>
