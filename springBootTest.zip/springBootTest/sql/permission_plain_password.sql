-- ============================================================
-- 用户表升级：新增权限字段 + 密码改为明文
-- 权限：1 = 普通用户（默认值，注册用户）；0 = 管理员（可进入后台）
-- 说明：历史 BCrypt 哈希无法反推明文，统一重置为 123456
-- ============================================================

USE spongebob;

ALTER TABLE t_user
    ADD COLUMN permission TINYINT NOT NULL DEFAULT 1 COMMENT '权限：1 普通用户，0 管理员' AFTER nickname;

ALTER TABLE t_user
    MODIFY COLUMN password VARCHAR(100) NOT NULL COMMENT '密码（明文存储，演示用）';

-- 历史哈希密码无法还原，统一重置为明文 123456
UPDATE t_user SET password = '123456' WHERE password LIKE '$2a$%' OR password LIKE '$2b$%';

-- 除管理员外全部恢复为默认权限（防止历史数据里混入异常值）
UPDATE t_user SET permission = 1 WHERE username <> 'admin';

-- 管理员账号：明文密码，权限 0
INSERT INTO t_user (username, password, nickname, permission, create_time, update_time)
VALUES ('admin', 'admin123', '蟹老板', 0, NOW(), NOW())
ON DUPLICATE KEY UPDATE
    password = 'admin123',
    nickname = '蟹老板',
    permission = 0,
    update_time = NOW();
