-- ============================================================
-- 海绵宝宝登录注册系统数据库脚本
-- 数据库: spongebob  |  MySQL 8.0+
-- 使用方法: 在 IDEA 的 Database 面板或 MySQL 命令行中执行本文件
-- ============================================================

-- 如果数据库已存在先删除（演示用，生产环境请勿 DROP）
DROP DATABASE IF EXISTS spongebob;

CREATE DATABASE spongebob
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_general_ci;

USE spongebob;

-- ----------------------------
-- 用户表 t_user
-- ----------------------------
DROP TABLE IF EXISTS t_user;
CREATE TABLE t_user (
    id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键ID',
    username    VARCHAR(30)  NOT NULL                COMMENT '用户名',
    password    VARCHAR(100) NOT NULL                COMMENT '密码（明文存储，演示用）',
    nickname    VARCHAR(30)           DEFAULT NULL    COMMENT '昵称',
    permission  TINYINT      NOT NULL DEFAULT 1      COMMENT '权限：1 普通用户，0 管理员',
    create_time DATETIME              DEFAULT NULL    COMMENT '创建时间',
    update_time DATETIME              DEFAULT NULL    COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_username (username)
) ENGINE = InnoDB
  AUTO_INCREMENT = 1
  DEFAULT CHARSET = utf8mb4 COMMENT ='用户表';

-- ----------------------------
-- 初始测试数据（密码均为明文）
-- spongebob / patrick / squidward 为普通用户（permission = 1）
-- admin 为管理员（permission = 0），可进入后台管理系统
-- ----------------------------
INSERT INTO t_user (username, password, nickname, permission, create_time, update_time)
VALUES ('spongebob', '123456', '海绵宝宝', 1, NOW(), NOW()),
       ('patrick',   '123456', '派大星',   1, NOW(), NOW()),
       ('squidward', '123456', '章鱼哥',   1, NOW(), NOW()),
       ('admin',     'admin123', '蟹老板', 0, NOW(), NOW());
