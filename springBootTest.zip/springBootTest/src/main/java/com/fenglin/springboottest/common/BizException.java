package com.fenglin.springboottest.common;

/**
 * 业务异常：用于参数校验、删除约束等场景。
 * 由 GlobalExceptionHandler 统一转成 Result.error 返回给前端。
 */
public class BizException extends RuntimeException {

    public BizException(String message) {
        super(message);
    }
}
