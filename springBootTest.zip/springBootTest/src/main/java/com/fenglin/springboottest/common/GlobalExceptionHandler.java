package com.fenglin.springboottest.common;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 全局异常兜底：把业务异常转成统一的错误返回，避免把堆栈直接抛给前端。
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(BizException.class)
    public Result<String> handleBizException(BizException e) {
        return Result.error(e.getMessage());
    }
}
