package com.fenglin.springboottest.config;

import com.fenglin.springboottest.service.AdminTokenService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.nio.charset.StandardCharsets;

/**
 * 管理员登录校验拦截器：保护 /api/admin/** 这组接口（登录接口本身放行）。
 *
 * 请求带上 Authorization: Bearer &lt;adm_token&gt;，校验不通过返回 401 + 统一 JSON，
 * 前端收到 401 会清本地管理员登录态并跳回管理登录页。
 */
@Component
public class AdminInterceptor implements HandlerInterceptor {

    /** 拦截器校验通过后的管理员账号放入请求属性 */
    public static final String ATTR_ADMIN = "currentAdmin";

    @Autowired
    private AdminTokenService adminTokenService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {

        // 跨域预检直接放行
        if (HttpMethod.OPTIONS.matches(request.getMethod())) {
            return true;
        }

        String header = request.getHeader("Authorization");
        String token = null;
        if (header != null && header.startsWith("Bearer ")) {
            token = header.substring(7).trim();
        }

        AdminTokenService.Session session = adminTokenService.verify(token);
        if (session == null) {
            writeUnauthorized(response);
            return false;
        }

        request.setAttribute(ATTR_ADMIN, session.username());
        return true;
    }

    private void writeUnauthorized(HttpServletResponse response) throws Exception {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().write("{\"code\":401,\"message\":\"管理员登录状态已失效，请重新登录\",\"data\":null}");
    }
}
