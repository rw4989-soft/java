package com.fenglin.springboottest.controller;

import com.fenglin.springboottest.common.Result;
import com.fenglin.springboottest.config.AdminInterceptor;
import com.fenglin.springboottest.entity.Category;
import com.fenglin.springboottest.entity.Place;
import com.fenglin.springboottest.service.AdminService;
import com.fenglin.springboottest.service.AdminTokenService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 后台管理接口（除登录外均需管理员 token，由 AdminInterceptor 校验）
 *
 * 这套接口主要负责对首页展示的「分类」和「地点」数据进行管理。
 */
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminTokenService adminTokenService;

    @Autowired
    private AdminService adminService;

    @Value("${admin.username:admin}")
    private String adminUser;

    @Value("${admin.password:admin123}")
    private String adminPass;

    /**
     * 管理员登录：POST /api/admin/login  body: {"username":"admin","password":"admin123"}
     * 成功 data = { token, tokenType, expiresIn, username }
     */
    @PostMapping("/login")
    public Result<Map<String, Object>> login(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String password = body.get("password");

        if (!adminUser.equals(username) || !adminPass.equals(password)) {
            return Result.error("管理员账号或密码错误 🔒");
        }

        String token = adminTokenService.issue(adminUser);
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("token", token);
        data.put("tokenType", "Bearer");
        data.put("expiresIn", adminTokenService.getExpireSeconds());
        data.put("username", adminUser);

        return Result.success("管理后台开门啦 🔑", data);
    }

    /** 校验管理员 token 是否有效 */
    @GetMapping("/me")
    public Result<Map<String, Object>> me(HttpServletRequest request) {
        Object name = request.getAttribute(AdminInterceptor.ATTR_ADMIN);
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("username", name == null ? "" : name);
        return Result.success("管理员登录态有效 🛠️", data);
    }

    /** 退出管理后台 */
    @PostMapping("/logout")
    public Result<String> logout(HttpServletRequest request) {
        String header = request.getHeader("Authorization");
        if (header != null && header.startsWith("Bearer ")) {
            adminTokenService.revoke(header.substring(7).trim());
        }
        return Result.success("已退出管理后台 🚪");
    }

    /** 后台首页统计 */
    @GetMapping("/stats")
    public Result<Map<String, Object>> stats() {
        return Result.success("统计拉取完成 📊", adminService.stats());
    }

    /** 分类列表 */
    @GetMapping("/categories")
    public Result<List<Map<String, Object>>> categories() {
        return Result.success("分类列表 🗂️", adminService.listCategories());
    }

    /** 新增分类 */
    @PostMapping("/categories")
    public Result<Category> createCategory(@RequestBody Category body) {
        return Result.success("分类已新增 ✅", adminService.createCategory(body));
    }

    /** 更新分类 */
    @PutMapping("/categories/{id}")
    public Result<Category> updateCategory(@PathVariable Long id, @RequestBody Category body) {
        return Result.success("分类已更新 ✅", adminService.updateCategory(id, body));
    }

    /** 删除分类 */
    @DeleteMapping("/categories/{id}")
    public Result<String> deleteCategory(@PathVariable Long id) {
        adminService.deleteCategory(id);
        return Result.success("分类已删除 🗑️");
    }

    /** 地点列表（关键词 / 分类 / 分级筛选 + 分页） */
    @GetMapping("/places")
    public Result<Map<String, Object>> places(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) String grade,
            @RequestParam(required = false, defaultValue = "1") int page,
            @RequestParam(required = false, defaultValue = "10") int size) {
        return Result.success("地点列表 📍", adminService.listPlaces(keyword, categoryId, grade, page, size));
    }

    /** 新增地点 */
    @PostMapping("/places")
    public Result<Place> createPlace(@RequestBody Place body) {
        return Result.success("地点已新增 ✅", adminService.createPlace(body));
    }

    /** 更新地点 */
    @PutMapping("/places/{id}")
    public Result<Place> updatePlace(@PathVariable Long id, @RequestBody Place body) {
        return Result.success("地点已更新 ✅", adminService.updatePlace(id, body));
    }

    /** 删除地点 */
    @DeleteMapping("/places/{id}")
    public Result<String> deletePlace(@PathVariable Long id) {
        adminService.deletePlace(id);
        return Result.success("地点已删除 🗑️");
    }
}
