package com.fenglin.springboottest.controller;

import com.fenglin.springboottest.common.Result;
import com.fenglin.springboottest.config.AdminInterceptor;
import com.fenglin.springboottest.entity.Category;
import com.fenglin.springboottest.entity.Place;
import com.fenglin.springboottest.entity.User;
import com.fenglin.springboottest.service.AdminService;
import com.fenglin.springboottest.service.AdminTokenService;
import com.fenglin.springboottest.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 后台管理接口（除登录外均需管理员 token，由 AdminInterceptor 校验）
 *
 * 这套接口主要负责对首页展示的「分类」和「地点」数据进行管理。
 */
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminTokenService adminTokenService;

    @Autowired
    private AdminService adminService;

    @Autowired
    private UserService userService;

    /**
     * 管理员登录：POST /api/admin/login  body: {"username":"admin","password":"admin123"}
     * 仅 t_user 表中 permission = 0 的账号可以登录，密码明文比对。
     * 成功 data = { token, tokenType, expiresIn, username, nickname }
     */
    @PostMapping("/login")
    public Result<Map<String, Object>> login(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String password = body.get("password");

        if (username == null || username.isBlank() || password == null || password.isBlank()) {
            return Result.error("管理员账号或密码错误 🔒");
        }

        User user = userService.lambdaQuery()
                .eq(User::getUsername, username.trim())
                .one();
        // 权限 1 的普通用户即使账号密码正确也不允许登录后台
        if (user == null || !password.equals(user.getPassword())
                || user.getPermission() == null || user.getPermission() != 0) {
            return Result.error("该账号不是管理员，或账号密码错误 🔒");
        }

        String token = adminTokenService.issue(user.getUsername());
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("token", token);
        data.put("tokenType", "Bearer");
        data.put("expiresIn", adminTokenService.getExpireSeconds());
        data.put("username", user.getUsername());
        data.put("nickname", user.getNickname());

        return Result.success("管理后台开门啦 🔑", data);
    }

    /** 校验管理员 token 是否有效 */
    @GetMapping("/me")
    public Result<Map<String, Object>> me(HttpServletRequest request) {
        Object name = request.getAttribute(AdminInterceptor.ATTR_ADMIN);
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("username", name == null ? "" : name);
        return Result.success("管理员登录态有效 🛠️", data);
    }

    /** 退出管理后台 */
    @PostMapping("/logout")
    public Result<String> logout(HttpServletRequest request) {
        String header = request.getHeader("Authorization");
        if (header != null && header.startsWith("Bearer ")) {
            adminTokenService.revoke(header.substring(7).trim());
        }
        return Result.success("已退出管理后台 🚪");
    }

    /** 后台首页统计 */
    @GetMapping("/stats")
    public Result<Map<String, Object>> stats() {
        return Result.success("统计拉取完成 📊", adminService.stats());
    }

    /** 分类列表 */
    @GetMapping("/categories")
    public Result<List<Map<String, Object>>> categories() {
        return Result.success("分类列表 🗂️", adminService.listCategories());
    }

    /** 新增分类 */
    @PostMapping("/categories")
    public Result<Category> createCategory(@RequestBody Category body) {
        return Result.success("分类已新增 ✅", adminService.createCategory(body));
    }

    /** 更新分类 */
    @PutMapping("/categories/{id}")
    public Result<Category> updateCategory(@PathVariable Long id, @RequestBody Category body) {
        return Result.success("分类已更新 ✅", adminService.updateCategory(id, body));
    }

    /** 删除分类 */
    @DeleteMapping("/categories/{id}")
    public Result<String> deleteCategory(@PathVariable Long id) {
        adminService.deleteCategory(id);
        return Result.success("分类已删除 🗑️");
    }

    /** 地点列表（关键词 / 分类 / 分级筛选 + 分页） */
    @GetMapping("/places")
    public Result<Map<String, Object>> places(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Long categoryId,
            @RequestParam(required = false) String grade,
            @RequestParam(required = false, defaultValue = "1") int page,
            @RequestParam(required = false, defaultValue = "10") int size) {
        return Result.success("地点列表 📍", adminService.listPlaces(keyword, categoryId, grade, page, size));
    }

    /** 新增地点 */
    @PostMapping("/places")
    public Result<Place> createPlace(@RequestBody Place body) {
        return Result.success("地点已新增 ✅", adminService.createPlace(body));
    }

    /** 更新地点 */
    @PutMapping("/places/{id}")
    public Result<Place> updatePlace(@PathVariable Long id, @RequestBody Place body) {
        return Result.success("地点已更新 ✅", adminService.updatePlace(id, body));
    }

    /** 删除地点 */
    @DeleteMapping("/places/{id}")
    public Result<String> deletePlace(@PathVariable Long id) {
        adminService.deletePlace(id);
        return Result.success("地点已删除 🗑️");
    }

    // ==================== 注册用户管理 ====================

    /** 注册用户列表（关键词搜索 + 分页） */
    @GetMapping("/users")
    public Result<Map<String, Object>> users(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false, defaultValue = "1") int page,
            @RequestParam(required = false, defaultValue = "20") int size) {
        return Result.success("用户列表 👥", adminService.listUsers(keyword, page, size));
    }

    /** 编辑用户：昵称 / 明文密码 / 权限 */
    @PutMapping("/users/{id}")
    public Result<String> updateUser(@PathVariable Long id,
                                     @RequestBody Map<String, Object> body,
                                     HttpServletRequest request) {
        User target = userService.getById(id);
        if (target == null) {
            return Result.error("用户不存在");
        }
        if (isSelf(request, target) && body.containsKey("permission")
                && !"0".equals(String.valueOf(body.get("permission")))) {
            return Result.error("不能取消自己的管理员权限");
        }
        adminService.updateUser(id, body);
        return Result.success("用户已更新 ✅");
    }

    /** 删除用户 */
    @DeleteMapping("/users/{id}")
    public Result<String> deleteUser(@PathVariable Long id, HttpServletRequest request) {
        User target = userService.getById(id);
        if (target == null) {
            return Result.error("用户不存在");
        }
        if (isSelf(request, target)) {
            return Result.error("不能删除当前登录的管理员账号");
        }
        adminService.deleteUser(id);
        return Result.success("用户已删除 🗑️");
    }

    private boolean isSelf(HttpServletRequest request, User user) {
        Object name = request.getAttribute(AdminInterceptor.ATTR_ADMIN);
        return name != null && name.equals(user.getUsername());
    }
}
