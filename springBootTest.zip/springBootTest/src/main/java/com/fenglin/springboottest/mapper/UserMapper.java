package com.fenglin.springboottest.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fenglin.springboottest.entity.User;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户表 Mapper，继承 MyBatis-Plus 的 BaseMapper 即拥有常用 CRUD
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {
}
