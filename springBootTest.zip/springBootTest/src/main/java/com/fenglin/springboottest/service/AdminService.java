package com.fenglin.springboottest.service;

import com.fenglin.springboottest.entity.Category;
import com.fenglin.springboottest.entity.Place;

import java.util.List;
import java.util.Map;

/**
 * 后台管理数据服务：主要对首页展示的分类（t_category）与地点（t_place）做增删改查。
 */
public interface AdminService {

    /** 后台首页统计：分类数、地点数、累计浏览、平均评分 */
    Map<String, Object> stats();

    /** 分类列表（含父级名称、子分类数、地点数） */
    List<Map<String, Object>> listCategories();

    /** 新增分类 */
    Category createCategory(Category category);

    /** 更新分类 */
    Category updateCategory(Long id, Category category);

    /** 删除分类（有子分类或地点时拒绝） */
    void deleteCategory(Long id);

    /** 地点列表（按关键词 / 分类 / 分级筛选，带分页） */
    Map<String, Object> listPlaces(String keyword, Long categoryId, String grade, int page, int size);

    /** 新增地点 */
    Place createPlace(Place place);

    /** 更新地点 */
    Place updatePlace(Long id, Place place);

    /** 删除地点 */
    void deletePlace(Long id);
}
