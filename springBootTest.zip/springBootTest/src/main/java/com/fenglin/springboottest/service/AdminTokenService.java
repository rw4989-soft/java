package com.fenglin.springboottest.service;

import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 管理后台专用 token 服务：与用户 token 完全隔离，互不可混用。
 * 演示项目用内存 Map 存会话，重启即失效；生产环境请换成 Redis 或 JWT。
 */
@Service
public class AdminTokenService {

    /** 管理员 token 有效期（秒）：8 小时 */
    private static final long EXPIRE_SECONDS = 8 * 60 * 60;

    /** admin token -> 会话信息 */
    private final Map<String, Session> sessions = new ConcurrentHashMap<>();

    /**
     * 管理员会话
     * @param username 管理员账号
     * @param expireAt 过期时间戳（毫秒）
     */
    public record Session(String username, long expireAt) {
    }

    /** 登录成功时发放一个前缀为 adm_ 的 token，避免与用户 token 混淆 */
    public String issue(String username) {
        String token = "adm_" + UUID.randomUUID().toString().replace("-", "");
        sessions.put(token, new Session(username, System.currentTimeMillis() + EXPIRE_SECONDS * 1000));
        return token;
    }

    /** 校验 token，无效或已过期返回 null，顺便清掉过期项 */
    public Session verify(String token) {
        if (token == null || token.isBlank()) {
            return null;
        }
        Session session = sessions.get(token);
        if (session == null) {
            return null;
        }
        if (session.expireAt() < System.currentTimeMillis()) {
            sessions.remove(token);
            return null;
        }
        return session;
    }

    /** 退出登录时作废 token */
    public void revoke(String token) {
        if (token != null) {
            sessions.remove(token);
        }
    }

    /** 有效期（秒），返回给前端展示用 */
    public long getExpireSeconds() {
        return EXPIRE_SECONDS;
    }
}
