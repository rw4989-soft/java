package com.fenglin.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fenglin.springboottest.common.BizException;
import com.fenglin.springboottest.entity.Category;
import com.fenglin.springboottest.entity.Place;
import com.fenglin.springboottest.entity.User;
import com.fenglin.springboottest.mapper.CategoryMapper;
import com.fenglin.springboottest.mapper.PlaceMapper;
import com.fenglin.springboottest.mapper.UserMapper;
import com.fenglin.springboottest.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 后台管理数据服务实现
 */
@Service
public class AdminServiceImpl implements AdminService {

    /** 分级中文名固定映射 */
    private static final Map<String, String> GRADE_LABELS = Map.of(
            "S", "传说级", "A", "稀有级", "B", "常见级", "C", "普通级");

    @Autowired
    private CategoryMapper categoryMapper;

    @Autowired
    private PlaceMapper placeMapper;

    @Autowired
    private UserMapper userMapper;

    // ==================== 统计 ====================

    @Override
    public Map<String, Object> stats() {
        long categoryCount = categoryMapper.selectCount(new QueryWrapper<>());
        long placeCount = placeMapper.selectCount(new QueryWrapper<>());
        long userCount = userMapper.selectCount(new QueryWrapper<>());

        List<Map<String, Object>> rows = placeMapper.selectMaps(
                new QueryWrapper<Place>().select("SUM(view_count) AS views", "AVG(rating) AS avg"));
        long views = 0;
        double avg = 0;
        if (!rows.isEmpty()) {
            Object v = rows.get(0).get("views");
            Object a = rows.get(0).get("avg");
            if (v instanceof Number n) views = n.longValue();
            if (a instanceof Number n) avg = n.doubleValue();
        }

        Map<String, Object> m = new LinkedHashMap<>();
        m.put("categoryCount", categoryCount);
        m.put("placeCount", placeCount);
        m.put("userCount", userCount);
        m.put("totalViews", views);
        m.put("avgRating", BigDecimal.valueOf(avg).setScale(1, RoundingMode.HALF_UP).toPlainString());
        return m;
    }

    // ==================== 分类 ====================

    @Override
    public List<Map<String, Object>> listCategories() {
        List<Category> all = categoryMapper.selectList(
                new QueryWrapper<Category>().orderByAsc("sort_no").orderByAsc("id"));
        Map<Long, Category> map = all.stream()
                .collect(Collectors.toMap(Category::getId, c -> c, (a, b) -> a));

        Map<Long, Long> childCount = new HashMap<>();
        Map<Long, Long> placeCount = new HashMap<>();
        for (Category c : all) {
            if (c.getParentId() != null && c.getParentId() != 0L) {
                childCount.merge(c.getParentId(), 1L, Long::sum);
            }
        }
        List<Map<String, Object>> pr = placeMapper.selectMaps(
                new QueryWrapper<Place>().select("category_id AS cid", "COUNT(*) AS cnt").groupBy("category_id"));
        for (Map<String, Object> r : pr) {
            if (r.get("cid") instanceof Number n && r.get("cnt") instanceof Number c) {
                placeCount.put(n.longValue(), c.longValue());
            }
        }

        List<Map<String, Object>> result = new ArrayList<>();
        for (Category c : all) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", c.getId());
            m.put("code", c.getCode());
            m.put("name", c.getName());
            m.put("icon", c.getIcon());
            m.put("parentId", c.getParentId());
            boolean hasParent = c.getParentId() != null && c.getParentId() != 0L;
            Category parent = hasParent ? map.get(c.getParentId()) : null;
            m.put("parentName", parent == null ? "" : parent.getName());
            m.put("sortNo", c.getSortNo());
            m.put("childCount", childCount.getOrDefault(c.getId(), 0L));
            m.put("placeCount", placeCount.getOrDefault(c.getId(), 0L));
            result.add(m);
        }
        return result;
    }

    @Override
    public Category createCategory(Category category) {
        if (category == null || !StringUtils.hasText(category.getName())) {
            throw new BizException("分类名称不能为空");
        }
        if (!StringUtils.hasText(category.getCode())) {
            throw new BizException("分类编码不能为空");
        }
        String code = category.getCode().trim();
        if (categoryMapper.selectCount(new QueryWrapper<Category>().eq("code", code)) > 0) {
            throw new BizException("分类编码「" + code + "」已存在");
        }

        Long pid = (category.getParentId() == null || category.getParentId() == 0L) ? 0L : category.getParentId();
        if (pid != 0L && categoryMapper.selectById(pid) == null) {
            throw new BizException("父分类不存在");
        }

        Category entity = new Category();
        entity.setCode(code);
        entity.setName(category.getName().trim());
        entity.setIcon(category.getIcon());
        entity.setParentId(pid);
        entity.setSortNo(category.getSortNo() == null ? 0 : category.getSortNo());
        categoryMapper.insert(entity);
        return entity;
    }

    @Override
    public Category updateCategory(Long id, Category category) {
        Category exist = categoryMapper.selectById(id);
        if (exist == null) {
            throw new BizException("分类不存在");
        }
        if (!StringUtils.hasText(category.getName())) {
            throw new BizException("分类名称不能为空");
        }
        if (!StringUtils.hasText(category.getCode())) {
            throw new BizException("分类编码不能为空");
        }
        String code = category.getCode().trim();
        if (!code.equals(exist.getCode())
                && categoryMapper.selectCount(new QueryWrapper<Category>().eq("code", code)) > 0) {
            throw new BizException("分类编码「" + code + "」已存在");
        }

        Long pid = (category.getParentId() == null || category.getParentId() == 0L) ? 0L : category.getParentId();
        if (pid != 0L && categoryMapper.selectById(pid) == null) {
            throw new BizException("父分类不存在");
        }
        if (pid.equals(id)) {
            throw new BizException("不能把分类设为自己的子分类");
        }

        exist.setCode(code);
        exist.setName(category.getName().trim());
        exist.setIcon(category.getIcon());
        exist.setParentId(pid);
        exist.setSortNo(category.getSortNo() == null ? 0 : category.getSortNo());
        categoryMapper.updateById(exist);
        return exist;
    }

    @Override
    public void deleteCategory(Long id) {
        Category exist = categoryMapper.selectById(id);
        if (exist == null) {
            throw new BizException("分类不存在");
        }
        long child = categoryMapper.selectCount(new QueryWrapper<Category>().eq("parent_id", id));
        if (child > 0) {
            throw new BizException("该分类下还有 " + child + " 个二级分类，请先删除子分类");
        }
        long pc = placeMapper.selectCount(new QueryWrapper<Place>().eq("category_id", id));
        if (pc > 0) {
            throw new BizException("该分类下还有 " + pc + " 个地点，请先删除或转移地点");
        }
        categoryMapper.deleteById(id);
    }

    // ==================== 地点 ====================

    @Override
    public Map<String, Object> listPlaces(String keyword, Long categoryId, String grade, int page, int size) {
        LambdaQueryWrapper<Place> qw = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            String k = keyword.trim();
            qw.like(Place::getName, k)
                    .or().like(Place::getTags, k)
                    .or().like(Place::getSummary, k);
        }
        if (categoryId != null) {
            qw.eq(Place::getCategoryId, categoryId);
        }
        if (StringUtils.hasText(grade)) {
            qw.eq(Place::getGrade, grade.trim().toUpperCase());
        }
        qw.orderByDesc(Place::getId);

        int safeSize = size <= 0 ? 10 : Math.min(size, 100);
        int safePage = Math.max(page, 1);
        Page<Place> p = placeMapper.selectPage(new Page<>(safePage, safeSize), qw);

        Map<Long, Category> catMap = toCategoryMap();
        List<Map<String, Object>> list = p.getRecords().stream()
                .map(pl -> toPlaceView(pl, catMap))
                .collect(Collectors.toList());

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("list", list);
        data.put("total", p.getTotal());
        data.put("page", safePage);
        data.put("size", safeSize);
        data.put("hasNext", (long) safePage * safeSize < p.getTotal());
        return data;
    }

    @Override
    public Place createPlace(Place place) {
        if (place == null || !StringUtils.hasText(place.getName())) {
            throw new BizException("地点名称不能为空");
        }
        if (place.getCategoryId() == null || categoryMapper.selectById(place.getCategoryId()) == null) {
            throw new BizException("请选择有效的所属分类");
        }
        fillGradeLabel(place);
        if (place.getHeat() == null) place.setHeat(0);
        if (place.getViewCount() == null) place.setViewCount(0);
        if (place.getRating() == null) place.setRating(BigDecimal.ZERO);
        placeMapper.insert(place);
        return place;
    }

    @Override
    public Place updatePlace(Long id, Place place) {
        Place exist = placeMapper.selectById(id);
        if (exist == null) {
            throw new BizException("地点不存在");
        }
        if (!StringUtils.hasText(place.getName())) {
            throw new BizException("地点名称不能为空");
        }
        if (place.getCategoryId() != null) {
            if (place.getCategoryId() <= 0 || categoryMapper.selectById(place.getCategoryId()) == null) {
                throw new BizException("请选择有效的所属分类");
            }
            exist.setCategoryId(place.getCategoryId());
        }
        exist.setName(place.getName().trim());
        exist.setEmoji(place.getEmoji());
        exist.setSummary(place.getSummary());
        exist.setDetail(place.getDetail());
        if (StringUtils.hasText(place.getGrade())) {
            exist.setGrade(place.getGrade().trim().toUpperCase());
        }
        fillGradeLabel(exist);
        if (place.getRating() != null) exist.setRating(place.getRating());
        if (place.getHeat() != null) exist.setHeat(place.getHeat());
        if (place.getViewCount() != null) exist.setViewCount(place.getViewCount());
        exist.setTags(place.getTags());
        placeMapper.updateById(exist);
        return exist;
    }

    @Override
    public void deletePlace(Long id) {
        if (placeMapper.selectById(id) == null) {
            throw new BizException("地点不存在");
        }
        placeMapper.deleteById(id);
    }

    // ==================== 注册用户 ====================

    @Override
    public Map<String, Object> listUsers(String keyword, int page, int size) {
        LambdaQueryWrapper<User> qw = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(keyword)) {
            String k = keyword.trim();
            qw.like(User::getUsername, k)
                    .or().like(User::getNickname, k);
        }
        qw.orderByDesc(User::getId);

        int safeSize = size <= 0 ? 10 : Math.min(size, 100);
        int safePage = Math.max(page, 1);
        Page<User> p = userMapper.selectPage(new Page<>(safePage, safeSize), qw);

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        List<Map<String, Object>> list = p.getRecords().stream().map(u -> {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", u.getId());
            m.put("username", u.getUsername());
            m.put("nickname", u.getNickname());
            m.put("password", u.getPassword());
            m.put("permission", u.getPermission());
            m.put("createTime", u.getCreateTime() == null ? "" : u.getCreateTime().format(fmt));
            m.put("updateTime", u.getUpdateTime() == null ? "" : u.getUpdateTime().format(fmt));
            return m;
        }).collect(Collectors.toList());

        Map<String, Object> data = new LinkedHashMap<>();
        data.put("list", list);
        data.put("total", p.getTotal());
        data.put("page", safePage);
        data.put("size", safeSize);
        data.put("hasNext", (long) safePage * safeSize < p.getTotal());
        return data;
    }

    @Override
    public void updateUser(Long id, Map<String, Object> body) {
        User user = userMapper.selectById(id);
        if (user == null) {
            throw new BizException("用户不存在");
        }
        if (body.containsKey("nickname")) {
            String nickname = body.get("nickname") == null ? "" : String.valueOf(body.get("nickname")).trim();
            if (StringUtils.hasText(nickname)) {
                user.setNickname(nickname);
            }
        }
        if (body.containsKey("password")) {
            String password = body.get("password") == null ? "" : String.valueOf(body.get("password")).trim();
            if (!StringUtils.hasText(password)) {
                throw new BizException("密码不能为空");
            }
            user.setPassword(password);
        }
        if (body.containsKey("permission")) {
            int permission;
            try {
                permission = Integer.parseInt(String.valueOf(body.get("permission")));
            } catch (Exception e) {
                throw new BizException("权限值不正确");
            }
            if (permission != 0 && permission != 1) {
                throw new BizException("权限只能是 0（管理员）或 1（普通用户）");
            }
            user.setPermission(permission);
        }
        user.setUpdateTime(LocalDateTime.now());
        userMapper.updateById(user);
    }

    @Override
    public void deleteUser(Long id) {
        if (userMapper.selectById(id) == null) {
            throw new BizException("用户不存在");
        }
        userMapper.deleteById(id);
    }

    // ==================== 内部工具 ====================

    private void fillGradeLabel(Place p) {
        if (StringUtils.hasText(p.getGrade())) {
            p.setGradeLabel(GRADE_LABELS.getOrDefault(p.getGrade().trim().toUpperCase(), ""));
        }
    }

    private Map<Long, Category> toCategoryMap() {
        return categoryMapper.selectList(new QueryWrapper<>()).stream()
                .collect(Collectors.toMap(Category::getId, c -> c, (a, b) -> a));
    }

    private Map<String, Object> toPlaceView(Place pl, Map<Long, Category> catMap) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", pl.getId());
        m.put("name", pl.getName());
        m.put("emoji", pl.getEmoji());
        m.put("summary", pl.getSummary());
        m.put("detail", pl.getDetail());
        m.put("grade", pl.getGrade());
        m.put("gradeLabel", pl.getGradeLabel());
        m.put("rating", pl.getRating());
        m.put("heat", pl.getHeat());
        m.put("viewCount", pl.getViewCount());
        m.put("categoryId", pl.getCategoryId());
        m.put("tags", pl.getTags());

        Category cat = pl.getCategoryId() != null ? catMap.get(pl.getCategoryId()) : null;
        if (cat != null) {
            if (cat.getParentId() != null && cat.getParentId() != 0L) {
                Category parent = catMap.get(cat.getParentId());
                m.put("parentName", parent == null ? "" : parent.getName());
                m.put("categoryName", cat.getName());
            } else {
                m.put("parentName", cat.getName());
                m.put("categoryName", "");
            }
        } else {
            m.put("parentName", "");
            m.put("categoryName", "");
        }
        return m;
    }
}
