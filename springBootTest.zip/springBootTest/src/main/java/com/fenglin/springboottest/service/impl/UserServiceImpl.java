package com.fenglin.springboottest.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.fenglin.springboottest.entity.User;
import com.fenglin.springboottest.mapper.UserMapper;
import com.fenglin.springboottest.service.UserService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

/**
 * 用户 Service 实现
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Override
    public User login(String username, String password) {
        User user = lambdaQuery()
                .eq(User::getUsername, username)
                .one();
        // 密码明文存储，直接比对
        if (user == null || !password.equals(user.getPassword())) {
            return null;
        }
        return user;
    }

    @Override
    public User register(String username, String password, String nickname) {
        // 检查用户名是否已存在
        Long count = lambdaQuery()
                .eq(User::getUsername, username)
                .count();
        if (count != null && count > 0) {
            return null;
        }

        User user = new User();
        user.setUsername(username);
        // 密码明文存储（演示项目，无需加密）
        user.setPassword(password);
        // 昵称为空时默认用用户名
        user.setNickname(nickname == null || nickname.isBlank() ? username : nickname);
        // 注册用户一律为默认权限 1，不能通过注册获得管理员权限
        user.setPermission(1);
        user.setCreateTime(LocalDateTime.now());
        user.setUpdateTime(LocalDateTime.now());
        save(user);
        return user;
    }
}
